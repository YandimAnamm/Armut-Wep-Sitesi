<?php
include "db.php";
include "kontrol.php";
$sayfa="Paketler";
?>

<?php
if( isset($_GET['silid']) ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$query = $db->prepare("DELETE FROM paketler WHERE id = :id");
$delete = $query->execute(array(
'id' => $_GET['silid']
));
header("Location: ?success=Paket silindi.");
exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteadi?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>


</head>
<body class="hold-transition <?=$tema?> sidebar-mini">
<div class="wrapper">

<?php
include "ust.php";
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!---------------------------------------------- Main content --------------------------------------------->
    <section class="content container-fluid" style="min-height:600px;">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><?=$sayfa?></h3>
          <div class="box-tools pull-right">
            <a href="paketekle.php" class="btn btn-success btn-sm" ><i class="fa fa-plus"></i> Yeni Kayıt</a>
          </div>
        </div>
        <div class="box-body" style="min-height:400px;">

<?php
$query = $db->prepare("SELECT * FROM paketler");
$query->execute();
$verisay = $query->rowCount();
?>
<?php if($verisay == "0"){ ?>
<div class="alert alert-warning">Kayıt Yok!</div>
<?php }else{ ?>
<div class="row">
<?php
while($row=$query->fetch(PDO::FETCH_ASSOC)) {
?>
<div class="col-md-4">
<ul class="list-group">
<li class="list-group-item text-center active"><b><?=$row['baslik']?></b><br><?=$row['altbaslik']?></li>
<?php
foreach($db->query("SELECT * FROM paketozellikleri order by id asc") as $ozb) {
?>
<li class="list-group-item text-center list-group-item-<?php echo strpos($row['ozellikler'],$ozb['ozellik'])===False ? 'danger':'success';?>"><i class="fa <?php echo strpos($row['ozellikler'],$ozb['ozellik'])===False ? 'fa-close':'fa-check';?>"></i> <?=$ozb['ozellik']?></li>
<?php }?>
<li class="list-group-item text-center list-group-item-info"><?=$row['ucret']?> TL / <?php if($row['sure']>1 && $row['sure']<12){ echo $row['sure'].' Ay';}else if($row['sure']=='1'){echo 'Ay';}else if($row['sure']=='12'){echo 'Yıl';}?></li>
<li class="list-group-item text-center">
<a href="paketguncelle.php?id=<?=$row['id']?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a> 
<a href="?silid=<?=$row['id']?>" class="btn btn-danger btn-sm" onclick="return confirm('Silmek istiyor musunuz?')"><i class="fa fa-trash-o"></i></a>
</li>
</ul>
</div>
<?php } ?>

</div>

<?php } ?>



        </div>
        <!-- /.box-body -->
        <div class="box-footer">
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->


    </section>
    <!----------------------------------------------- /.content ------------------------------------------------>
  </div>
  <!-- /.content-wrapper -->


<?php
include "alt.php";
?>






</body>
</html>