<?php
include "db.php";
include "kontrol.php";
?>

<?php
$talepno=$_GET["talepno"];
$talepbak = $db->prepare("SELECT * FROM talepler WHERE talepno=:talepno");
$talepbak->bindValue(':talepno', $talepno);
$talepbak->execute();
if($talepbak->rowCount()){
$talepbilgi = $talepbak->fetch(PDO::FETCH_ASSOC);
$id=$talepbilgi['id'];

$talepuyebilgi = $db->query("SELECT * FROM uyeler where id=".$talepbilgi['uyeid']." ")->fetch(PDO::FETCH_ASSOC);
if(!isset($talepuyebilgi['id'])){
echo "Üye Silinmiş!";
}else{

$kat2 = $db->query("SELECT * FROM kategoriler where id=".$talepbilgi['katid']." ")->fetch(PDO::FETCH_ASSOC);
if(!isset($kat2['id'])){
echo "Kategori Silinmiş!";
}else{

$kat1 = $db->query("SELECT * FROM kategoriler where id=".$kat2['ustkat']." ")->fetch(PDO::FETCH_ASSOC);
if(!isset($kat1['id'])){
echo "Kategori Silinmiş!";
}else{


if(isset($kat1['id'])){
if($kat1['minteklif']!==''){
$minteklif=$kat1['minteklif'];
}
if($kat1['teklifucreti']!==''){
$teklifucreti=$kat1['teklifucreti'];
}
if($kat1['komisyonucreti']!==''){
$komisyonucreti=$kat1['komisyonucreti'];
}
}

if($kat2['minteklif']!==''){
$minteklif=$kat2['minteklif'];
}

if($kat2['teklifucreti']!==''){
$teklifucreti=$kat2['teklifucreti'];
}

if($kat2['komisyonucreti']!==''){
$komisyonucreti=$kat2['komisyonucreti'];
}


?>



<h3 class="text-center"><?=$talepbilgi['durum']?></h3>

<table class="table">
<tr><td class="text-bold">Talep Sahibi</td><td><span class="uyebilgi" data-uyeid="<?=$talepuyebilgi['id']?>" ><?=$talepuyebilgi['isim']?></span></td></tr>
<tr><td class="text-bold">Telefon</td><td><?=$talepuyebilgi['tel']?></td></tr>
<tr><td class="text-bold">E-Posta</td><td><?=$talepuyebilgi['eposta']?> <a class="btn btn-success" href="mesajlar.php?kisiid=<?=$talepbilgi['uyeid']?>"><i class="fa fa-envelope"></i> Mesaj Yaz </a></td></tr>
<tr><td class="text-bold">Adres</td><td><?=$talepuyebilgi['adres']?> <span style="display:inline-block"><?=$talepuyebilgi['il']?> / <?=$talepuyebilgi['ilce']?></span></td></tr>
<tr><td class="text-bold">Kategori</td><td><?=$kat2['baslik']?></td></tr>
<?php 
if(!empty($talepbilgi['secim'])){
$secimler=json_decode($talepbilgi['secim'],true);
foreach($secimler as $key=>$value){ 
?>
<tr><td class="text-bold"><?=$secimler[$key]['soru']?></td><td><?php foreach($secimler[$key]['secenek'] as $key2=>$value2){ echo $value2; } ?></td></tr>
<?php }} ?>
<tr><td class="text-bold">Açıklama</td><td><?=$talepbilgi['detaylar']?></td></tr>
<?php
$query = $db->prepare("SELECT * FROM galeri where dosyano='".$talepbilgi['talepno']."' order by id asc");
$query->execute();
$verisay = $query->rowCount();
?>
<?php if($verisay){ ?>
<tr><td colspan="2">
<?php while($row=$query->fetch(PDO::FETCH_ASSOC)) { ?>
<img src="<?=$row['adres']?>" style="width:160px;margin:10px;">
<?php } ?>
</td></tr>
<?php } ?>
<tr><td class="text-bold">Bölge</td><td><?=$talepbilgi['il']?>/<?=$talepbilgi['ilce']?></td></tr>
<tr><td class="text-bold">Hizmetin istendiği tarih</td><td><?php if($talepbilgi['nezaman']=='Belli bir zaman'){ ?> <?=date('d.m.Y',$talepbilgi['tarih'])?> <?=$talepbilgi['saat']?> <?php }else{?> <?=$talepbilgi['nezaman']?> <?php } ?></td></tr>
<tr><td class="text-bold">Oluşturma</td><td><?=date('d.m.Y H:i',strtotime($talepbilgi['olusturma']))?></td></tr>
</table>


<?php
if($talepbilgi['durum']!=='Onay Bekliyor'){  //--------------- if 1 --------------
$rsbak = $db->prepare("SELECT * FROM teklifler where talepno='".$talepbilgi['talepno']."' order by id asc");
$rsbak->execute();
$rssay = $rsbak->rowCount();
if($rssay=="0"){ 
?>
<p class="alert alert-warning">Henüz Teklif Gelmedi</p>
<?php 
}else{ 
?>

<?php if($talepbilgi['durum']=='Kapandı'){ ?> 
<p><b>Yeterli teklif sayısına ulaşıldığı için bu talep tekliflere kapandı.</b></p>
<p>Müşterinin uygun teklifi onaylaması bekleniyor.</p>
<?php } ?>

<h3>Gelen Teklifler</h3>
<table class="table">
<?php
while($rs=$rsbak->fetch(PDO::FETCH_ASSOC)) {
$uyebak = $db->query("SELECT * FROM uyeler where id=".$rs['uyeid']." ")->fetch(PDO::FETCH_ASSOC);
$uyehizmet = $db->query("SELECT * FROM hizmetler where uyeid=".$rs['uyeid']." and katid=".$talepbilgi['katid']." ")->fetch(PDO::FETCH_ASSOC);
?>
<tr class="<?php if($rs['durum']=='Başarılı'){ echo 'success'; }else if($rs['durum']=='Başarısız'){ echo 'danger';} ?>">
<td><span class="uyebilgi" data-uyeid="<?=$uyebak['id']?>" ><?=$uyebak['isim']?></span></td>
<td class="text-right"><?=$rs['teklif']?> TL</td>
<td class="text-right"><?=$rs['durum']?></td>
</tr>
<?php } ?>
</table>
<?php } ?>



<?php if($talepbilgi['durum']=='İş Tamamlandı'){ ?>
<br>
<p><b>Müşteri Hizmet Değerlendirmesi</b></p>
<p><i class="fa fa-star<?php echo $talepbilgi['puan']>0 ? '':'-o';?>"></i><i class="fa fa-star<?php echo $talepbilgi['puan']>1 ? '':'-o';?>"></i><i class="fa fa-star<?php echo $talepbilgi['puan']>2 ? '':'-o';?>"></i><i class="fa fa-star<?php echo $talepbilgi['puan']>3 ? '':'-o';?>"></i><i class="fa fa-star<?php echo $talepbilgi['puan']>4 ? '':'-o';?>"></i></p>
<p><?=$talepbilgi['yorum']?></p>

<?php if($talepbilgi['yorum']!=='' && $talepbilgi['yorumonay']=='1'){ ?>
<p class="text-success">Yorum Onaylandı</p>
<?php }else if($talepbilgi['yorum']!=='' && $talepbilgi['yorumonay']=='0'){ ?>
<p class="text-danger">Yorum Onay Bekliyor!</p>
<?php } ?>

<?php } ?>




<?php } ?> <!--------------- if 1 --------------->



<?php }}} ?>
<?php } ?>