<?php
include "db.php";
include "kontrol.php";
$sayfa="Anasayfa";
?>

<?php
if( isset($_GET['silid']) ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$query = $db->prepare("DELETE FROM ucretler WHERE siparisno = :id");
$delete = $query->execute(array(
'id' => $_GET['silid']
));
header("Location: ?");
exit();
}
?>


<?php
if( isset($_GET['havaleonayla']) ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$siparisno=$_GET['havaleonayla'];
$sipbak = $db->prepare("SELECT * FROM ucretler WHERE siparisno=:siparisno");
$sipbak->bindValue(':siparisno', $siparisno);
$sipbak->execute();
if($sipbak->rowCount()){
$sip = $sipbak->fetch(PDO::FETCH_ASSOC);
$kisiid=$sip['uyeid'];
$miktar=$sip['miktar'];
}

$bak = $db->prepare("SELECT * FROM uyeler WHERE id=:uyeid");
$bak->bindValue(':uyeid', $kisiid);
$bak->execute();
if($bak->rowCount()){
$uyebilgi = $bak->fetch(PDO::FETCH_ASSOC);
$uyebakiye = $uyebilgi['bakiye'];
}

$yenibakiye = round(($uyebakiye + $miktar),2);
$song1 = $db->prepare("UPDATE uyeler SET bakiye = :yenibakiye where id=:uyeid ");
$song1->bindValue(':uyeid', $kisiid);
$song1->bindValue(':yenibakiye', $yenibakiye);
$song1->execute();

$song1 = $db->prepare("UPDATE ucretler SET durum = 1 where siparisno=:siparisno ");
$song1->bindValue(':siparisno', $siparisno);
$song1->execute();

$mesaj="<a href=\"/bakiyem\">Havale bildiriminiz onaylandı.</a>";
$bildir = $db->prepare("INSERT INTO bildirimler (uyeid, mesaj) VALUES ('".$kisiid."','".$mesaj."') ");
$bildir->execute();

header("Location: ?");
exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteadi?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>

<!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="bower_components/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">

</head>
<body class="hold-transition <?=$tema?> sidebar-mini">
<div class="wrapper">

<?php
include "ust.php";
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!---------------------------------------------- Main content --------------------------------------------->
    <section class="content container-fluid" style="min-height:600px;">

<div class="row">
<div class="col-md-12">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Bakiye İşlemleri</h3>
          <div class="box-tools pull-right">

          </div>
        </div>
        <div class="box-body" style="min-height:400px;">
		
<?php
if(!empty($_GET['islem'])){
if($_GET['islem']=='ara'){
$tarih1=$_POST['tarih1'];
$tarih2=$_POST['tarih2'];
$durum=$_POST['durum'];
}}else{
$tarih1=date("Y-m-d",strtotime("-7 Days"));
$tarih2=date("Y-m-d");
$durum='9';
}
?>


<form action="?islem=ara" method="post">
<div class="row">
<div class="col-md-4">
  
  <div class="row">
  <div class="col-sm-6"><span>Tarih Başlangıç</span><input type="date" class="form-control" name="tarih1" placeholder="Tarih" value="<?=$tarih1?>" ></div>
  <div class="col-sm-6"><span>Tarih Bitiş</span><input type="date" class="form-control" name="tarih2" placeholder="Tarih" value="<?=$tarih2?>" ></div>
  </div>
</div>
<div class="col-md-2">
  <span>Durumu</span>
  <select class="form-control" name="durum">
<option <?php echo $durum=='9' ? 'selected':'';?> value="9">Tümü</option>
<option <?php echo $durum=='1' ? 'selected':'';?> value="1">Başarılı</option>
<option <?php echo $durum=='0' ? 'selected':'';?> value="0">Bekliyor</option>
<option <?php echo $durum=='2' ? 'selected':'';?> value="2">Başarısız</option>
</select>
</div>
<div class="col-md-2">
<p style="margin-top:20px;"><button type="submit" class="btn btn-default" >Getir</button></p>
</div>

</div>
</form>




<?php
$query = $db->prepare("SELECT * FROM ucretler where tarih >= :tarih1 and tarih <= :tarih2 and (durum = :durum or :durum='9')  order by id desc");
$query->bindValue(':tarih1', $tarih1);
$query->bindValue(':tarih2', date("Y-m-d",strtotime($tarih2)+86400));
$query->bindValue(':durum', $durum);
$query->execute();
$verisay = $query->rowCount();
?>
<?php if($verisay == "0"){ ?>
<div class="alert alert-info" >Bakiyelerle ilgili işlemler olduğunda buradan takip edebilirsiniz.</div>
<?php }else{ ?>
<div class="table-responsive">
                           <table class="table table-striped" >
                              <thead>
                                 <tr class="active">
                                    <th class="text-left" style="width:120px">İşlem No</th>
                                    <th class="text-center" style="width:150px">Üye</th>
                                    <th>Açıklama</th>
                                    <th class="text-right" style="width:120px">Miktar</th>
                                    <th class="text-center" style="width:150px">Tarih</th>
									<th class="text-center" style="width:120px">Durum</th>
									<th class="text-center" style="width:140px"></th>
									
                                 </tr>
                              </thead>
                              <tbody>
<?php
while($row=$query->fetch(PDO::FETCH_ASSOC)) {
$bak = $db->prepare("SELECT * FROM uyeler WHERE id=:firmaid");
$bak->bindValue(':firmaid', $row['uyeid']);
$bak->execute();
if($bak->rowCount()){
$firma = $bak->fetch(PDO::FETCH_ASSOC);
$kisi=$firma['isim'];
$kisiid=$firma['id'];
}else{
$kisi="Üye Silindi!";
$kisiid=0;
}

if($row['durum']=='1'){
$renk="success";
$durum="Başarılı";
}else if($row['durum']=='0'){
$renk="warning";
$durum="Bekliyor";
}else if($row['durum']=='2'){
$renk="danger";
$durum="Başarısız";
}
?>
                                 <tr class="<?php echo $renk;?>">
                                    <td class="text-left"><?=$row['siparisno']?></td>
									<td class="text-center"><span class="uyebilgi" data-uyeid="<?=$kisiid?>" ><?=$kisi?></span></td>
                                    <td><?=$row['aciklama']?></td>
                                    <td class="text-right"><?=number_format($row['miktar'],2)?></td>
                                    <td class="text-center"><?php echo date('d.m.Y H:i',strtotime($row['tarih']));?></td>
                                    <td class="text-center"><?php echo $durum;?> </td>
									<td class="text-right">
									<?php if($row['durum']=='0' && strpos($row['aciklama'],'Banka Havalesi')!==false ){ ;?> 
									<a class="btn btn-success btn-sm" href="?havaleonayla=<?=$row['siparisno']?>"> Onayla </a>
									<?php } ?>
									<?php if($row['durum']=='0'){ ;?> 
									<a class="btn btn-danger btn-sm" href="?silid=<?=$row['siparisno']?>"> Sil </a>
									<?php } ?>
									</td>
                                 </tr>
<?php } ?>
                              </tbody>
                           </table>
</div>
<?php } ?>



        </div>
        <!-- /.box-body -->
        <div class="box-footer">
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->


</div>
</div>



    </section>
    <!----------------------------------------------- /.content ------------------------------------------------>
  </div>
  <!-- /.content-wrapper -->


<?php
include "alt.php";
?>




</body>
</html>