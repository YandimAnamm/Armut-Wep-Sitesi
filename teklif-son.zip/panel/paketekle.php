<?php
include "db.php";
include "kontrol.php";
$sayfa="Paket Ekle";
?>

<?php
if( isset($_GET['islem']) ){
if( $_GET['islem']=="kaydet" ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$yeni = $db->prepare("INSERT INTO paketler SET baslik = :baslik, altbaslik = :altbaslik, ozellikler = :ozellikler, ucret = :ucret, sure=:sure ");
$yeni->bindValue(':baslik', $_POST['baslik']);
$yeni->bindValue(':altbaslik', $_POST['altbaslik']);
$yeni->bindValue(':ozellikler', implode(",",$_POST['ozellikler']));
$yeni->bindValue(':ucret', $_POST['ucret']);
$yeni->bindValue(':sure', $_POST['sure']);
$yeni->execute();

if($yeni){
    header("Location: paketyonet.php");
	exit();
}

}}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteadi?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>


</head>
<body class="hold-transition <?=$tema?> sidebar-mini">
<div class="wrapper">

<?php
include "ust.php";
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!---------------------------------------------- Main content --------------------------------------------->
    <section class="content container-fluid" style="min-height:600px;">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><a href="paketyonet.php"> Paketler </a> >> <?=$sayfa?></h3>
        </div>
        <div class="box-body" style="min-height:400px;">

<form action="?islem=kaydet" method="post" >

<div class="form-group">
<label>Paket Adı</label>
<input type="text" class="form-control" placeholder="" value="" name="baslik" required>
</div>

<div class="form-group">
<label>Paket Açıklama/Slogan</label>
<input type="text" class="form-control" placeholder="" value="" name="altbaslik" required>
</div>

<div class="row">
<div class="col-sm-6">
<div class="form-group">
<label>Paket Ücreti</label>
<input type="number" min="0" max="5000" class="form-control" placeholder="" value="" name="ucret" required>
</div>
</div><div class="col-sm-6">
<div class="form-group">
<label>Paket Süresi</label>
<select class="form-control" name="sure" required>
<option value="1">1 Ay</option>
<option value="2">2 Ay</option>
<option value="3">3 Ay</option>
<option value="4">4 Ay</option>
<option value="5">5 Ay</option>
<option value="6">6 Ay</option>
<option value="7">7 Ay</option>
<option value="8">8 Ay</option>
<option value="9">9 Ay</option>
<option value="10">10 Ay</option>
<option value="11">11 Ay</option>
<option value="12">1 Yıl</option>
</select>
</div>
</div>
</div>

<div class="form-group">
<label>Özellikler</label>
<br>
<?php
foreach($db->query("SELECT * FROM paketozellikleri order by id asc") as $row) {
?>
<label><input type="checkbox" name="ozellikler[]" value="<?=$row['ozellik']?>"> <?=$row['ozellik']?></label><br>
<?php } ?>


</div><br>

<div style="width:%100;text-align:center;">
<button type="submit" class="btn btn-success">Kaydet</button>
</div>





</form>                                    





        </div>
        <!-- /.box-body -->
        <div class="box-footer">
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->


    </section>
    <!----------------------------------------------- /.content ------------------------------------------------>
  </div>
  <!-- /.content-wrapper -->


<?php
include "alt.php";
?>





</body>
</html>