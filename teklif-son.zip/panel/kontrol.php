<?php
if(isset($_COOKIE["uyeid"])){
$uyeid=$_COOKIE["uyeid"];
$q = $db->prepare("SELECT * FROM uyeler WHERE id=:id");
$q->bindValue(':id', $uyeid);
$q->execute();
if($q->rowCount()){
$uyebilgi = $q->fetch(PDO::FETCH_ASSOC);
$isim=$uyebilgi['isim'];
$uyeid=$uyebilgi['id'];
$yetki=$uyebilgi['yetki'];
}else{
header("location: /");
exit();
}
}else{
header("location: /");
exit();
}

if($yetki!=='99' && $yetki!=='98' && $yetki!=='11'){
header("location: /");
exit();
}

?>
