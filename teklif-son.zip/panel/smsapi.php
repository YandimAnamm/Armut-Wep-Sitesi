<?php
header('Content-Type: text/html; charset=utf-8');

// Bu değişkenleri sisteminizde gerçek değerlerle doldurun
$MUSTERİNO        = $smsmusterino;     
$KULLANICIADI      = $smskullaniciadi; 
$SIFRE             = $smssifre;        
$ORGINATOR         = $smsbaslik;       
$smsmesaj          = isset($smsmesaj) ? $smsmesaj : '';
$smsnumaralar      = isset($smsnumaralar) ? $smsnumaralar : '';

// Yeni API bilgileri
$api_id  = 'fa129487108492b31a19523e';
$api_key = 'bb97756508ea24dd0397848c';
$sender  = $ORGINATOR; 

// Mesaj tipi ve içerik türü
$message_type = 'normal';       
$message_content_type = 'bilgi';

// Mesaj içindeki '\n' ifadelerini gerçek alt satıra dönüştürelim
$smsmesaj = str_replace('\n', "\n", $smsmesaj);

// Numaraları diziye dönüştürelim
$phones = array_map('trim', explode(',', $smsnumaralar));

// Yeni API endpoint
$api_url = 'https://api.vatansms.net/api/v1/1toN';

// Parametreleri hazırlayalım
$params = [
    'api_id'              => $api_id,
    'api_key'             => $api_key,
    'sender'              => $sender,
    'message_type'        => $message_type,
    'message'             => $smsmesaj,
    'message_content_type'=> $message_content_type,
    'phones'              => $phones
];

// cURL ile isteği gönderelim
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $api_url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

$response = curl_exec($ch);
$err = curl_error($ch);
curl_close($ch);

// Yanıtı göstermeye gerek yok
?>
