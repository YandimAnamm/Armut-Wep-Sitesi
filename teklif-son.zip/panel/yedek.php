<?php
include "db.php";
include "kontrol.php";
$sayfa="Yedekleme";

if($yetki!=='99'){
header("location: index.php");
exit();
}

if(isset($_GET['sil'])){

unlink($_GET['sil']);

header("Location: ?success=Dosya Silindi.");
exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteadi?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>


</head>
<body class="hold-transition <?=$tema?> sidebar-mini">
<div class="wrapper">

<?php
include "ust.php";
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!---------------------------------------------- Main content --------------------------------------------->
    <section class="content container-fluid" style="min-height:600px;">

<div class="row">
<div class="col-sm-6">

<div class="box" style="max-width:700px">
	<div class="box-header with-border">
		<i class="fa fa-database"></i> Veritabanı Yedekleri
		<span class="pull-right">
			<button type="button" class="btn btn-success btn-sm vtyedekle" ><i class="fa fa-plus"></i> Veritabanı Yedekle</a>
		</span>
	</div>
    <div class="box-body">


<ul class="list-group">
<?php
foreach(scandir('DBBackupRestore/temp', 1) as $file){
if($file!=='.' && $file!=='..'){
?>
<li class="list-group-item list-group-item-action"><a href="<?="DBBackupRestore/temp/".$file?>" download><?=$file?></a> <span class="pull-right text-bold"><?=gecenzaman(filectime("DBBackupRestore/temp/".$file));?>  <a class="fa fa-trash-o text-danger" href="?sil=<?="DBBackupRestore/temp/".$file?>"></a></span></li>
<?php 
}}
?>
</ul>

</div>
<div class="overlay" id="yukleniyor1" style="display:none">
    <i class="fa fa-refresh fa-spin"></i>
</div>
</div>

</div><div class="col-sm-6">

<div class="box" style="max-width:700px">
	<div class="box-header with-border">
		<i class="fa fa-database"></i> Tam Yedekler
		<span class="pull-right">
			<button type="button" class="btn btn-success btn-sm tamyedekle" ><i class="fa fa-plus"></i> Tam Yedekle</a>
		</span>
	</div>
    <div class="box-body">


<ul class="list-group">
<?php
foreach(scandir('DBBackupRestore/fullyedek', 1) as $file){
if($file!=='.' && $file!=='..'){
?>
<li class="list-group-item list-group-item-action"><a href="<?="DBBackupRestore/fullyedek/".$file?>" download><?=$file?></a> <span class="pull-right text-bold"><?=gecenzaman(filectime("DBBackupRestore/fullyedek/".$file));?>  <a class="fa fa-trash-o text-danger" href="?sil=<?="DBBackupRestore/fullyedek/".$file?>"></a></span></li>
<?php 
}}
?>
</ul>
</div>
<div class="overlay" id="yukleniyor2" style="display:none">
    <i class="fa fa-refresh fa-spin"></i>
</div>
</div>

</div>
</div>



    </section>
    <!----------------------------------------------- /.content ------------------------------------------------>
  </div>
  <!-- /.content-wrapper -->


<?php
include "alt.php";
?>



<!--js-->
<script>
$(".vtyedekle").click(function(){
$("#yukleniyor1").show();
	$.get("yedekal.php",function(data){
		location.href="?";
	});
});

$(".tamyedekle").click(function(){
$("#yukleniyor2").show();
	$.get("yedekaltam.php",function(data){
		location.href="?";
	});
});
</script>






</body>
</html>