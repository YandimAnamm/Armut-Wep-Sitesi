<?php
include "db.php";
include "kontrol.php";
$sayfa="Üst Menüler";
?>

<?php
if( isset($_GET['silid']) ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$ids="";
foreach($db->query("SELECT * FROM ustmenu where id=".$_GET['silid']." order by id asc") as $row1) {
$ids=$ids.",".$row1['id'];
foreach($db->query("SELECT * FROM ustmenu where ustkat=".$row1['id']." order by id asc") as $row2) {
$ids=$ids.",".$row2['id'];
foreach($db->query("SELECT * FROM ustmenu where ustkat=".$row2['id']." order by id asc") as $row3) {
$ids=$ids.",".$row3['id'];
foreach($db->query("SELECT * FROM ustmenu where ustkat=".$row3['id']." order by id asc") as $row4) {
$ids=$ids.",".$row4['id'];
}
}
}
}

$ids=ltrim($ids,",");
$q = $db->prepare("DELETE FROM ustmenu WHERE id in (".$ids.") ");
$q->execute();

header("Location: ?");
exit();
}
?>



<?php
if( isset($_GET['islem']) ){
if( $_GET['islem']=="kaydet" ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$yeni = $db->prepare("INSERT INTO ustmenu SET baslik = :baslik, ustkat = :ustkat, link = :link ");
$yeni->bindValue(':baslik', $_POST['baslik']);
$yeni->bindValue(':ustkat', $_POST['ustkat']);
$yeni->bindValue(':link', $_POST['link']);
$yeni->execute();

if($yeni){
    header("Location: ?");
	exit();
}

}}
?>


<?php
if( isset($_GET['islem']) ){
if( $_GET['islem']=="guncelle" ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$katbilgi = $db->query("SELECT * FROM ustmenu where id=".$_POST['id']." ")->fetch(PDO::FETCH_ASSOC);

$yeni = $db->prepare("UPDATE urunler SET ".$_POST['katno']." = :yenibaslik where ".$_POST['katno']."=:baslik");
$yeni->bindValue(':yenibaslik', $_POST['baslik']);
$yeni->bindValue(':baslik', $katbilgi['baslik']);
$yeni->execute();

$yeni = $db->prepare("UPDATE ustmenu SET baslik = :baslik, link = :link where id=:id");
$yeni->bindValue(':baslik', $_POST['baslik']);
$yeni->bindValue(':link', $_POST['link']);
$yeni->bindValue(':id', $_POST['id']);
$yeni->execute();

if($yeni){
    header("Location: ?");
	exit();
}

}}
?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteadi?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>

<style>
.pointer{cursor:pointer}
</style>

</head>
<body class="hold-transition <?=$tema?> sidebar-mini">
<div class="wrapper">

<?php
include "ust.php";
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!---------------------------------------------- Main content --------------------------------------------->
    <section class="content container-fluid" style="min-height:600px;">

<div class="row">
<div class="col-md-6">
      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><?=$sayfa?></h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-success btn-sm altmenuekle" data-ustkat="0"><i class="fa fa-plus"></i> Yeni Kayıt</button>
          </div>
        </div>
        <div class="box-body" style="min-height:400px;">

<div class="table-responsive">
<table class="table menuler" >
<tbody class="ui-sortable" id="sirala">
<?php
$query = $db->prepare("SELECT * FROM ustmenu where ustkat=0 order by sira asc, id asc");
$query->execute();
$verisay = $query->rowCount();
?>
<?php if($verisay == "0"){ ?>
<div class="alert alert-warning">Kayıt Yok!</div>
<?php }else{ ?>
<?php
while($row=$query->fetch(PDO::FETCH_ASSOC)) {
?>
<tr class="success" id="eleman-<?=$row['id']?>">
<td class="text-center sortable ui-sortable-handle"><i class="fa fa-arrows"></i></td>
<td class="text-left text-bold pointer togglemenu" id="ustmenu<?=$row['id']?>"><?=$row['baslik']?></td>
<td class="text-left"><?=$row['link']?></td>
<td class="text-right">
<button type="button" class="btn btn-primary btn-sm altmenuekle" data-ustkat="<?=$row['id']?>" ><i class="fa fa-plus"></i></button>
<button type="button" class="btn btn-warning btn-sm guncelle" data-id="<?=$row['id']?>" data-baslik="<?=$row['baslik']?>" data-link="<?=$row['link']?>" data-katno="kat1"><i class="fa fa-edit"></i></button> 
<button type="button" class="btn btn-danger btn-sm sil" data-id="<?=$row['id']?>" data-katno="kat1"><i class="fa fa-trash-o"></i></button>
</td>
</tr>

<!-------------------KAT 2---------------------------->
<?php
$query2 = $db->prepare("SELECT * FROM ustmenu where ustkat=".$row['id']." order by baslik asc");
$query2->execute();
while($row2=$query2->fetch(PDO::FETCH_ASSOC)) {
?>
<tr class="info ustmenu<?=$row['id']?>" id="eleman-<?=$row2['id']?>" style="display:none;">
<td class="text-center sortable ui-sortable-handle"><i class="fa fa-arrows"></i></td>
<td class="text-left text-bold pointer togglemenu" id="ustmenu<?=$row2['id']?>"><?=$row2['baslik']?></td>
<td class="text-left"><?=$row2['link']?></td>
<td class="text-right">
<button type="button" class="btn btn-primary btn-sm altmenuekle" data-ustkat="<?=$row2['id']?>" ><i class="fa fa-plus"></i></button>
<button type="button" class="btn btn-warning btn-sm guncelle" data-id="<?=$row2['id']?>" data-baslik="<?=$row2['baslik']?>" data-link="<?=$row2['link']?>" data-katno="kat2"><i class="fa fa-edit"></i></button> 
<button type="button" class="btn btn-danger btn-sm sil"  data-id="<?=$row2['id']?>" data-katno="kat2"><i class="fa fa-trash-o"></i></button> 
</td>
</tr>

<!-------------------KAT 3---------------------------->
<?php
$query3 = $db->prepare("SELECT * FROM ustmenu where ustkat=".$row2['id']." order by baslik asc");
$query3->execute();
while($row3=$query3->fetch(PDO::FETCH_ASSOC)) {
?>
<tr class="warning ustmenu<?=$row2['id']?>" id="eleman-<?=$row3['id']?>" style="display:none;">
<td class="text-center sortable ui-sortable-handle"><i class="fa fa-arrows"></i></td>
<td class="text-left text-bold pointer togglemenu" id="ustmenu<?=$row3['id']?>"><?=$row3['baslik']?></td>
<td class="text-left"><?=$row3['link']?></td>
<td class="text-right">
<button type="button" class="btn btn-primary btn-sm altmenuekle" data-ustkat="<?=$row3['id']?>" ><i class="fa fa-plus"></i></button>
<button type="button" class="btn btn-warning btn-sm guncelle" data-id="<?=$row3['id']?>" data-baslik="<?=$row3['baslik']?>" data-link="<?=$row3['link']?>" data-katno="kat3"><i class="fa fa-edit"></i></button> 
<button type="button" class="btn btn-danger btn-sm sil"  data-id="<?=$row3['id']?>" data-katno="kat3"><i class="fa fa-trash-o"></i></button> 
</td>
</tr>

<!-------------------KAT 4---------------------------->
<?php
$query4 = $db->prepare("SELECT * FROM ustmenu where ustkat=".$row3['id']." order by baslik asc");
$query4->execute();
while($row4=$query4->fetch(PDO::FETCH_ASSOC)) {
?>
<tr class="danger ustmenu<?=$row3['id']?>" id="eleman-<?=$row4['id']?>" style="display:none;">
<td class="text-center sortable ui-sortable-handle"><i class="fa fa-arrows"></i></td>
<td class="text-left text-bold pointer togglemenu" id="ustmenu<?=$row4['id']?>"><?=$row4['baslik']?></td>
<td class="text-left"><?=$row4['link']?></td>
<td class="text-right">
<button type="button" class="btn btn-warning btn-sm guncelle" data-id="<?=$row4['id']?>" data-baslik="<?=$row4['baslik']?>" data-link="<?=$row4['link']?>" data-katno="kat4"><i class="fa fa-edit"></i></button> 
<button type="button" class="btn btn-danger btn-sm sil"  data-id="<?=$row4['id']?>" data-katno="kat4"><i class="fa fa-trash-o"></i></button> 
</td>
</tr>
<?php } ?>
<!-------------------KAT 4 X---------------------------->

<?php } ?>
<!-------------------KAT 3 X---------------------------->

<?php } ?>
<!-------------------KAT 2 X---------------------------->



<?php } ?>
<?php } ?>
</tbody>
</table>


<div class="modal fade" id="yeni">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Menü Ekle</h4>
      </div>
	  <form action="?islem=kaydet" method="post">
      <div class="modal-body">

<div class="form-group">
<input type="hidden" class="ustkat" name="ustkat" value="" required>
<label>Menü Başlığı</label>
<input type="text" class="form-control seflink" id="birinci" placeholder="Menü Başlığı" value="" name="baslik" required>
</div>

<div class="form-group">
<label>Menü Linki</label>
<input type="text" class="form-control birinci" placeholder="Seflink" value="" name="link" required>
</div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Kapat</button>
        <button type="submit" class="btn btn-success" ><i class="fa fa-save"></i> Kaydet</button>
      </div>
	  </form>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<div class="modal fade" id="guncelle">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Menü Güncelle</h4>
      </div>
	  <form action="?islem=guncelle" method="post">
      <div class="modal-body">
<input type="hidden" name="id" required>
<input type="hidden" name="katno" required>
<div class="form-group">
<label>Menü Başlığı</label>
<input type="text" class="form-control seflink" id="ikinci" placeholder="Menü Başlığı" name="baslik" required>
</div>

<div class="form-group">
<label>Menü Linki</label>
<input type="text" class="form-control ikinci" placeholder="Seflink" name="link" required>
</div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Kapat</button>
        <button type="submit" class="btn btn-success" ><i class="fa fa-save"></i> Değişiklikleri Kaydet</button>
      </div>
	  </form>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->






        </div>
        <!-- /.box-body -->
        <div class="box-footer">
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->
</div>
</div>


    </section>
    <!----------------------------------------------- /.content ------------------------------------------------>
  </div>
  <!-- /.content-wrapper -->


<?php
include "alt.php";
?>

<script>
$(".menuler .togglemenu").each(function(){
	var menuid=$(this).attr("id");
	i=0;
	$(".menuler ."+menuid).each(function(){
	i=i+1;
	if(i=="1"){
	$("#"+menuid).prepend("<i class=\"fa fa-arrow-down\"></i> ");
	}
	});
});

$(".altmenuekle").click(function(){
	var ustkat=$(this).attr("data-ustkat");
	$(".ustkat").val(ustkat);
	$("#yeni").modal("show");
});

$(".guncelle").click(function(){
	var id=$(this).attr("data-id");
	var baslik=$(this).attr("data-baslik");
	var link=$(this).attr("data-link");
	var katno=$(this).attr("data-katno");
	$("#guncelle input[name=id]").val(id);
	$("#guncelle input[name=baslik]").val(baslik);
	$("#guncelle input[name=link]").val(link);
	$("#guncelle input[name=katno]").val(katno);
	$("#guncelle").modal("show");
});

$(".sil").click(function(){
	if (confirm("Bu Menü ve altındaki menüler silinecektir. \r\n Onaylıyor musunuz?") == true) {
	var id=$(this).attr("data-id");
	location.href="?silid="+id
	}
});
</script>



<script src="bower_components/jquery/dist/jquery-ui.min.js"></script>
<script src="bower_components/jquery/dist/jquery.ui.touch-punch.min.js"></script>
<script>
$(document).ready(function () {
    $("#sirala").sortable({  // sıralamanın yapılacağı ul nin id si
        revert: true, // sürükle bırak yaparken yavaş ve estetik olması için
        handle: ".sortable",
        stop: function (event, ui) {
            var data = $(this).sortable('serialize'); // sıralama verisini oluşturuyoruz
            $.ajax({
                type: "POST", // post metodunu kullanıyoruz
                data: data, // data verisini yolluyoruz
                url: "verisirala.php?tablo=ustmenu",  // post edeceğimiz sayfamızın yolu
                success: function (data) { // veri işlendikten sonra sonucu alıyoruz.
                    if (data.trim() == "success") {
                        //$('span').text(" Sonuç: Başarılı"); 
                        // span da işlem sonucu başarılı ise belirtiyoruz
                    }
                    else {
                        alert("Demo Yetkileri Kısıtlıdır!");
                        // span da işlem sonucu başarısız ise belirtiyoruz
                    }
                }
            });
        }
    });
	$( "#sirali" ).disableSelection();
});
</script>

</body>
</html>