

<!DOCTYPE HTML>
<html lang="tr">
<body>

<form name="yukleme" method="post" action="index.php" enctype="multipart/form-data">
      <table border="0">
         <tr>
            <td>Dosya Seçiniz:</td>
            <td><input type="file" name="dosya"></td>
            <td><input type="submit" name="yukle" value="Yükle"></td>
         </tr>
      </table>
   </form>
 
<?php
function turkce($metin){
   $aranan=array("ç","Ç","ğ","Ğ","ı","İ","ö","Ö","ş","Ş","ü","Ü"," ");
   $yerine=array("c","c","g","g","i","i","o","o","s","s","u","u","_");
   return str_replace($aranan,$yerine,$metin);
}
 
if($_POST){
   $gecici_ad=$_FILES["dosya"]["tmp_name"];
   $kalici_yol_ad="resimler/".time()."-".turkce($_FILES["dosya"]["name"]);
 
   if ($_FILES["dosya"]["error"]) // hata oluştu ise
      echo "<font color='green'>Hata : ",$_FILES["dosya"]["error"],"</font>";
   else{
      if (file_exists($kalici_yol_ad)) // yüklenen dosya upload dizininde varsa
         echo "<font color='red'>Yazdığınız ad ile bir dosya zaten kayıtlıdır.</font>";
      else{
         if (move_uploaded_file($gecici_ad,$kalici_yol_ad)) // eğer dosya kaydedilirse
            echo "<font color='green'>Dosya başarı ile yüklendi.</font>";
         else
             echo "<font color='red'>Dosya yükleme başarısız.</font>";
      }
   }
}
?>












<?php
  
function list_files($dir)
{
    if(is_dir($dir))
    {
        if($handle = opendir($dir))
        {
            while(($file = readdir($handle)) !== false)
            {
                if($file != "." && $file != ".." && $file != "Thumbs.db"/*Bazı sinir bozucu windows dosyaları.*/)
                {
				?>
<div style="float:left;width:200px;margin:30px;height:130px;">
<a href="#" onClick="window.opener.document.getElementsByClassName('cke_dialog_ui_input_text')[1].value='/panel/upload/<?=$dir.$file?>';self.close();">
<img src="<?=$dir.$file?>" style="width:100%;height:130px;">
</a>
</div>

				<?php
                }
            }
            closedir($handle);
        }
    }
}
 
    list_files("resimler/"); // Listelenecek olan klasörün yolunu gönderelim.
?>








</body>
</html>