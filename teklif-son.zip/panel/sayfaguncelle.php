<?php
include "db.php";
include "kontrol.php";
$sayfa="Sayfa Güncelle";
?>

<?php
if( isset($_GET['islem']) ){
if( $_GET['islem']=="kaydet" ){
if($yetki=='11'){
header("Location: sayfalar.php?error=Demo yetkileri kısıtlıdır!");
exit();
}
$yeni = $db->prepare("UPDATE sayfalar SET baslik = :baslik, link = :link, icerik = :icerik, ozet = :ozet, kapak = :kapak, galeri = :galeri, durum = :durum, etiket = :etiket where id= :id  ");
$yeni->bindValue(':baslik', $_POST['baslik']);
$yeni->bindValue(':link', $_POST['link']);
$yeni->bindValue(':icerik', $_POST['icerik']);
$yeni->bindValue(':ozet', $_POST['ozet']);
$yeni->bindValue(':kapak', @$_POST['kapak']);
$yeni->bindValue(':galeri', $_POST['galeri']);
$yeni->bindValue(':durum', $_POST['durum']);
$yeni->bindValue(':etiket', $_POST['etiket']);
$yeni->bindValue(':id', $_GET['id']);
$yeni->execute();

if($yeni){
    header("Location: sayfalar.php");
}

}
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteadi?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){    
 $("#birinci").on("keyup focusout", function() {
    str = $(this).val();
    str =replaceSpecialChars(str);
    str=str.toLowerCase();
    str =str.replace( /\s\s+/g, ' ' ).replace(/[^a-z0-9\s]/gi, '').replace(/[^\w]/ig, "-");
   function replaceSpecialChars(str) {
            var specialChars = [["ş", "s"], ["ğ", "g"], ["ü", "u"], ["ı", "i"],["_", "-"],
                                ["ö", "o"], ["Ş", "S"], ["Ğ", "G"], ["Ç", "C"], ["ç", "c"],
                                ["Ü", "U"], ["İ", "I"], ["Ö", "O"], ["ş", "s"]];
            for (var i = 0; i < specialChars.length; i++) {
                str = str.replace(eval("/" + specialChars[i][0] + "/ig"), specialChars[i][1]);
            }
            return str;
        }
    $("#ikinci").val(str);
 });    
});
</script>


</head>
<body class="hold-transition <?=$tema?> sidebar-mini">
<div class="wrapper">

<?php
include "ust.php";
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!---------------------------------------------- Main content --------------------------------------------->
    <section class="content container-fluid" style="min-height:600px;">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><a href="sayfalar.php"> Sayfalar </a> > <?=$sayfa?></h3>
        </div>
        <div class="box-body" style="min-height:400px;">
		
<?php
$bak = $db->prepare("SELECT * FROM sayfalar WHERE id=:id");
$bak->bindValue(':id', $_GET['id']);
$bak->execute();
if($bak->rowCount()){
$veri = $bak->fetch(PDO::FETCH_ASSOC);
$galeri=$veri['galeri'];
$kapak=$veri['kapak'];
?>

<form action="?islem=kaydet&id=<?=$_GET['id']?>" method="post" >

<div class="form-group">
<label>Başlık</label>
<input type="text" class="form-control" id="birinci" placeholder="" value="<?=$veri['baslik']?>" name="baslik" required>
</div>

<div class="form-group">
<label>Seflink</label>
<input type="text" class="form-control" id="ikinci" placeholder="" value="<?=$veri['link']?>" name="link" required>
</div>

<div class="form-group">
<label>İçerik Özeti</label>
<input type="text" class="form-control" placeholder="" value="<?=$veri['ozet']?>" name="ozet" >
</div>

<div class="form-group">
<label>İçerik</label>
<textarea id="editor1" name="icerik"  style="width:100%; min-height:500px;"><?=$veri['icerik']?></textarea>
</div><br>

<div class="form-group">
<div class="progress" id="upload-progress" style="display:none">
  <div class="progress-bar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>
</div>

<div id="yuklenenler"></div>
<input type="hidden" value="<?=$veri['galeri']?>" name="galeri">
<br>
<p><button type="button" class="btn btn-success filebuton">Fotoğraf Ekle</button> </p>
<input class="image-upload" style="visibility : hidden;" data-id="<?=$veri['galeri']?>" id="uploadImage3" type="file" name="images[1]" accept="image/jpeg,image/jpg" multiple>
</div><br>


<div class="form-group">
<label>Etiket</label>
<input type="text" class="form-control" placeholder="blog,yazı" value="<?=$veri['etiket']?>" name="etiket">
</div>

<div class="form-group">
<label>Yayında</label>
<select name="durum" class="form-control">
<option value="Evet">Evet</option>
<option <?php if($veri['durum']=="Hayır"){ ?>selected<?php } ?> value="Hayır">Hayır</option>
</select>
</div>


<div style="width:%100;text-align:center;">
<button type="submit" class="btn btn-success">Kaydet</button>
</div>


</form>                                    


<?php } ?>


        </div>
        <!-- /.box-body -->
        <div class="box-footer">
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->


    </section>
    <!----------------------------------------------- /.content ------------------------------------------------>
  </div>
  <!-- /.content-wrapper -->


<?php
include "alt.php";
?>



<script src="bower_components/ckeditor/ckeditor.js"></script>
<script>
$(function () {
    CKEDITOR.replace('editor1');
});
</script>



    <script type="text/javascript" src="base64/js/exif.js"></script>
    <script type="text/javascript" src="base64/js/ImageUploader.js"></script>
    <script type="text/javascript" src="base64/js/custom.js"></script>

<script type="text/javascript">
$("#yuklenenler").load("yuklenenler.php?dosyano=<?=$galeri?>&kapak=<?=$kapak?>");
$(".filebuton").click(function() {
    $(".image-upload").click();
})
</script>



</body>
</html>