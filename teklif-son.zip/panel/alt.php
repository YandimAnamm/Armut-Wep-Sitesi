

								<!-- Üye bilgi Çek -->
                                <div id="uyebilgicek" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="vcenter" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
												<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                                <h5 class="modal-title" >Üye Bilgileri</h5>
                                            </div>
                                            <div class="modal-body">
                                                
                                            </div>
                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>
                                <!-- /.modal -->




  <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      Copyright &copy; 2020 
    </div>
    <!-- Default to the left -->
    <strong><a href="http://www.yahyaaydin.com.tr">YA</a></strong>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
  <div style="margin:10px;">
<div id="layout-skins-list">
                  <a href="#" data-skin="skin-blue" class="btn btn-primary btn-xs"><i class="fa fa-eye"></i> skin-blue</a>
				  <a href="#" data-skin="skin-blue-light" class="btn btn-primary btn-xs"><i class="fa fa-eye"></i> skin-blue-light</a>
				  <a href="#" data-skin="skin-yellow" class="btn btn-warning btn-xs"><i class="fa fa-eye"></i> skin-yellow</a>
				  <a href="#" data-skin="skin-yellow-light" class="btn btn-warning btn-xs"><i class="fa fa-eye"></i> skin-yellow-light</a>
				  <a href="#" data-skin="skin-green" class="btn btn-success btn-xs"><i class="fa fa-eye"></i> skin-green</a>
				  <a href="#" data-skin="skin-green-light" class="btn btn-success btn-xs"><i class="fa fa-eye"></i> skin-green-light</a>
				  <a href="#" data-skin="skin-purple" class="btn bg-purple btn-xs"><i class="fa fa-eye"></i> skin-purple</a>
				  <a href="#" data-skin="skin-purple-light" class="btn bg-purple btn-xs"><i class="fa fa-eye"></i> skin-purple-light</a>
				  <a href="#" data-skin="skin-red" class="btn btn-danger btn-xs"><i class="fa fa-eye"></i> skin-red</a>
				  <a href="#" data-skin="skin-red-light" class="btn btn-danger btn-xs"><i class="fa fa-eye"></i> skin-red-light</a>
				  <a href="#" data-skin="skin-black" class="btn bg-black btn-xs"><i class="fa fa-eye"></i> skin-black</a>
				  <a href="#" data-skin="skin-black-light" class="btn bg-black btn-xs"><i class="fa fa-eye"></i> skin-black-light</a></td>
</div>

  </div>
  </aside>
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- REQUIRED JS SCRIPTS -->
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- Skin -->
<script>
  var currentSkin = '<?=$tema?>'
  $('#layout-skins-list [data-skin]').click(function (e) {
    e.preventDefault()
    var skinName = $(this).data('skin')
    $('body').removeClass(currentSkin)
    $('body').addClass(skinName)
    currentSkin = skinName
	$.get("tema.php?tema="+skinName);
  });
</script>
<!-- REQUIRED JS SCRIPTS X-->

<link href="bower_components/sweetalert2/sweetalert2.min.css" rel="stylesheet" />
<script src="bower_components/sweetalert2/sweetalert2.min.js"></script>


<script>
$(document).ready(function() {
$("#bildirimler").load("bildirimler.php");
});
setInterval(function() {
	$("#bildirimler").load('bildirimler.php');
}, 20000);

$('#bildirimler').click(function () {
$.get("bildirimler.php?bild=sustur");
});
</script>

<?php if(isset($_GET['success'])){ ?>
<script>
Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: '<?=$_GET['success']?>',
  showConfirmButton: false,
  timer: 2000
})
</script>
<?php } ?>

<?php if(isset($_GET['error'])){ ?>
<script>
Swal.fire({
  position: 'top-end',
  icon: 'error',
  title: '<?=$_GET['error']?>',
  showConfirmButton: false,
  timer: 4000
})
</script>
<?php } ?>


<script>
$('.togglemenu').click(function () {
var menuid=$(this).attr("id");
$('.'+menuid).toggle("slow");
});
</script>


<script>
$(".uyebilgi").css("cursor","pointer");
$(document).on("click",".uyebilgi", function() {
var uyeid=$(this).attr("data-uyeid");
	$.post("uyebilgicek.php",{uyeid:uyeid}, function(veri){
	$("#uyebilgicek .modal-body").html(veri);
	$("#uyebilgicek").modal('show');
	});
});
</script>


<?php
$db = null;
ob_end_flush();
?>

