<?php
include "db.php";
include "kontrol.php";
$sayfa="Üyeler";

if($yetki!=='99'){
header("location: index.php");
exit();
}
?>

<?php
if(isset($_GET['silid'])){

$query = $db->prepare("DELETE FROM bildirimler WHERE uyeid = :id");
$delete = $query->execute(array(
'id' => $_GET['silid']
));

$query = $db->prepare("DELETE FROM mesajlar WHERE kimdenid=:id or kimeid=:id ");
$delete = $query->execute(array(
'id' => $_GET['silid']
));

$query = $db->prepare("DELETE FROM hizmetler WHERE uyeid = :id");
$delete = $query->execute(array(
'id' => $_GET['silid']
));

$query = $db->prepare("DELETE FROM talepler WHERE uyeid = :id");
$delete = $query->execute(array(
'id' => $_GET['silid']
));

$query = $db->prepare("DELETE FROM teklifler WHERE uyeid = :id");
$delete = $query->execute(array(
'id' => $_GET['silid']
));

$query = $db->prepare("DELETE FROM ucretler WHERE uyeid = :id");
$delete = $query->execute(array(
'id' => $_GET['silid']
));

$query = $db->prepare("DELETE FROM uyeler WHERE id = :id");
$delete = $query->execute(array(
'id' => $_GET['silid']
));

header("Location: ?");
exit();
}

if(isset($_GET['uyetipi'])){
$uyetipi=$_GET['uyetipi'];
}else{
$uyetipi='';
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteadi?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>


</head>
<body class="hold-transition <?=$tema?> sidebar-mini">
<div class="wrapper">

<?php
include "ust.php";
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!---------------------------------------------- Main content --------------------------------------------->
    <section class="content container-fluid" style="min-height:600px;">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><?=$sayfa?></h3>
          <div class="box-tools pull-right">
            <a href="uyeekle.php" class="btn btn-success btn-sm" ><i class="fa fa-plus"></i> Yeni Kayıt</a>
          </div>
        </div>
        <div class="box-body" style="min-height:400px;">

<form action="?">
<div class="input-group input-group-sm" style="max-width:300px;margin-bottom:20px;">
    <select class="form-control" name="uyetipi">
	<option value="">Tüm Üyeler</option>
	<option value="Firma" <?php echo $uyetipi=='Firma' ? 'selected':'';?> >Firma</option>
	<option value="Müşteri" <?php echo $uyetipi=='Müşteri' ? 'selected':'';?> >Müşteri</option>
	</select>
    <span class="input-group-btn">
        <button type="submit" class="btn btn-info btn-flat">Filtrele</button>
    </span>
</div>
</form>



<?php
$q1 = $db->prepare("SELECT * FROM uyeler where uyetipi like '%".$uyetipi."%' ");
$q1->execute();

$toplamveri = $q1->rowCount();
if($toplamveri=='0'){
?>
<div class="alert alert-warning">Kayıt Bulunamadı...</div>
<?php }else{ ?>
<p><?=$toplamveri?> kayıt listelendi...</p>

<div class="table-responsive">
<table class="table table-striped">
<tr class="active">
<td class="text-bold text-left">Üye</td>
<td class="text-bold text-center" width="200">Yetki</td>
<td class="text-bold text-center" width="200">Son Giriş</td>
<td class="text-bold text-center" width="250"></td>
</tr>
<?php
$goster = 20;
$toplamSayfa = ceil($toplamveri / $goster);
if(!empty($_GET["s"])){
$sayfa = $_GET["s"];
}else{
$sayfa = 1;
}
if($sayfa < 1){ 
$sayfa = 1;
}
if($sayfa > $toplamSayfa){
$sayfa = $toplamSayfa;
}
$limit = ($sayfa - 1) * $goster;

$q = $db->prepare("SELECT * FROM uyeler where uyetipi like '%".$uyetipi."%' order by isim asc limit $limit, $goster");
$q->execute();
$toplamverim = $q->rowCount();

while($row=$q->fetch(PDO::FETCH_ASSOC)) {
?>
<tr>
<td class="text-left"><span class="uyebilgi" data-uyeid="<?=$row['id']?>" ><?=$row['isim']?></span></td>
<td class="text-center"><?php if($row['yetki']=='99'){ echo 'Admin';}else if($row['yetki']=='98'){ echo 'Editör';}else if($row['yetki']=='11'){ echo 'Demo';}else{ echo 'Normal';} ?></td>
<td class="text-center"><?=date('d.m.Y H:i',strtotime($row['songiris']))?></td>
<td class="text-right">
<?php if($row['uyetipi']=='Firma'){ ?>
<a  class="btn btn-info btn-sm" href="uyecari.php?id=<?=$row['id']?>"><i class="fa fa-money"></i> Bakiye (<?=$row['bakiye']?>)</a> 
<?php } ?>
<a href="uyeguncelle.php?id=<?=$row['id']?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a> 
<?php if($row['yetki']!=="99"){ ?>
<a href="?silid=<?=$row['id']?>" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a>
<?php } ?>
</td>
</tr>
<?php } ?>
</table>
</div>

<ul class="pagination">
<?php 
$nokta=0;
for($i = 1; $i<=$toplamSayfa;$i++)
{
?>
<?php
if($i=='1' || ($i>=$sayfa-3 && $i<=$sayfa+3) || $i==$toplamSayfa ){
$nokta=0;
?>
<?php 
if($i==$sayfa){
?>
<li class="paginate_button active" ><a href="#"><?php echo $i;?></a></li>
<?php 
}else{ 
?>
<li class="paginate_button"><a href="?uyetipi=<?=$uyetipi?>&s=<?php echo $i;?>"><?php echo $i;?></a></li>
<?php } ?>
<?php 
}else{
if($nokta===0){
$nokta=1;
?>
<li class="paginate_button"><a href="#">...</a></li>
<?php }}} ?>
</ul>
</div>
<?php } ?>








        </div>
        <!-- /.box-body -->
        <div class="box-footer">
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->


    </section>
    <!----------------------------------------------- /.content ------------------------------------------------>
  </div>
  <!-- /.content-wrapper -->


<?php
include "alt.php";
?>






</body>
</html>