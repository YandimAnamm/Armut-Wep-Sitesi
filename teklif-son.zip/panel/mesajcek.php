<?php
include "db.php";
include "kontrol.php";
$sayfa="Mesajlar";
?>

<?php
if( isset($_GET['kisiid']) ){
$bak = $db->prepare("SELECT * FROM uyeler WHERE id=:id");
$bak->bindValue(':id', $_GET['kisiid']);
$bak->execute();
if($bak->rowCount()){
$veri = $bak->fetch(PDO::FETCH_ASSOC);
$kisiid=$veri['id'];
$kisi=$veri['isim'];
}
}
?>

<?php
if(isset($_GET['islem']) ){
if($_GET['islem']=='dosyagonder' && $kisiid!==$uyeid ){
 if ( 0 < $_FILES['file']['error'] ) {
        echo 'Error: ' . $_FILES['file']['error'] . '<br>';
    }
    else {
        move_uploaded_file($_FILES['file']['tmp_name'], 'upload/' . $_FILES['file']['name']);
$ekler='/upload/' . $_FILES['file']['name'];
$icerik='<a href=\'/upload/' . $_FILES['file']['name'].'\' class=\'btn btn-primary btn-sm btn-flat\' download><i class=\'fa fa-download\'></i> ' . $_FILES['file']['name'].'</a>';
$yeni = $db->prepare("INSERT INTO mesajlar SET kimden = :kimden, kimdenid = :kimdenid, kime = :kime, kimeid = :kimeid, icerik = :icerik, ekler = :ekler, okundu = 'Hayır', sil1 = 'Hayır', sil2 = 'Hayır' ");
$yeni->bindValue(':kimden', $isim );
$yeni->bindValue(':kimdenid', $uyeid );
$yeni->bindValue(':kime', $kisi );
$yeni->bindValue(':kimeid', $kisiid );
$yeni->bindValue(':icerik', $icerik);
$yeni->bindValue(':ekler', $ekler);
$yeni->execute();

	echo "Dosya başarıyla gönderildi.";
    }
}
}
?>



<?php
if(isset($_GET['mesaj']) ){
if($_GET['mesaj']=='yaz' && $kisiid!==$uyeid ){

$yeni = $db->prepare("INSERT INTO mesajlar SET kimden = :kimden, kimdenid = :kimdenid, kime = :kime, kimeid = :kimeid, icerik = :icerik, okundu = 'Hayır', sil1 = 'Hayır', sil2 = 'Hayır' ");
$yeni->bindValue(':kimden', $isim );
$yeni->bindValue(':kimdenid', $uyeid );
$yeni->bindValue(':kime', $kisi );
$yeni->bindValue(':kimeid', $kisiid );
$yeni->bindValue(':icerik', $_POST['icerik']);
$yeni->execute();
}
}


if(isset($_GET['mesaj']) ){
if($_GET['mesaj']=='sil'){
$yeni = $db->prepare("UPDATE mesajlar SET sil1 = 'Evet' where kimdenid='$uyeid' and kimeid='$kisiid' ");
$yeni->execute();
$yeni = $db->prepare("UPDATE mesajlar SET sil2 = 'Evet' where kimdenid='$kisiid' and kimeid='$uyeid' ");
$yeni->execute();
}
}


if(isset($_GET['islem']) ){
if($_GET['islem']=='bak'){
$bak = $db->prepare("SELECT * FROM mesajlar WHERE kimdenid='$kisiid' and kimeid='$uyeid' and okundu='Hayır' ");
$bak->execute();
$mesajsay=$bak->rowCount();
echo $mesajsay;
}
}
?>



<?php 
if(isset($_GET['islem']) ){
if($_GET['islem']=='oku'){
?>

<div style="height:100px;"></div>
<?php
foreach($db->query("SELECT * FROM mesajlar WHERE (kimdenid='$uyeid' and kimeid='$kisiid' and sil1<>'Evet') or (kimdenid='$kisiid' and kimeid='$uyeid' and sil2<>'Evet') ") as $row) {
?>


                    <!-- Message to the right -->
                    <div class="direct-chat-msg <?php if($uyeid==$row['kimdenid']){ ?>right<?php } ?>">
                      <div class="direct-chat-info clearfix">
                        <span class="direct-chat-name pull-<?php if($uyeid==$row['kimdenid']){ ?>right<?php }else{ ?>left<?php } ?>"> <?php echo $row['kimden'];?> </span>
                        <span class="direct-chat-timestamp pull-<?php if($uyeid==$row['kimdenid']){ ?>left<?php }else{ ?>right<?php } ?>"> <?php echo date('d.m.Y H:i', strtotime($row['tarih']));?> <?php if($row['okundu']=='Evet' && $uyeid==$row['kimdenid']){ ?> <i class="glyphicon glyphicon-ok" data-toggle="tooltip" title="Okundu"> </i> <?php } ?></span>
                      </div>
                      <!-- /.direct-chat-info -->
                      <img class="direct-chat-img" src="<?php echo $row['kimdenresim'];?>" onerror="this.src='dist/img/noperson.png'" alt="<?php echo $row['kimden'];?>"><!-- /.direct-chat-img -->
                      <div class="direct-chat-text">
                        <?php echo $row['icerik'];?>
                      </div>
                      <!-- /.direct-chat-text -->
                    </div>
                    <!-- /.direct-chat-msg -->



<?php
}

$yeni = $db->prepare("UPDATE mesajlar SET okundu = 'Evet' where kimdenid='$kisiid' and kimeid='$uyeid' ");
$yeni->execute();

?>
<script>$("#mesajcek").scrollTop(1000000);</script>
<?php
}}
?>


