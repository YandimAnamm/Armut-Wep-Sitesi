<html>
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AYDIN WEB</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>


</head>
<body>

<div class="form-group">
<div class="progress" id="upload-progress" style="display:none">
  <div class="progress-bar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>
</div>

<div id="yuklenenler"></div>
<input type="hidden" value="0" name="galeri">
<br>
<p><button type="button" class="btn btn-success filebuton">Fotoğraf Ekle</button> </p>
<input class="image-upload" style="visibility : hidden;" data-id="0" id="uploadImage3" type="file" name="images[1]" accept="image/jpeg,image/jpg" multiple>
</div><br>






























    <script type="text/javascript" src="base64/js/exif.js"></script>
    <script type="text/javascript" src="base64/js/ImageUploader.js"></script>
    <script type="text/javascript" src="base64/js/custom.js"></script>

<script type="text/javascript">
$(".filebuton").click(function() {
    $(".image-upload").click();
})
</script>


</body>
</html>