<?php
include "db.php";
include "kontrol.php";
$sayfa="Mesajlar";
?>

<?php
if( isset($_GET['kisiid']) ){
$bak = $db->prepare("SELECT * FROM uyeler WHERE id=:id");
$bak->bindValue(':id', $_GET['kisiid']);
$bak->execute();
if($bak->rowCount()){
$veri = $bak->fetch(PDO::FETCH_ASSOC);
$kisiid=$veri['id'];
$kisi=$veri['isim'];
}
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteadi?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>

<!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="bower_components/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">

</head>
<body class="hold-transition <?=$tema?> sidebar-mini">
<div class="wrapper">

<?php
include "ust.php";
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1><?=$sayfa?> <small> </small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> </a></li>
		<!--<li><a href="/"> üstsayfa </a></li>-->
		<li class="active"><?=$sayfa?></li>
      </ol>
    </section>

    <!---------------------------------------------- Main content --------------------------------------------->
    <section class="content container-fluid" style="min-height:600px;">

<div class="row">
<div class="col-md-4">
<!-- quick email widget -->
          <div class="box box-info">
            <div class="box-header">
              <i class="fa fa-bars"></i>
              <h3 class="box-title">Kişiler</h3>
              <!-- tools box -->
              <div class="pull-right box-tools">
                <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip"
                        title="Remove">
                  <i class="fa fa-times"></i></button>
              </div>
              <!-- /. tools -->
            </div>
            <div class="box-body">
			
<p><b>Kişiler</b></p>
<table class="table" >
<?php
foreach($db->query('SELECT * FROM uyeler where id<>'.$uyeid.' ') as $row) {
$bak = $db->prepare('SELECT * FROM mesajlar WHERE kimdenid='.$row['id'].' and kimeid='.$uyeid.' and okundu="Hayır" ');
$bak->execute();
$mesajsay=$bak->rowCount();
?>
<tr>
<td class="text-bold text-left"><a href="?kisiid=<?=$row['id']?>"><?=$row['isim']?></a> <?php if($mesajsay>0){?><span class="badge bg-red pull-right"><?=$mesajsay?></span><?php } ?></td>
</tr>
<?php } ?>
</table>

            </div>
          </div>
</div>
<?php if( isset($_GET['kisiid']) ){ ?>
<div class="col-md-8">


              <!-- DIRECT CHAT -->
              <div class="box box-default direct-chat direct-chat-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Siz & <?php echo $kisi; ?></h3>

                  <div class="box-tools pull-right">
                    <a href="<?=$url?>" class="btn btn-info btn-xs" data-toggle="tooltip" title="Kişiler" ><i class="fa fa-reply"></i></a>
                    <button type="button" class="btn btn-danger btn-xs sil" data-toggle="tooltip" title="Konuşmayı Sil"><i class="glyphicon glyphicon-trash"></i></button>
                  </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                  <!-- Conversations are loaded here -->
                  <div class="direct-chat-messages" id="mesajcek">




                  </div>
                  <!--/.direct-chat-messages-->
				  <p id="ekler" style="margin-left:20px;font-size:16px;color:red;font-weight:600;"></p>
                </div>
                <!-- /.box-body -->
                <div class="box-footer">


		    <div class="input-group">
						   <span class="input-group-btn">
                            <button type="button" class="btn btn-default btn-flat" id="yukle"><i class="fa fa-paperclip"></i></button>
                          </span>
                      <input type="text" name="icerik" id="icerik" placeholder="Mesajınız..." class="form-control" autofocus="on" autocomplete="off">
                          <span class="input-group-btn">
                            <button type="button" class="btn btn-info btn-flat" id="gonder">Gönder</button>
                          </span>
                    </div>

                </div>
                <!-- /.box-footer-->
              </div>
              <!--/.direct-chat -->
<?php } ?>

<div style="min-height:300px;"></div>



</div>
</div>





    </section>
    <!----------------------------------------------- /.content ------------------------------------------------>
  </div>
  <!-- /.content-wrapper -->


<?php
include "alt.php";
?>




<?php if(!empty($kisiid)){ ?>

<script>
$("#mesajcek").load("/mesajcek.php?islem=oku&kisiid=<?php echo $kisiid; ?>");
$("#mesajcek").scrollTop(1000000);
$(document).ready(function() {
setInterval(function() {
		$.post("/mesajcek.php?kisiid=<?php echo $kisiid; ?>&islem=bak",{islem: "bak"},function (baktim) {
			if(baktim.trim()!=="0"){
            $("#mesajcek").load("mesajcek.php?islem=oku&kisiid=<?php echo $kisiid; ?>");
			$("#mesajcek").scrollTop(1000000);
			}
        });
}, 3000);

$('.sil').click(function () {
	$.get("/mesajcek.php?islem=oku&kisiid=<?php echo $kisiid; ?>&mesaj=sil",function (gelen) {
	$("#mesajcek").load("/mesajcek.php?islem=oku&kisiid=<?php echo $kisiid; ?>");
	});
});

});
</script>



<script type="text/javascript">
var mesajsay = 1 ;
function mesajcek() {
		var icerik=$("#icerik").val();
		if(!!icerik){
			$("#gonder").prop('disabled', true);
		    $("#icerik").prop('disabled', true);
	        $.post("/mesajcek.php?islem=oku&kisiid=<?php echo $kisiid; ?>&mesaj=yaz", {
                icerik: icerik
            }, function (cevap) {
			mesajsay = mesajsay+1;
            $("#mesajcek").html(cevap);
			$("#icerik").val("");
			$("#icerik").prop('disabled', false);
			$("#icerik").focus();
			$("#gonder").prop('disabled', false);
			
            });
		}
}

$('#icerik').keypress(function (e) {
 var key = e.which;
 if(key == 13)
  {
	mesajcek();
  }
});

var mesajsay = 0 ;
$('#gonder').click(function () {
$("#gonder").prop('disabled', true);
	mesajcek();
});

</script>


<input type="file" id="dosya" style="opacity:0">
<script>
$('#yukle').on('click', function() {
$('#dosya').click();
});
$('#dosya').change(function (){
$('#ekler').html("Yükleniyor...");  
    var file_data = $(this).prop('files')[0];   
    var form_data = new FormData();                  
    form_data.append('file', file_data);  
    $.ajax({
        url: '/mesajcek.php?islem=dosyagonder&kisiid=<?php echo $kisiid; ?>', // point to server-side PHP script 
        dataType: 'text',  // what to expect back from the PHP script, if anything
        cache: false,
        contentType: false,
        processData: false,
        data: form_data,                         
        type: 'post',
        success: function(cevap){
            $('#ekler').html(cevap);
			$("#mesajcek").load("/mesajcek.php?islem=oku&kisiid=<?php echo $kisiid; ?>");
        }
     });
});
</script>







<?php } ?>








</body>
</html>