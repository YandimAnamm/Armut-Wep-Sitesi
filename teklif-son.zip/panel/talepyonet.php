<?php
include "db.php";
include "kontrol.php";
$sayfa="Talepler";
?>

<?php
if( isset($_GET['silid']) ){

if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}

$query = $db->prepare("DELETE FROM talepler WHERE talepno = :talepno");
$delete = $query->execute(array(
'talepno' => $_GET['silid']
));

$query = $db->prepare("DELETE FROM teklifler WHERE talepno = :talepno");
$delete = $query->execute(array(
'talepno' => $_GET['silid']
));

foreach($db->query('SELECT * FROM galeri where dosyano='.$_GET['silid'].' ') as $row) {
unlink($_SERVER['DOCUMENT_ROOT'] . $row['adres']);
}

header("Location: ?success=Talep silindi.");
exit();
}
?>

<?php
if( isset($_GET['yorumonayla']) ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}

$talepno=$_GET['yorumonayla'];
$rs = $db->prepare("UPDATE talepler SET yorumonay=1 WHERE talepno=:talepno");
$rs->bindValue(':talepno', $talepno);
$rs->execute();

header("Location: ?success=Değerlendirme onaylandı.");
exit();
}

if( isset($_GET['yorumonaykaldir']) ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$talepno=$_GET['yorumonaykaldir'];
$rs = $db->prepare("UPDATE talepler SET yorumonay=0 WHERE talepno=:talepno");
$rs->bindValue(':talepno', $talepno);
$rs->execute();

header("Location: ?success=Değerlendirme onayı geri alındı.");
exit();
}


if( isset($_GET['onaylaid']) ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$talepno=$_GET['onaylaid'];
$rs = $db->prepare("UPDATE talepler SET durum='Teklifler Bekleniyor' WHERE talepno = :talepno");
$rs->bindValue(':talepno', $talepno);
$rs->execute();

$alicilar="";
$iletilensayisi=0;
$rs1 = $db->prepare("SELECT * FROM talepler where talepno = :talepno ");
$rs1->bindValue(':talepno', $talepno);
$rs1->execute();
$rs1say = $rs1->rowCount();
if($rs1say){
$talepbilgi=$rs1->fetch(PDO::FETCH_ASSOC);
$kat2 = $db->query("SELECT * FROM kategoriler where id=".$talepbilgi['katid']." ")->fetch(PDO::FETCH_ASSOC);

if($talepbilgi['ozelid']=='0'){
$rs2 = $db->prepare("SELECT * FROM hizmetler where katid=:katid and (bolge like '%Tüm Şehirler%' or bolge like :bolge1 or bolge like :bolge2) order by id asc");
$rs2->bindValue(':katid', $talepbilgi['katid']);
$rs2->bindValue(':bolge1', '%'.$talepbilgi['il'].'/'.$talepbilgi['ilce'].'%');
$rs2->bindValue(':bolge2', '%'.$talepbilgi['il'].'/*'.'%');
$rs2->execute();
$rs2say = $rs2->rowCount();
if($rs2say){
while($rs2veri=$rs2->fetch(PDO::FETCH_ASSOC)) {
$kisiid=$rs2veri['uyeid'];
$alicilar=$alicilar.",".$kisiid;
$iletilensayisi=$iletilensayisi+1;
}
$alicilar=ltrim($alicilar,",");
$siteicimesaj="<a href=\"/talep/".$talepno."\">Size uygun iş yayınlandı</a>";
$smsmesaj="Size uygun iş yayınlandı. Teklif vermek için tıklayın. ".$siteurl."/talep/".$talepno;
$epostakonu="Size uygun yeni iş var #".$talepno;
$epostamesaj="<p>Size uygun iş talebi yayınlandı. Taleple ilgili işlemler için hemen ziyaret edin. </p><p><a href=\"".$siteurl."/talep/".$talepno."\" style='text-decoration:none;display:inline-block;color:#ffffff;background-color:#583;border-radius:3px;border:1px solid #472;padding:8px;'>TALEBİ İNCELE</a></p>";
$epostamesaj=$epostamesaj."<div style='max-width: 500px;background: #daffe3;border: 1px solid #ddd;padding: 5px 15px;border-radius: 10px;font-size: 14px;'>
<h3>Talep Detayları</h3>
<p><b>Kategori: </b> ".$kat2['baslik']."</p>";
if(!empty($talepbilgi['secim'])){
$epostamesaj=$epostamesaj."<p>";
$secimler=json_decode($talepbilgi['secim'],true);
foreach($secimler as $key=>$value){ 
$epostamesaj=$epostamesaj."<p><b>".$secimler[$key]['soru'].": </b>";
foreach($secimler[$key]['secenek'] as $key2=>$value2){ $epostamesaj=$epostamesaj.$value2." "; }
$epostamesaj=$epostamesaj."</p>";
}
}
$epostamesaj=$epostamesaj."<p><b>Açıklama: </b>".$talepbilgi['detaylar']."</p>";
$epostamesaj=$epostamesaj."<p><b>Bölge: </b>".$talepbilgi['il']."/".$talepbilgi['ilce']."</p>";
$epostamesaj=$epostamesaj."<p><b>Hizmetin istendiği tarih: </b>";
if($talepbilgi['nezaman']=='Belli bir zaman (3 hafta içinde)'){
$epostamesaj=$epostamesaj.date('d.m.Y',$talepbilgi['tarih'])." ".$talepbilgi['saat'];
}else{
$epostamesaj=$epostamesaj.$talepbilgi['nezaman'];
}
$epostamesaj=$epostamesaj."</p>";
$epostamesaj=$epostamesaj."</div>";

include "bildirimgonder.php";

}

}else{

$kisiid=$talepbilgi['ozelid'];
$alicilar=$kisiid;
$iletilensayisi=1;

$siteicimesaj="<a href=\"/talep/".$talepno."\">Size özel iş yayınlandı</a>";
$smsmesaj="Size özel iş talebi yayınlandı. Teklif vermek için tıklayın. ".$siteurl."/talep/".$talepno;
$epostakonu="Size Özel İş Talebi Yayınlandı #".$talepno;
$epostamesaj="<p>Ziyaretçimizin profil sayfanızı inceleyerek oluşturduğu ve Sadece sizin teklif verebilceğiniz özel bir talep yayınlandı. </p><p><a href=\"".$siteurl."/talep/".$talepno."\">".$talepno." Nolu Talebe teklif vermek için hemen tıklayın.</a></p>";
$epostamesaj=$epostamesaj."<br><br><div style='background: #eef1ed;border:1px solid #ddd;padding:5px;'>
<h3>Talep Detayları</h3>
<p><b>Kategori: </b> ".$kat2['baslik']."</p>";
if(!empty($talepbilgi['secim'])){
$epostamesaj=$epostamesaj."<p><b>DETAYLAR</b>";
$secimler=json_decode($talepbilgi['secim'],true);
foreach($secimler as $key=>$value){ 
$epostamesaj=$epostamesaj."<p><b>".$secimler[$key]['soru'].": </b>";
foreach($secimler[$key]['secenek'] as $key2=>$value2){ $epostamesaj=$epostamesaj.$value2." "; }
$epostamesaj=$epostamesaj."</p>";
}
}
$epostamesaj=$epostamesaj."<p><b>Açıklama: </b>".$talepbilgi['detaylar']."</p>";
$epostamesaj=$epostamesaj."<p><b>Bölge: </b>".$talepbilgi['il']."/".$talepbilgi['ilce']."</p>";
$epostamesaj=$epostamesaj."<p><b>Hizmetin istendiği tarih: </b>";
if($talepbilgi['nezaman']=='Belli bir zaman (3 hafta içinde)'){
$epostamesaj=$epostamesaj.date('d.m.Y',$talepbilgi['tarih'])." ".$talepbilgi['saat'];
}else{
$epostamesaj=$epostamesaj.$talepbilgi['nezaman'];
}
$epostamesaj=$epostamesaj."</p>";
$epostamesaj=$epostamesaj."</div>";

include "bildirimgonder.php";

}
}



if( isset($_GET['kisiid']) ){
$kisiid=$_GET['kisiid'];
$kisibak = $db->prepare("SELECT * FROM uyeler WHERE id=:kisiid ");
$kisibak->bindValue(':kisiid', $kisiid);
$kisibak->execute();
if($kisibak->rowCount()){
$kisibilgi = $kisibak->fetch(PDO::FETCH_ASSOC);
$kisiid=$kisibilgi['id'];
$kisitel=$kisibilgi['tel'];
}

$siteicimesaj="<a href=\"/talep/".$talepno."\">".$talepno." nolu talebiniz yayınlandı</a>";
$smsmesaj="Talebiniz yayınlandı. Gelen teklifleri size bildireceğiz. ".$siteurl."/talep/".$talepno;
$smsnumaralar=$kisitel;
$bildir = $db->prepare("INSERT INTO bildirimler (uyeid, mesaj) VALUES ('".$kisiid."','".$siteicimesaj."') ");
$bildir->execute();
include "smsapi.php";
}


header("Location: ?success=Talep, ".$iletilensayisi." üyeye iletildi.");
}
?>

<?php
if( isset($_GET['onaykaldirid']) ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$query = $db->prepare("UPDATE talepler SET durum='Onay Bekliyor' WHERE talepno = :talepno");
$delete = $query->execute(array(
'talepno' => $_GET['onaykaldirid']
));

header("Location: ?");
}
?>

<?php
if( isset($_GET['gerialid']) ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$query = $db->prepare("UPDATE talepler SET durum='Teklifler Bekleniyor', kazananid=0, kazanantarih='', kazananteklif=0 WHERE talepno = :talepno");
$delete = $query->execute(array(
'talepno' => $_GET['gerialid']
));

$query = $db->prepare("UPDATE teklifler SET durum='Devam Ediyor' WHERE talepno = :talepno");
$delete = $query->execute(array(
'talepno' => $_GET['gerialid']
));

header("Location: ?");
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteadi?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>


</head>
<body class="hold-transition <?=$tema?> sidebar-mini">
<div class="wrapper">

<?php
include "ust.php";
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!---------------------------------------------- Main content --------------------------------------------->
    <section class="content container-fluid" style="min-height:600px;">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><?=$sayfa?></h3>
          <div class="box-tools pull-right">
            
          </div>
        </div>
        <div class="box-body" style="min-height:400px;">

<?php if(isset($_GET['success'])){ ?>
<div class="alert alert-info"><?=$_GET['success']?></div>
<?php } ?>
		
<?php
if(!empty($_GET['islem'])){
if($_GET['islem']=='ara'){
$tarih1=$_POST['tarih1'];
$tarih2=$_POST['tarih2'];
$durum=$_POST['durum'];
}}else{
$tarih1=date("Y-m-d",strtotime("-7 Days"));
$tarih2=date("Y-m-d");
$durum='Onay Bekliyor';
}
?>


<form action="?islem=ara" method="post">
<div class="row">
<div class="col-md-4">
  
  <div class="row">
  <div class="col-sm-6"><span>Tarih Başlangıç</span><input type="date" class="form-control" name="tarih1" placeholder="Tarih" value="<?=$tarih1?>" ></div>
  <div class="col-sm-6"><span>Tarih Bitiş</span><input type="date" class="form-control" name="tarih2" placeholder="Tarih" value="<?=$tarih2?>" ></div>
  </div>
</div>
<div class="col-md-2">
  <span>Durumu</span>
  <select class="form-control" name="durum">
<option <?php echo $durum=='Onay Bekliyor' ? 'selected':'';?> value="Onay Bekliyor">Onay Bekliyor</option>
<option <?php echo $durum=='Teklifler Bekleniyor' ? 'selected':'';?> value="Teklifler Bekleniyor">Teklifler Bekleniyor</option>
<option <?php echo $durum=='İş Verildi' ? 'selected':'';?> value="İş Verildi">İş Verildi</option>
<option <?php echo $durum=='İş Tamamlandı' ? 'selected':'';?> value="İş Tamamlandı">İş Tamamlandı</option>
</select>
</div>
<div class="col-md-2">
<p style="margin-top:20px;"><button type="submit" class="btn btn-default" >Getir</button></p>
</div>

</div>
</form>



<?php
$query = $db->prepare("SELECT * FROM talepler where olusturma >= :tarih1 and olusturma <= :tarih2 and durum=:durum order by id desc");
$query->bindValue(':tarih1', $tarih1);
$query->bindValue(':tarih2', date("Y-m-d",strtotime($tarih2)+86400));
$query->bindValue(':durum', $durum);
$query->execute();
$verisay = $query->rowCount();
?>
<?php if($verisay == "0"){ ?>
<div class="alert alert-warning">Henüz talep oluşturulmadı!</div>
<?php }else{ ?>
						<div class="table-responsive">
                           <table class="table" style="margin-bottom:100px">
                              <thead>
                                 <tr class="active">
                                    <th>Talep</th>
                                    <th>Ne Zaman</th>
                                    <th>Nerede</th>
									<th>Talep Sahibi</th>
                                    <th>Oluşturma</th>
                                    <th>Durum</th>
									<th></th>
									
                                 </tr>
                              </thead>
                              <tbody>
<?php
while($row=$query->fetch(PDO::FETCH_ASSOC)) {
$baktim = $db->query("SELECT * FROM uyeler where id=".$row['uyeid']." ")->fetch(PDO::FETCH_ASSOC);
$kat2 = $db->query("SELECT * FROM kategoriler where id=".$row['katid']." ")->fetch(PDO::FETCH_ASSOC);
?>
                                 <tr>
                                    <td>
									<a href="/talep/<?=$row['talepno']?>" target="_blank"><b><?=$row['talepno']?></b> <?=$kat2['baslik']?></a>
									<?php 
									if($row['ozelid']>0){ 
									$ozelbak = $db->query("SELECT * FROM uyeler where id=".$row['ozelid']." ")->fetch(PDO::FETCH_ASSOC);
									
									?><br>
									<span class="text-bold text-danger">Özel Talep (<span class="uyebilgi" data-uyeid="<?=$ozelbak['id']?>" ><?=$ozelbak['isim']?></span>)</span>
									<?php } ?>
									</td>
									<td><?php if($row['nezaman']=='Belli bir zaman (3 hafta içinde)'){ ?> <?php echo date('d.m.Y',$row['tarih']);?> <?=$row['saat']?> <?php }else{?> <?=$row['nezaman']?> <?php } ?></td>
                                    <td><?=$row['ilce']?>/<?=$row['il']?></td>
                                    <td><span class="uyebilgi" data-uyeid="<?=$baktim['id']?>" ><?=$baktim['isim']?></span></td>
                                    <td><?php echo date('d.m.Y H:i',strtotime($row['olusturma']));?></td>
                                    <td><span class="<?php echo $row['durum']=='İş Verildi' ? 'text-success':'';?>"><?=$row['durum']?></span>
<?php if($row['yorum']!=='' && $row['yorumonay']=='0'){ ?>
<br><b>Değerlendirme Onayı Bekliyor</b>
<?php } ?>
									</td>
									<td class="text-right">
<button type="button" class="btn btn-info talepdetay" data-talepno="<?=$row['talepno']?>" >Detaylar</button>
<div class="btn-group">
  <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">İşlem <span class="caret"></span></button>
  <ul class="dropdown-menu dropdown-menu-right">
<?php if($row['durum']=='Onay Bekliyor'){ ?>
	<li><a href="?onaylaid=<?=$row['talepno']?>&kisiid=<?=$row['uyeid']?>" onclick="return confirm('Onaylamak istiyor musunuz?')"><i class="fa fa-check"></i> Onayla</a></li>
	<li role="separator" class="divider"></li>
<?php }else if($row['durum']=='Teklifler Bekleniyor'){ ?>
	<li><a href="?onaylaid=<?=$row['talepno']?>" onclick="return confirm('Tekrar yayınlamak istiyor musunuz?')"><i class="fa fa-repeat"></i> Tekrar Yayınla</a></li>
	<li><a href="?onaykaldirid=<?=$row['talepno']?>" onclick="return confirm('Onayı kaldırmak istiyor musunuz?')"><i class="fa fa-check"></i> Onayı Kaldır</a></li>
	<li role="separator" class="divider"></li>
	<li><a href="?silid=<?=$row['talepno']?>" onclick="return confirm('Silmek istiyor musunuz?')"><i class="fa fa-trash-o"></i> Sil</a></li>
<?php }else if($row['durum']=='İş Verildi'){ ?>
	<li><a href="?gerialid=<?=$row['talepno']?>" onclick="return confirm('Verilen işi geri almak istiyor musunuz?')"><i class="fa fa-reply"></i> Geri Al</a></li>
<?php }else if($row['durum']=='İş Tamamlandı'){ ?>
	<?php if($row['yorumonay']=='0'){ ?>
	<li><a href="?yorumonayla=<?=$row['talepno']?>" ><i class="fa fa-check"></i> Değerlendirme Onayla</a></li>
	<?php }else{ ?>
	<li><a href="?yorumonaykaldir=<?=$row['talepno']?>" ><i class="fa fa-repeat"></i> Değerlendirme Onayı Geri Al</a></li>
	<?php } ?>
<?php } ?>
	<li><a href="?silid=<?=$row['talepno']?>" onclick="return confirm('Silmek istiyor musunuz?')"><i class="fa fa-trash-o"></i> Sil</a></li>

  </ul>
</div>

									</td>
                                 </tr>
<?php } ?>
                              </tbody>
                           </table>
                        </div>
<?php } ?>






<div class="modal fade" id="taleppopup" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Talep Detayları</h4>
      </div>
      <div class="modal-body">
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->









        </div><!-- /.box-body -->
      </div><!-- /.box -->


    </section>
    <!----------------------------------------------- /.content ------------------------------------------------>
  </div>
  <!-- /.content-wrapper -->


<?php
include "alt.php";
?>



<script>
$('.talepdetay').click(function () {
var talepno=$(this).attr("data-talepno");
	$.get("talepdetaycek.php?talepno="+talepno , function(data){
		$('#taleppopup .modal-body').html(data);
		$('#taleppopup').modal("show");
	});
});
</script>





</body>
</html>