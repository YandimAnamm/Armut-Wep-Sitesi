<?php
include "db.php";
include "kontrol.php";
?>


<?php
if(!empty($_POST['uyeid'])){
$q1 = $db->prepare("SELECT * FROM uyeler WHERE id=:uyeid");
$q1->bindValue(':uyeid', $_POST['uyeid']);
$q1->execute();
$q11 = $q1->fetch(PDO::FETCH_ASSOC);
if($q11){
$talepsay = $db->query("SELECT count(id) FROM talepler where uyeid=".$q11['id']." ")->fetchColumn();
$teklifsay = $db->query("SELECT count(id) FROM teklifler WHERE uyeid=".$q11['id']." ")->fetchColumn();
$kteklifsay = $db->query("SELECT count(id) FROM teklifler WHERE uyeid=".$q11['id']." and durum='Başarılı' ")->fetchColumn();
?>
		  <div class="box box-widget widget-user-2">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-yellow">
              <div class="widget-user-image">
                <img src="<?=$q11['resim']?>" onerror="this.src='dist/img/noperson.png'"  class="img-circle" >
              </div>
              <!-- /.widget-user-image -->
              <h3 class="widget-user-username"><?=$q11['isim']?></h3>
			  <?php if($yetki=='99'){ ?>
              <h5 class="widget-user-desc"><?=$q11['eposta']?><br><?=$q11['tel']?></h5>
			  <?php } ?>
            </div>
            <div class="box-footer no-padding">
              <ul class="nav nav-stacked">
                <li><a class="nav-link" href="javascript:;"> <i class="fa fa-clock-o"></i> Son Görülme <span class="badge bg-blue pull-right"><?=gecenzaman(strtotime($q11['songiris']))?></span></a></li>
                <li><a class="nav-link" href="javascript:;"> <i class="fa fa-comment"></i> Talepler <span class="badge bg-yellow pull-right"><?=$talepsay?></span></a></li>
                <li><a class="nav-link" href="javascript:;"> <i class="fa fa-money"></i> Teklifler <span class="badge bg-green pull-right"><?=$kteklifsay?>/<?=$teklifsay?></span></a></li>
              </ul>
            </div>
          </div>
		  

<?php }} ?>

