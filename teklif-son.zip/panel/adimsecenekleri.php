﻿<?php
include "db.php";
include "kontrol.php";
$sayfa="Adım Seçenekleri";
?>

<?php
$id=$_GET['id'];

if( isset($_GET['tsilid']) ){
if($yetki=='11'){
header("Location: ?id=".$id."&error=Demo yetkileri kısıtlıdır!");
exit();
}
$query = $db->prepare("DELETE FROM adimsecenekleri WHERE id = :id");
$delete = $query->execute(array(
'id' => $_GET['tsilid']
));
header("Location: ?id=".$id);
exit();
}

if( isset($_GET['islem']) ){
if( $_GET['islem']=="tkaydet" ){
if($yetki=='11'){
header("Location: ?id=".$id."&error=Demo yetkileri kısıtlıdır!");
exit();
}
if(isset($_POST['secenekler'])){
$secenekler=implode("|",$_POST['secenekler']);
}else{
$secenekler="";
}
$yeni = $db->prepare("INSERT INTO adimsecenekleri SET baslik = :baslik, secenekler = :secenekler, tur=:tur, katid=:katid ");
$yeni->bindValue(':baslik', $_POST['baslik']);
$yeni->bindValue(':secenekler', $secenekler);
$yeni->bindValue(':tur', $_POST['tur']);
$yeni->bindValue(':katid', $id);
$yeni->execute();

header("Location: ?id=".$id);
exit();
}}

if( isset($_GET['islem']) ){
if( $_GET['islem']=="tguncelle" ){
if($yetki=='11'){
header("Location: ?id=".$id."&error=Demo yetkileri kısıtlıdır!");
exit();
}
if(isset($_POST['secenekler'])){
$secenekler=implode("|",$_POST['secenekler']);
}else{
$secenekler="";
}
$yeni = $db->prepare("UPDATE adimsecenekleri SET baslik = :baslik, secenekler = :secenekler, tur=:tur where id=:id");
$yeni->bindValue(':baslik', $_POST['baslik']);
$yeni->bindValue(':secenekler', $secenekler);
$yeni->bindValue(':tur', $_POST['tur']);
$yeni->bindValue(':id', $_POST['id']);
$yeni->execute();

header("Location: ?id=".$id);
exit();
}}
?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteadi?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>

</head>
<body class="hold-transition <?=$tema?> sidebar-mini">
<div class="wrapper">
<?php
include "ust.php";
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!---------------------------------------------- Main content --------------------------------------------->
    <section class="content container-fluid" style="min-height:600px;">
	<div class="row">
	<div class="col-md-12">
      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><a href="kategoriler.php"><i class="fa fa-arrow-left"></i> Geri</a> << <?=$sayfa?></h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#yenipopup"><i class="fa fa-plus"></i> Yeni Kayıt</button>
          </div>
        </div>
        <div class="box-body" style="min-height:400px;">

<?php
$query = $db->prepare("SELECT * FROM adimsecenekleri where katid=:katid order by sira asc");
$query->bindValue(':katid', $id);
$query->execute();
$verisay = $query->rowCount();
?>
<?php if($verisay == "0"){ ?>
<div class="alert alert-warning">Kayıt Yok!</div>
<?php }else{ ?>
<table class="table">
<tr class="info text-bold">
<td>Sorular</td>
<td style="width:300px;" class="text-left">Seçenekler</td>
<td style="width:100px;"></td>
</tr>
<?php
while($row=$query->fetch(PDO::FETCH_ASSOC)) {
?>
<tr>
<td><b><?=$row['baslik']?></b></td>
<td class="text-left">
<?php 
foreach( explode("|",$row['secenekler']) as $key=>$value){ 
echo "<small>".$value."</small><br>";
} 
?>
</td>
<td class="text-right">
<button type="button" class="btn btn-warning btn-sm guncelle" data-id="<?=$row['id']?>" data-baslik="<?=$row['baslik']?>" data-secenekler="<?=$row['secenekler']?>" data-tur="<?=$row['tur']?>" ><i class="fa fa-edit"></i></button>
<a href="?tsilid=<?=$row['id']?>&id=<?=$id?>" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a>
</td>
</tr>
<?php } ?>
</table>

<?php } ?>





<div class="modal fade" id="yenipopup">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Yeni</h4>
      </div>
<form action="?islem=tkaydet&id=<?=$id?>" method="post" >
      <div class="modal-body">

<div class="form-group">
<label>Soru Başlığı</label>
<input type="text" class="form-control" placeholder="" name="baslik" required>
</div>

<div class="form-group">
<label>Seçenek Türü</label>
<select class="form-control tur" name="tur" required>
<option value="radio">Tek Seçim</option>
<option value="checkbox">Çoklu Seçim</option>
<option value="text">Kısa Açıklama</option>
<option value="textarea">Geniş Açıklama</option>
<option value="number">Sayı</option>
<option value="date">Tarih</option>
</select>
</div>

<div class="form-group">
<label>Seçenekler</label>
<div class="kaynak">
<div class="input-group" style="margin-bottom:10px">
<input type="text" class="form-control" name="secenekler[]" placeholder="" required>
<span class="input-group-btn"><button class="btn btn-danger cikar" type="button"><i class="fa fa-trash-o"></i></button></span>
</div>
</div>
<button type="button" class="btn btn-primary btn-xs ekle" ><i class="fa fa-plus"></i> Ekle</button> 
</div>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Vazgeç</button>
        <button type="submit" class="btn btn-primary">Kaydet</button>
      </div>
</form>                                    
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div class="modal fade" id="guncellepopup">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Güncelle</h4>
      </div>
<form action="?islem=tguncelle&id=<?=$id?>" method="post" >
      <div class="modal-body">

<input type="hidden" name="id" value="">

<div class="form-group">
<label>Soru Başlığı</label>
<input type="text" class="form-control" placeholder="" name="baslik" required>
</div>

<div class="form-group">
<label>Seçenekler</label>
<div class="kaynak">
</div>
<button type="button" class="btn btn-primary btn-xs ekle" ><i class="fa fa-plus"></i> Ekle</button>
</div>

<div class="form-group">
<label>Seçenek Türü</label>
<select class="form-control tur" name="tur" required>
<option value="radio">Tek Seçim</option>
<option value="checkbox">Çoklu Seçim</option>
<option value="text">Kısa Açıklama</option>
<option value="textarea">Geniş Açıklama</option>
<option value="number">Sayı</option>
<option value="date">Tarih</option>
</select>
</div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Vazgeç</button>
        <button type="submit" class="btn btn-primary">Kaydet</button>
      </div>
</form>                                    
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->



        </div>
      </div>
      <!-- /.box -->
	</div><!-- /.col -->
	</div><!-- /.row -->

    </section>
    <!----------------------------------------------- /.content ------------------------------------------------>
  </div>
  <!-- /.content-wrapper -->


<?php
include "alt.php";
?>

<script>
$(".tur").change(function() {
	if($(this).find("option:selected").val()=="text" || $(this).find("option:selected").val()=="number" || $(this).find("option:selected").val()=="date" || $(this).find("option:selected").val()=="textarea"){
		$(this).closest(".modal-body").find(".kaynak").html("");
	}
});

$(".ekle").click(function() {
$(this).closest(".modal").find(".kaynak").append('<div class="input-group" style="margin-bottom:10px"><input type="text" class="form-control" name="secenekler[]" placeholder="" required><span class="input-group-btn"><button class="btn btn-danger cikar" type="button"><i class="fa fa-trash-o"></i></button></span></div>');
});

$(document).on("click",".cikar",function() {
$(this).closest(".input-group").remove();
});
</script>

<script>
$(".guncelle").click(function() {
$("#guncellepopup input[name=id]").val($(this).attr("data-id"));
$("#guncellepopup input[name=baslik]").val($(this).attr("data-baslik"));
$("#guncellepopup select[name=tur]").val($(this).attr("data-tur"));

$("#guncellepopup .kaynak").html("");
var secenekler=$(this).attr("data-secenekler");
var array=secenekler.split("|");
$.each(array, function( i, val ) {
if(val!==''){
$("#guncellepopup .kaynak").append('<div class="input-group" style="margin-bottom:10px"><input type="text" class="form-control" name="secenekler[]" value="'+val+'" required><span class="input-group-btn"><button class="btn btn-danger cikar" type="button"><i class="fa fa-trash-o"></i></button></span></div>');
}
});

$("#guncellepopup").modal("show");
});
</script>



</body>
</html>