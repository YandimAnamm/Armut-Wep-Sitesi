<?php

$dbhost = "localhost"; //Veritaban�n bulundu�u host
$dbuser = "u9274148_admin"; //Veritaban� Kullan�c� Ad�
$dbpass = "3EHyG4wYKbIu"; //Veritaban� �ifresi
$dbdata = "u9274148_teklif"; //Veritaban� Ad�

try {
     $db = new PDO("mysql:host=".$dbhost.";port=3306;dbname=".$dbdata.";charset=utf8", $dbuser, $dbpass);
} catch ( PDOException $e ){
     print $e->getMessage();
}
?>