<?php
include "db.php";
include "kontrol.php";
$sayfa="Üye Güncelle";


$id=$_GET['id'];
$veri = $db->query("SELECT * FROM uyeler where id=".$id." ")->fetch(PDO::FETCH_ASSOC); 
$uyebakiye = $veri['bakiye'];

if( isset($_GET['islem']) ){
if($yetki=='11'){
header("Location: ?id=".$id."&error=Demo yetkileri kısıtlıdır!");
exit();
}


if( $_GET['islem']=="sil" ){

$rs = $db->query("SELECT * FROM ucretler where id=".$_GET['silid']." ")->fetch(PDO::FETCH_ASSOC); 
$yenibakiye = round(($uyebakiye - $rs['miktar']),2);
$song1 = $db->prepare("UPDATE uyeler SET bakiye = :yenibakiye where id=:uyeid ");
$song1->bindValue(':uyeid', $id);
$song1->bindValue(':yenibakiye', $yenibakiye);
$song1->execute();

$query = $db->prepare("DELETE FROM ucretler WHERE id = :id");
$delete = $query->execute(array(
'id' => $_GET['silid']
));
header("Location: ?id=".$id."&success=İşlem silindi.");
exit();
}

if( $_GET['islem']=="bakiyeyukle" ){

$miktar=$_POST['miktar'];

$yenibakiye = round(($uyebakiye + $miktar),2);
$song1 = $db->prepare("UPDATE uyeler SET bakiye = :yenibakiye where id=:uyeid ");
$song1->bindValue(':uyeid', $id);
$song1->bindValue(':yenibakiye', $yenibakiye);
$song1->execute();

$siparisno=$id.time();
$aciklama="Bakiye Yükleme (Yönetim)";
$yeni = $db->prepare("INSERT INTO ucretler SET uyeid = :uyeid, aciklama = :aciklama, miktar = :miktar, siparisno=:siparisno, durum='1' ");
$yeni->bindValue(':uyeid', $id);
$yeni->bindValue(':aciklama', $aciklama);
$yeni->bindValue(':miktar', $miktar);
$yeni->bindValue(':siparisno', $siparisno);
$yeni->execute();

header("Location: ?success=Bakiye yüklendi.&id=".$id);
exit();
}

if( $_GET['islem']=="paketyukle" ){


$rs = $db->prepare("SELECT * FROM paketler where id=:id ");
$rs->bindValue(':id', $_POST['paketid']);
$rs->execute();
$rssay = $rs->rowCount();
if($rssay){ 
$row = $rs->fetch(PDO::FETCH_ASSOC);
$paketucreti=$row['ucret'];

if($uyebakiye<$paketucreti && $paketucreti>0){
$fark=number_format(($paketucreti - $uyebakiye), 2, ',', '.');
header("Location: ?error=Bakiye Yetersiz. Bu paketi satın alabilmek için en az ".$fark." TL bakiye yüklemelisiniz!&id=".$id);
exit();
}else{

if($paketucreti>0){
$song1 = $db->prepare("UPDATE uyeler SET bakiye = bakiye - '".$paketucreti."' where id=:uyeid ");
$song1->bindValue(':uyeid', $id);
$song1->execute();
}else{
$rs1 = $db->query("SELECT count(id) FROM ucretler where uyeid=".$id." and miktar=0 ")->fetchColumn();
if($rs1>0){
header("Location: ?error=Ücretsiz paketten her üye bir kez yararlanabilir!&id=".$id);
exit();
}
}

$siparisno=$id.time();
$miktar=0-$paketucreti;
$aciklama=$row['baslik'].' - Paket Ücreti';
$para = $db->prepare("INSERT INTO ucretler SET uyeid = :uyeid, siparisno = :siparisno, miktar = :miktar, aciklama = :aciklama, paketid=:paketid, durum=1 ");
$para->bindValue(':uyeid', $id);
$para->bindValue(':siparisno', $siparisno);
$para->bindValue(':miktar', $miktar);
$para->bindValue(':aciklama', $aciklama);
$para->bindValue(':paketid', $_POST['paketid']);
$para->execute();

header("Location: ?success=Paket tanımlandı.&id=".$id);
exit();
}}
}
}
?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteadi?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>

</head>
<body class="hold-transition <?=$tema?> sidebar-mini">
<div class="wrapper">

<?php
include "ust.php";
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!---------------------------------------------- Main content --------------------------------------------->
    <section class="content container-fluid" style="min-height:600px;">


<div class="row">
<div class="col-md-8">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><a href="uyeler1.php">Hizmet Verenler</a> > Bakiye İşlemleri</h3>
        </div>
        <div class="box-body" style="min-height:400px;">

<h3>Mevcut Bakiye : <b><?=$veri['bakiye']?> TL</b></h3>
<br><br>

<div class="row">
<div class="col-md-6">

<form action="?islem=bakiyeyukle&id=<?=$id?>" method="post">
    <div class="input-group">
      <input type="number" step="0.01" class="form-control text-right" name="miktar" placeholder="Yüklemek istediğiniz TL miktarını giriniz." >
      <span class="input-group-btn">
        <button class="btn btn-success" type="submit">Yükle</button>
      </span>
    </div><!-- /input-group -->
</form>

</div><div class="col-md-6">

<form action="?islem=paketyukle&id=<?=$id?>" method="post">
    <div class="input-group">
      <select class="form-control" name="paketid" >
		<option value="">Paket Seçiniz</option>
		<?php foreach($db->query("SELECT * FROM paketler order by id asc") as $rs) { ?>
		<option value="<?=$rs['id']?>"><?=$rs['baslik']?></option>
		<?php } ?>
	  </select>
      <span class="input-group-btn">
        <button class="btn btn-success" type="submit">Tanımla</button>
      </span>
    </div><!-- /input-group -->
</form>

</div>
</div>

<br><br>
<p><b>Geçmiş İşlemleri</b></p>

<?php
$query = $db->prepare("SELECT * FROM ucretler where uyeid = :uyeid  order by id desc");
$query->bindValue(':uyeid', $id);
$query->execute();
$verisay = $query->rowCount();
?>
<?php if($verisay == "0"){ ?>
<div class="alert alert-info" >Bakiyelerle ilgili işlemler olduğunda buradan takip edebilirsiniz.</div>
<?php }else{ ?>
                           <table class="table table-stripped" >
                              <thead>
                                 <tr class="active">
                                    <th>Sipariş No</th>
                                    <th>Üye</th>
                                    <th>Açıklama</th>
                                    <th>Miktar</th>
                                    <th>Tarih</th>
									<th>Durum</th>
									<th></th>
                                 </tr>
                              </thead>
                              <tbody>
<?php
while($row=$query->fetch(PDO::FETCH_ASSOC)) {
$bak = $db->prepare("SELECT * FROM uyeler WHERE id=:firmaid");
$bak->bindValue(':firmaid', $row['uyeid']);
$bak->execute();
if($bak->rowCount()){
$firma = $bak->fetch(PDO::FETCH_ASSOC);
$kisi=$firma['isim'];
}

if($row['durum']=='1'){
$renk="success";
$durum="Başarılı";
}else if($row['durum']=='0'){
$renk="warning";
$durum="Bekliyor";
}else if($row['durum']=='2'){
$renk="danger";
$durum="Başarısız";
}
?>
                                 <tr class="<?php echo $renk;?>">
                                    <td><?=$row['siparisno']?></td>
									<td><?=$kisi?></td>
                                    <td><?=$row['aciklama']?></td>
                                    <td><?=number_format($row['miktar'],2)?></td>
                                    <td><?php echo date('d.m.Y H:i',strtotime($row['tarih']));?></td>
									<td><?php echo $durum;?></td>
                                    <td><a href="?id=<?=$id?>&islem=sil&silid=<?=$row['id']?>" class="btn btn-danger btn-sm" onclick="return confirm('Bu işlemi silmek istiyor musunuz?')"><i class="fa fa-trash-o"></i></a></td>
                                 </tr>
<?php } ?>
                              </tbody>
                           </table>
<?php } ?>


        </div>
        <!-- /.box-body -->
        <div class="box-footer">
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->
		
	  
</div>
</div>
    </section>
    <!----------------------------------------------- /.content ------------------------------------------------>
  </div>
  <!-- /.content-wrapper -->


<?php
include "alt.php";
?>






</body>
</html>