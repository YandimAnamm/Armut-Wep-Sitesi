<?php
include "db.php";
include "kontrol.php";
$sayfa="Üye Hizmet Ekle";


if( isset($_GET['islem']) ){
if( $_GET['islem']=="kaydet" ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
if( isset($_POST['kapak']) ){
$kapak=$_POST['kapak'];
}else{
$kapak='';
}


$uyebak = $db->query("SELECT * FROM uyeler where id=".$_POST['uyeid']." ")->fetch(PDO::FETCH_ASSOC);
$isim = $uyebak['isim'];


$link=seflink($isim.'-'.$uyeil.'-'.$uyeilce.'-'.$_POST['kat2']).'-'.time();

$yeni = $db->prepare("INSERT INTO hizmetler SET uyeid = :uyeid, katid = :katid, baslik = :baslik, link = :link, detaylar = :detaylar, enaz = :enaz, encok = :encok, bolge = :bolge, kapak = :kapak, galeri = :galeri, durum = 'Yayında' ");
$yeni->bindValue(':uyeid', $_POST['uyeid']);
$yeni->bindValue(':katid', $_POST['katid']);
$yeni->bindValue(':baslik', $_POST['baslik']);
$yeni->bindValue(':link', $link);
$yeni->bindValue(':detaylar', $_POST['detaylar']);
$yeni->bindValue(':enaz', $_POST['enaz']);
$yeni->bindValue(':encok', $_POST['encok']);
$yeni->bindValue(':bolge', $_POST['bolge']);
$yeni->bindValue(':kapak', $kapak);
$yeni->bindValue(':galeri', $_POST['galeri']);
$yeni->execute();

$song = $db->prepare("UPDATE uyeler SET uyetipi ='Firma'  where id=".$_POST['uyeid']." ");
$song->execute();
$song1 = $db->prepare("UPDATE kategoriler SET hit = hit + 1  where id=".$_POST['katid']." ");
$song1->execute();

header("Location: hizmetilanlar.php");
exit();
}}
?>




<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteadi?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>

</head>
<body class="hold-transition <?=$tema?> sidebar-mini">
<div class="wrapper">

<?php
include "ust.php";
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!---------------------------------------------- Main content --------------------------------------------->
    <section class="content container-fluid" style="min-height:600px;">

<div class="row">
<div class="col-md-8">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><a href="hizmetilanlar.php"> Hizmet Profilleri </a> > <?=$sayfa?></h3>
        </div>
        <div class="box-body" style="min-height:400px;">



<form id="hizmetformu" action="?islem=kaydet" method="post">
									<div class="form-group">
                                        <label>Üye:</label>
										<select class="form-control" name="uyeid" required>
                                          <option value=""> Seçiniz </option>
<?php
$query = $db->prepare("SELECT * FROM uyeler order by isim asc ");
$query->execute();
while($row=$query->fetch(PDO::FETCH_ASSOC)) {
?>
<option value="<?=$row['id'];?>" > <?=$row['isim'];?> </option>
<?php } ?>
									    </select>
									</div>
                                    <div class="form-group">
                                       <label for="katmanset">Hizmet Kategorisi:</label>
                                       <input type="text" class="form-control hizmetara" id="kathizmet" placeholder="Ör: Tadilat,Özel Ders,Temizlik..." required>
									   <div id="kathizmetsonuc"></div>
									   <div id="secilenhizmetler"></div>
                                    </div>
<div class="hizmetdevam hide">
                                    <div class="form-group">
                                       <label for="baslik">Hizmet Başlığı:</label>
                                       <input type="text" class="form-control zorunlu" id="baslik" name="baslik" placeholder="" required>
                                    </div>
                                    <div class="form-group">
                                       <label for="j_desc">Verdiğiniz hizmeti Müşterilere anlatın:</label>
                                       <textarea id="j_desc" class="form-control zorunlu" name="detaylar" placeholder="Şu kadar yıldır bu hizmeti veriyorum. Verdiğim hizmete şunlar dahil değildir. Yaptığım hizmetin hep arkasındayım...vs."  required></textarea>
                                    </div>
									<div class="row">
									<div class="col-sm-6">
                                    <div class="form-group">
                                       <label for="mn_salary">Ücret Tarife Aralığı (En Az)<span>(₺)</span>:</label>
                                       <input type="number" class="form-control zorunlu text-right" placeholder="" id="mn_salary" name="enaz">
                                    </div>
									</div><div class="col-sm-6">
                                    <div class="form-group">
                                       <label for="mx_salary">Ücret Tarife Aralığı (En Çok)<span>(₺)</span>:</label>
                                       <input type="number" class="form-control zorunlu text-right" placeholder="" id="mx_salary" name="encok">
                                    </div>
									</div>
									</div>
                                 <div class="row">
									<div class="col-sm-12 text-left">
									<label><b>Hizmeti verebileceğiniz yerler:</b></label>
									</div>  
                                    <div class="col-sm-4 form-group">
                                       <select class="form-control" id="il" name="il" >
                                          <option value="Tüm Şehirler"> Tüm Şehirler </option>
<?php
$query = $db->prepare("SELECT * FROM iller order by il asc ");
$query->execute();
while($row=$query->fetch(PDO::FETCH_ASSOC)) {
?>
<option value="<?=$row['il'];?>" > <?=$row['il'];?> </option>
<?php } ?>
									    </select>
                                    </div>
									<div class="col-sm-4 form-group ilce"  style="display:none">
                                       <select class="form-control" id="ilce" name="ilce" >
                                          <option value="Tüm Şehirler"> Tüm Şehirler </option>
									   </select>
                                    </div>
									<div class="col-sm-4 form-group text-left">
                                       <button type="button" class="btn btn-default" id="yerekle">Ekle</button>
                                    </div>
									<div class="col-sm-12 yerler text-left">
									<span></span>
									<input type="hidden" name="bolge" id="bolge" >
									</div> 
                                 </div>
								 <br>
                                 <div class="form-group">
								 <label>Verdiğiniz hizmeti anlatan fotoğraflarla müşterilerin dikkatini çekin.</label><br> 
<div id="yuklenenler"></div>
<div class="progress" id="upload-progress" style="display:none">
  <div class="progress-bar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>
</div>
<input type="hidden" value="<?=time()?>" name="galeri">

                                    <label class="btn btn-default">
                                       <i class="fa fa-upload"></i> Görseller Yükleyin
                                       <input data-id="<?=time()?>" class="image-upload" style="display: contents;" id="w_screen" type="file" name="images[1]" accept="image/jpeg,image/jpg,image/png,image/gif" multiple>
                                    </label>
                                    
                                 </div>

<div class="hizmetdevam hide">
								<div class="form-group text-center">
								<span class="uyari"></span>
								<button type="button" class="btn btn-success" id="kaydet">Hizmet Profilini Kaydet</button>
								</div>
</div>
                           </form>







        </div><!-- /.box-body -->
      </div><!-- /.box -->

</div>
</div>

    </section>
    <!----------------------------------------------- /.content ------------------------------------------------>
  </div>
  <!-- /.content-wrapper -->


<?php
include "alt.php";
?>



<script>
$("#kaydet").click(function(){
var bosmu="";
$("#hizmetformu .zorunlu").each(function(){
$(this).css("background","#fff");
if($(this).val()==''){
bosmu="evet";
$(this).css("background","#faa");
}
});

if(bosmu!==''){
$("#hizmetformu .uyari").html("Tüm Alanları doldurunuz!").show().delay("2000").hide("slow");
}else if($("#bolge").val()==''){
$("#hizmetformu .uyari").html("Hizmet verebileceğiniz en az bir yer ekleyiniz!").show().delay("2000").hide("slow");
}else{
$("#hizmetformu").submit();
}

});
</script>

<script type="text/javascript">
$(function(){	
	$('#kathizmet').on('keyup', function () {
	var kathizmet = $(this).val();
	if(kathizmet.length<2){
	$("#kathizmetsonuc").html("");
	}else{
		$.post("/katcekhizmet.php", {
        kat: kathizmet
        }, function (cevap) {
            $("#kathizmetsonuc").html(cevap);
        });
	}
    });
	
	$("#kathizmet").click(function(){
	$("#kathizmet").val("");
	$("#kathizmetsonuc").val("");
	});
});


$(document).on('click','.kaldir',function(e) {
$(this).closest("p").css("color","#900").delay(2000).remove();
if($("#secilenhizmetler").html()==''){
$(".hizmetdevam").hide();
$(".hizmetara").show("slow");
}
});

</script>


    <script type="text/javascript" src="/assets/base64/js/exif.js"></script>
    <script type="text/javascript" src="/assets/base64/js/ImageUploader.js"></script>
    <script type="text/javascript" src="/assets/base64/js/custom.js"></script>


<script type="text/javascript">
$(function(){
$('#il').on('change', function () {
	var il = $('#il option:selected').val();
    $.post("/hizmetekleilceler.php", {il: il}, function (cevap) {
        $("#ilce").html(cevap);
		$(".ilce").show();
		
    });
});


$(document).on("click","#yerekle",function(){
	var il = $('#il option:selected').val();
	var ilce = $('#ilce option:selected').val();
	var bolge = il+'/'+ilce;
	if($(".yerler #bolge").val().indexOf(bolge)=='-1'){
	$(".yerler span").append('<div class="btn-group mt-2 mr-3"><button type="button" class="btn btn-light btn-sm">'+bolge+'</button><button type="button" class="btn btn-danger btn-sm yersil" data-yer="'+bolge+'"><i class="fa fa-trash-o"></i></button></div>');
	$(".yerler #bolge").val($(".yerler #bolge").val() + bolge+', ');
	}
});

$(document).on("click",".yersil",function(){
	var bolge=$(this).attr("data-yer");
	$(".yerler #bolge").val(($(".yerler #bolge").val()).replace(bolge+', ',''));
	$(this).closest(".btn-group").remove();
});

});
</script>





</body>
</html>