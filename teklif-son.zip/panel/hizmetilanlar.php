<?php
include "db.php";
include "kontrol.php";
$sayfa="Hizmet Profilleri";
?>


<?php
if( isset($_GET['silid']) ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$query = $db->prepare("DELETE FROM hizmetler WHERE id = :id");
$delete = $query->execute(array(
'id' => $_GET['silid']
));
header("Location: ?");
}
?>


<?php
if( isset($_GET['yayinla']) ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$query = $db->prepare("UPDATE hizmetler SET durum='Yayında' WHERE id = :id");
$delete = $query->execute(array(
'id' => $_GET['yayinla']
));
header("Location: ?");
}

if( isset($_GET['yayindankaldir']) ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$query = $db->prepare("UPDATE hizmetler SET durum='Durduruldu' WHERE id = :id");
$delete = $query->execute(array(
'id' => $_GET['yayindankaldir']
));
header("Location: ?");
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteadi?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>


</head>
<body class="hold-transition <?=$tema?> sidebar-mini">
<div class="wrapper">

<?php
include "ust.php";
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!---------------------------------------------- Main content --------------------------------------------->
    <section class="content container-fluid" style="min-height:600px;">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><?=$sayfa?></h3>
          <div class="box-tools pull-right">
            <a href="uyehizmetekle.php" class="btn btn-success">Hizmet Ekle</a>
          </div>
        </div>
        <div class="box-body" style="min-height:400px;">


		
<?php
if(isset($_GET['katid'])){
$katid=$_GET['katid'];
}else{
$katid='0';
}
?>


<form action="?islem=ara" method="GET">
<div class="row">
<div class="col-md-2">
<span>Kategori</span>
<select class="form-control" name="katid">
<option value="0">Tümü</option>
<?php 
foreach($db->query("SELECT * FROM hizmetler group by katid ") as $rs) { 
$katbak = $db->query("SELECT * FROM kategoriler where id=".$rs['katid']." ")->fetch(PDO::FETCH_ASSOC);
?>
<option <?php echo $katid==$rs['katid'] ? 'selected':'';?> value="<?=$rs['katid']?>"><?=$katbak['baslik']?></option>
<?php } ?>
</select>
</div>
<div class="col-md-2">
<p style="margin-top:20px;"><button type="submit" class="btn btn-default" >Getir</button></p>
</div>

</div>
</form>


<?php
$q1 = $db->prepare("SELECT * FROM hizmetler where (katid=".$katid." or '".$katid."'='0') order by id desc ");
$q1->execute();

$toplamveri = $q1->rowCount();
if($toplamveri=='0'){
?>
<div class="alert alert-warning">Kayıt Bulunamadı...</div>
<?php }else{ ?>
<p><?=$toplamveri?> kayıt listelendi...</p>


<div class="table-responsive">
<table class="table table-striped">
<tr class="active">
<td class="text-bold text-left">Başlık</td>
<td class="text-bold text-center" width="200">Üye</td>
<td class="text-bold text-center" width="200">Oluşturma</td>
<td class="text-bold text-center" width="150">İşlem</td>
</tr>
<?php
$goster = 20;
$toplamSayfa = ceil($toplamveri / $goster);
if(!empty($_GET["s"])){
$sayfa = $_GET["s"];
}else{
$sayfa = 1;
}
if($sayfa < 1){ 
$sayfa = 1;
}
if($sayfa > $toplamSayfa){
$sayfa = $toplamSayfa;
}
$limit = ($sayfa - 1) * $goster;

$q = $db->prepare("SELECT * FROM hizmetler where (katid=".$katid." or '".$katid."'='0') order by id desc limit $limit, $goster");
$q->execute();
$toplamverim = $q->rowCount();

while($row=$q->fetch(PDO::FETCH_ASSOC)) {
$bak = $db->prepare("SELECT * FROM uyeler WHERE id=:uyeid");
$bak->bindValue(':uyeid', $row['uyeid']);
$bak->execute();
if($bak->rowCount()){
$veri = $bak->fetch(PDO::FETCH_ASSOC);
$kisi=$veri['isim'];
$kisiid=$veri['id'];
}
?>
<tr>
<td class="text-left">
<a class="text-success text-bold" href="/profil/<?=$row['link']?>" target="_blank"><?=$row['baslik']?></a>
<ul>
<?php
$ybelgeler=$row['belgeler'];
$ybelgeler=$ybelgeler!=='' ? json_decode($ybelgeler,true):Array();
foreach($ybelgeler as $key=>$val){
echo '<li><a class="text-muted" href="'.$ybelgeler[$key]['dosya'].'" download>'.$ybelgeler[$key]['baslik'].'</a></li>';
}
?>
</ul>
</td>
<td class="text-center"><span class="uyebilgi" data-uyeid="<?=$kisiid?>" ><?=$kisi?></span></td>
<td class="text-center"><?php echo date('d/m/Y H:i', strtotime($row['olusturma'])); ?></td>
<td class="text-center">
<?php if($row['durum']=='Yayında'){?>
<a href="?yayindankaldir=<?=$row['id']?>" class="btn btn-success btn-sm"><i class="fa fa-tv"></i> Aktif</a>
<?php }else{ ?>
<a href="?yayinla=<?=$row['id']?>" class="btn btn-warning btn-sm"><i class="fa fa-tv"></i> Pasif</a>
<?php } ?>
<a href="uyehizmetguncelle.php?id=<?=$row['id']?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a>
<a href="?silid=<?=$row['id']?>" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a>
</td>
</tr>
<?php } ?>

</table>
</div>


<ul class="pagination">
<?php 
$nokta=0;
for($i = 1; $i<=$toplamSayfa;$i++)
{
?>
<?php
if($i=='1' || ($i>=$sayfa-3 && $i<=$sayfa+3) || $i==$toplamSayfa ){
$nokta=0;
?>
<?php 
if($i==$sayfa){
?>
<li class="paginate_button active" ><a href="#"><?php echo $i;?></a></li>
<?php 
}else{ 
?>
<li class="paginate_button"><a href="?katid=<?=$katid?>&s=<?php echo $i;?>"><?php echo $i;?></a></li>
<?php } ?>
<?php 
}else{
if($nokta===0){
$nokta=1;
?>
<li class="paginate_button"><a href="#">...</a></li>
<?php }}} ?>
</ul>
</div>
<?php } ?>




        </div>
        <!-- /.box-body -->
        <div class="box-footer">
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->


    </section>
    <!----------------------------------------------- /.content ------------------------------------------------>
  </div>
  <!-- /.content-wrapper -->


<?php
include "alt.php";
?>




</body>
</html>