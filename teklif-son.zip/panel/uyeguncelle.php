<?php
include "db.php";
include "kontrol.php";
$sayfa="Üye Güncelle";
?>

<?php
if( isset($_GET['islem']) ){
if( $_GET['islem']=="kaydet" ){
$yeni = $db->prepare("UPDATE uyeler SET isim = :isim, eposta = :eposta, tel=:tel, sifre = :sifre, yetki=:yetki where id= :id ");
$yeni->bindValue(':isim', $_POST['isim']);
$yeni->bindValue(':eposta', $_POST['eposta']);
$yeni->bindValue(':tel', $_POST['tel']);
$yeni->bindValue(':sifre', $_POST['sifre']);
$yeni->bindValue(':yetki', $_POST['yetki']);
$yeni->bindValue(':id', $_GET['id']);
$yeni->execute();

if($yeni){
    header("Location: uyeler.php");
}

}}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteadi?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>

</head>
<body class="hold-transition <?=$tema?> sidebar-mini">
<div class="wrapper">

<?php
include "ust.php";
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!---------------------------------------------- Main content --------------------------------------------->
    <section class="content container-fluid" style="min-height:600px;">

<div class="row">
<div class="col-md-4">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><a href="uyeler.php"> Üyeler </a> > <?=$sayfa?></h3>
        </div>
        <div class="box-body" style="min-height:400px;">
		
<?php
$bak = $db->prepare("SELECT * FROM uyeler WHERE id=:id");
$bak->bindValue(':id', $_GET['id']);
$bak->execute();
if($bak->rowCount()){
$veri = $bak->fetch(PDO::FETCH_ASSOC);
?>

<form action="?islem=kaydet&id=<?=$_GET['id']?>" method="post" >

<div class="form-group">
<label>Üye Adı Soyadı</label>
<input type="text" class="form-control" placeholder="" value="<?=$veri['isim']?>" name="isim" required>
</div>

<div class="form-group">
<label>Telefon</label>
<input type="number" class="form-control" placeholder="" value="<?=$veri['tel']?>" name="tel" required>
</div>

<div class="form-group">
<label>E-Posta</label>
<input type="email" class="form-control" placeholder="" value="<?=$veri['eposta']?>" name="eposta" required>
</div>

<div class="form-group">
<label>Şifre</label>
<input type="text" class="form-control" placeholder="" value="<?=$veri['sifre']?>" name="sifre" >
</div>

<div class="form-group">
<label>Yetki</label>
<select class="form-control" name="yetki">
<option value="0" <?php echo $veri['yetki']=='0' ? 'selected':'';?> >Normal Üye</option>
<option value="11" <?php echo $veri['yetki']=='11' ? 'selected':'';?> >Demo Kullanıcı</option>
<option value="98" <?php echo $veri['yetki']=='98' ? 'selected':'';?> >Editör</option>
<option value="99" <?php echo $veri['yetki']=='99' ? 'selected':'';?> >Admin</option>
</select>
</div>

<div style="width:%100;text-align:center;">
<button type="submit" class="btn btn-success">Kaydet</button>
</div>

</form>                                    


<?php } ?>




        </div><!-- /.box-body -->
      </div><!-- /.box -->

</div>
</div>

    </section>
    <!----------------------------------------------- /.content ------------------------------------------------>
  </div>
  <!-- /.content-wrapper -->


<?php
include "alt.php";
?>






</body>
</html>