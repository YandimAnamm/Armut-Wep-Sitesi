<?php
session_start();
ob_start();

include "db_ayar.php";

include 'DBBackupRestore/DBBackupRestore.class.php';

$dbBackup = new DBYedek();

	$kayityeri	= "DBBackupRestore/temp/";
	$arsiv		= false;	//Yedeği zip arsivi olarak almak için true // .sql olarak almak için false
	$tablosil	= true;		//DROP TABLE if EXISTS satırı eklemek için true // istenmiyorsa false

	//Veri için kullanılacak sözdizimi:
	$veritipi	= 1; // INSERT INTO tbl_adı VALUES (1,2,3);
	//$veritipi	= 2; // INTO tbl_adı VALUES (1,2,3), (4,5,6), (7,8,9);
	//$veritipi	= 3; // INSERT INTO tbl_adı (sütun_A,sütun_B,sütun_C) VALUES (1,2,3);
	//$veritipi	= 4; // INSERT INTO tbl_adı (col_A,col_B,col_C) VALUES (1,2,3), (4,5,6), (7,8,9);

	$backup = $dbBackup->Disa_Aktar($kayityeri, $arsiv, $tablosil, $veritipi);
	rename($backup,$kayityeri.'kurulum.sql');
	
$dbBackup->kapat();
ob_end_flush();



$rootPath = realpath('../');
$kayityeri="DBBackupRestore/fullyedek/";
if(!file_exists($kayityeri)){
	mkdir($kayityeri, 0700);
}

$dosyaadi=$kayityeri.'yedek-'.date('Y-m-d_H-i').'.zip';
$zip = new ZipArchive();
$zip->open($dosyaadi, ZipArchive::CREATE | ZipArchive::OVERWRITE);

$files = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($rootPath),
    RecursiveIteratorIterator::LEAVES_ONLY
);

foreach ($files as $name => $file)
{
    // Skip directories (they would be added automatically)
    if (!$file->isDir())
    {
        // Get real and relative path for current file
        $filePath = $file->getRealPath();
        $relativePath = substr($filePath, strlen($rootPath) + 1);
        // Add current file to archive
		if(strpos($file,'/fullyedek/yedek')===false){
        echo '<br>'.$file;
		$zip->addFile($filePath, $relativePath);
		}
    }
}

// Zip archive will be created only after closing object
$zip->close();

/*
rename($dosyaadi,$kayityeri.$dosyaadi);
if(file_exists($dosyaadi)){
	unlink($dosyaadi);
}
*/
?>