<?php
include "db.php";
include "kontrol.php";
?>


<?php
$sonuc = "error"; // sonucumuzu varsayılan olarak error olarak ayarlıyoruz
if (is_array($_POST['eleman']) && $yetki=='99') { // gelen değerler (eleman-1) dizi olup olmadığını kontrol ediyoruz
$tablo=$_GET['tablo'];
    foreach ($_POST['eleman'] as $key => $value) // döngüde elemanların id ve sıra bilgisini alıyoruz
        if ($db->query("UPDATE `$tablo` SET sira = $key WHERE id = $value"))
            // her satırın id bilgisi ile sıra bilgisini veritabanında düzenliyoruz
            $sonuc = "success";  // sonuc değişkenine success değerini atıyoruz
}
echo $sonuc; // sonuç değerini geri döndürüyoruz json formatında da döndürebilirdik
?>
