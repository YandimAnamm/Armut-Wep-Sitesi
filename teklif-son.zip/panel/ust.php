  <!-- Main Header -->
  <header class="main-header">
    <!-- Logo -->
    <a href="/" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>Y</b>A</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>AYDIN</b>WEB</span>
    </a>

    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top" role="navigation">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <!-- Navbar Right Menu -->
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li class="dropdown notifications-menu" id="bildirimler"></li>
          <li class="dropdown user user-menu">
            <!-- Menu Toggle Button -->
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <!-- The user image in the navbar-->
              <img src="dist/img/noperson.png" class="user-image" alt="User Image">
              <!-- hidden-xs hides the username on small devices so only the image appears. -->
              <span class="hidden-xs"><?=$isim?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- The user image in the menu -->
              <li class="user-header">
                <img src="dist/img/noperson.png" class="img-circle" alt="User Image">
                <p> <?=$isim?> <small></small></p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left hide">
                  <a href="profil.php" class="btn btn-default btn-flat">Profil</a>
                </div>
                <div class="pull-right">
                  <a href="cik.php" class="btn btn-default btn-flat">Çıkış</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="dist/img/noperson.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?=$isim?></p>
          <!-- Status -->
          <a href="#"><i class="fa fa-circle text-success"></i> Çevrimiçi</a>
        </div>
      </div>

<br><br>
      <!-- Sidebar Menu -->
      <ul class="sidebar-menu" data-widget="tree">
        <li><a href="index.php"><i class="fa fa-home"></i> <span>Anasayfa</span></a></li>
		<li><a href="talepyonet.php"><i class="fa fa-link"></i> <span>Talepler</span></a></li>
        <li><a href="hizmetilanlar.php"><i class="fa fa-link"></i> <span>Hizmet Profilleri</span></a></li>
		<li><a href="kategoriler.php"><i class="fa fa-bars"></i> <span>Kategoriler</span></a></li>
        <li><a href="sayfalar.php"><i class="fa fa-file-text"></i> <span>Sayfalar</span></a></li>
		<li><a href="ustmenuler.php"><i class="fa fa-bars"></i> <span>Üst Menüler</span></a></li>
		<li><a href="bankalar.php"><i class="fa fa-bank"></i> <span>Hesap Numaraları</span></a></li>
		<li><a href="paketyonet.php"><i class="fa fa-star"></i> <span>Paketler</span></a></li>
		<?php if($yetki=='99'){ ?>
		<li><a href="uyeler.php"><i class="fa fa-users"></i> <span>Üyeler</span></a></li>
		<li><a href="ayarlar.php"><i class="fa fa-cog"></i> <span>Site Ayarları</span></a></li>
		<li><a href="yedek.php"><i class="fa fa-database"></i> <span>Yedekleme</span></a></li>
		<?php } ?>
      </ul>
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
  </aside>
