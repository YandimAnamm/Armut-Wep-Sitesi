<?php
include "db.php";
include "kontrol.php";
?>

<?php 
if($uyeid!==''){
$song = $db->prepare("UPDATE uyeler SET songiris = '".date('Y-m-d H:i:s',time())."' where id=".$uyeid." ");
$song->execute();
?>

<?php
if( isset($_GET['bild']) ){
if( $_GET['bild']=="temizle" ){
$query = $db->prepare("DELETE FROM bildirimler WHERE uyeid = :uyeid");
$delete = $query->execute(array(
'uyeid' => $uyeid
));
}
if( $_GET['bild']=="sustur" ){
$query = $db->prepare("UPDATE bildirimler Set durum=1 WHERE uyeid = :uyeid");
$delete = $query->execute(array(
'uyeid' => $uyeid
));
}
}
?>


<a href="#" id="bildirimler" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
<i class="fa fa-bell-o"></i>
<?php
$bibak = $db->prepare("SELECT * FROM bildirimler WHERE uyeid=:uyeid and durum=0");
$bibak->execute([
            ':uyeid' =>  $uyeid
        ]);
		$okunmayanverisay = $bibak->rowCount();

$query = $db->prepare("SELECT * FROM bildirimler WHERE uyeid=:uyeid order by id desc");
        $query->execute([
            ':uyeid' =>  $uyeid
        ]);
		$verisay = $query->rowCount();

if($okunmayanverisay > 0){
?>
<span class="label label-warning"><?=$okunmayanverisay?></span>
<?php } ?>

</a>
<ul class="dropdown-menu">
<?php if($verisay == 0){ ?>
<li class="header"><center><b>Bildiriminiz Bulunmamaktadır.</b></center></li>
<?php }else{ ?>
<li class="header"><center><i class="fa fa-warning text-yellow"></i> <b><?=$verisay?> Bildiriminiz Var!</b></center></li>
<li>
<div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 200px;"><ul class="menu" style="overflow: hidden; width: 100%; height: 200px;">
<?php
while($row=$query->fetch(PDO::FETCH_ASSOC)) {
?>
<li <?php if($row['durum']==0){ ?>style="background-color:#efc5c5;"<?php } ?> ><?=$row['mesaj']?></li>
<?php } ?>
</ul><div class="slimScrollBar" style="width: 3px; position: absolute; top: 0px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 195.122px; background: rgb(0, 0, 0);"></div><div class="slimScrollRail" style="width: 3px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; opacity: 0.2; z-index: 90; right: 1px; background: rgb(51, 51, 51);"></div></div>
</li>
<li class="footer"><a href="#" id="bildtemizle">Temizle</a></li>
</ul>

<?php if($okunmayanverisay > 0){ ?>
<audio autoplay="true" src="dist/notify.mp3" style="display:none;">
<?php } ?>

<?php } ?>



<script>
$('#bildtemizle').click(function () {
$.get("bildirimler.php?bild=temizle", function(){
$("#bildirimler").load('bildirimler.php');
});
});
</script>

<?php } ?>