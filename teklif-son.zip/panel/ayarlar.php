<?php
include "db.php";
include "kontrol.php";
$sayfa="Ayarlar";

if($yetki!=='99'){
header("location: index.php");
exit();
}
?>

<?php
if( isset($_GET['islem'])=="kaydet" ){


$logo='';
$dizin = 'upload/resimler/';

if(isset($_FILES['logodosya'])){
   $hata = $_FILES['logodosya']['error'];
   if($hata != 0) {
      //$durum='Yüklenirken bir hata gerçekleşmiş.';
   } else {
      $boyut = $_FILES['logodosya']['size'];
      if($boyut > (1024*1024*5)){
         $durum='Dosya 5MB den büyük olamaz.';
      } else {
         $tip = $_FILES['logodosya']['type'];
         $isim = $_FILES['logodosya']['name'];
         $dbol = explode('.', $isim);
         $uzanti = $dbol[1];
         $dosyaadi = $dbol[0];
         if($uzanti=='jpg' || $uzanti=='jpeg' || $uzanti=='png'){
			$orjdosya = $_FILES['logodosya']['tmp_name'];
            $yenidosyaadi=$dizin . seflink($dosyaadi).'-'.$uyeid.time().'.'.$uzanti;
            copy($orjdosya, $yenidosyaadi);
            $durum='Dosyanız upload edildi! ve Değişiklikler Kaydedildi. ';
			$logo=$yenidosyaadi;
			
			$yeni = $db->prepare("UPDATE ayarlar SET logo=:logo where id=1 ");
			$yeni->bindValue(':logo', '/panel/'.$logo);
			$yeni->execute();
			
         } else {
			$durum='Yanlızca resim dosyaları gönderebilirsiniz.';
         }
      }
   }
}




$odemeyontemleri = implode(',', $_POST['odemeyontemi']);

$yeni = $db->prepare("UPDATE ayarlar SET siteadi = :siteadi, siteurl = :siteurl, postasunucu = :postasunucu , posta = :posta , postasifre = :postasifre , yetkiliid = :yetkiliid , tel = :tel  , adres = :adres , facebook=:facebook, twitter=:twitter, instagram=:instagram, smsbaslik = :smsbaslik, smsmusterino = :smsmusterino, smskullaniciadi = :smskullaniciadi, smssifre = :smssifre, merchant_id = :merchant_id, merchant_key = :merchant_key, merchant_salt = :merchant_salt, minteklif = :minteklif, teklifucreti = :teklifucreti, komisyonucreti = :komisyonucreti, maxteklifsayisi=:maxteklifsayisi, odemeyontemi = :odemeyontemi where id=1 ");
$yeni->bindValue(':siteadi', $_POST['siteadi']);
$yeni->bindValue(':siteurl', $_POST['siteurl']);
$yeni->bindValue(':postasunucu', $_POST['postasunucu']);
$yeni->bindValue(':posta', $_POST['posta']);
$yeni->bindValue(':postasifre', $_POST['postasifre']);
$yeni->bindValue(':yetkiliid', $_POST['yetkiliid']);
$yeni->bindValue(':tel', $_POST['tel']);
$yeni->bindValue(':adres', $_POST['adres']);

$yeni->bindValue(':facebook', $_POST['facebook']);
$yeni->bindValue(':twitter', $_POST['twitter']);
$yeni->bindValue(':instagram', $_POST['instagram']);

$yeni->bindValue(':smsbaslik', $_POST['smsbaslik']);
$yeni->bindValue(':smsmusterino', $_POST['smsmusterino']);
$yeni->bindValue(':smskullaniciadi', $_POST['smskullaniciadi']);
$yeni->bindValue(':smssifre', $_POST['smssifre']);
$yeni->bindValue(':merchant_id', $_POST['merchant_id']);
$yeni->bindValue(':merchant_key', $_POST['merchant_key']);
$yeni->bindValue(':merchant_salt', $_POST['merchant_salt']);

$yeni->bindValue(':minteklif', $_POST['minteklif']);
$yeni->bindValue(':teklifucreti', $_POST['teklifucreti']);
$yeni->bindValue(':komisyonucreti', $_POST['komisyonucreti']);
$yeni->bindValue(':maxteklifsayisi', $_POST['maxteklifsayisi']);

$yeni->bindValue(':odemeyontemi', $odemeyontemleri);

$yeni->execute();

if($yeni){
    header("Location: ?");
	exit();
}

}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteadi?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>

</head>
<body class="hold-transition <?=$tema?> sidebar-mini">
<div class="wrapper">

<?php
include "ust.php";
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!---------------------------------------------- Main content --------------------------------------------->
    <section class="content container-fluid" style="min-height:600px;">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><?=$sayfa?></h3>
        </div>
        <div class="box-body" style="min-height:400px;">
		
<?php
$bak = $db->prepare("SELECT * FROM ayarlar WHERE id=1 ");
$bak->execute();
if($bak->rowCount()){
$veri = $bak->fetch(PDO::FETCH_ASSOC);
?>

<form action="?islem=kaydet" method="post" enctype="multipart/form-data"  >

<div class="form-group">
<label>Site Adı</label>
<input type="text" class="form-control" placeholder="Yahya Aydın Kişisel Web Sitesi"  name="siteadi" value="<?=$veri['siteadi']?>" required>
</div>

<div class="form-group">
<label>Site Url</label>
<input type="text" class="form-control" placeholder="http://www.yahyaaydin.com.tr"  name="siteurl" value="<?=$veri['siteurl']?>" required>
</div>

<div class="form-group">
<label>Logo</label>
<input type="file" class="form-control" name="logodosya" >
</div>

<div class="form-group">
<label>E-Posta</label>
<input type="text" class="form-control" placeholder="bilgi@yahyaaydin.com.tr"  name="posta" value="<?=$veri['posta']?>"  >
</div>

<div class="form-group">
<label>E-Posta Şifresi</label>
<input type="text" class="form-control" placeholder="*******"  name="postasifre" value="<?=$veri['postasifre']?>"  >
</div>

<div class="form-group">
<label>E-Posta Sunucusu</label>
<input type="text" class="form-control" placeholder="mail.yahyaaydin.com.tr"  name="postasunucu" value="<?=$veri['postasunucu']?>"  >
</div>

<div class="form-group">
<label>Bildirim Gönderilecek Yetkili Üye</label>
<select class="form-control" name="yetkiliid">
<?php foreach($db->query("SELECT * FROM uyeler order by id asc") as $row) { ?>
<option value="<?=$row['id']?>" <?php echo $veri['yetkiliid']==$row['id'] ? 'selected':'';?> ><?=$row['isim']?></option>
<?php } ?>
</select> 
</div>

<div class="form-group">
<label>İletişim Telefon</label>
<input type="text" class="form-control" placeholder="08889998877"  name="tel" value="<?=$veri['tel']?>" >
</div>

<div class="form-group">
<label>İletişim Adres</label>
<input type="text" class="form-control" placeholder="Sancak mah. güller sok. No:55"  name="adres" value="<?=$veri['adres']?>" >
</div>

<div class="form-group">
<label>Facebook</label>
<input type="text" class="form-control" placeholder=""  name="facebook" value="<?=$veri['facebook']?>"  >
</div>

<div class="form-group">
<label>Twitter</label>
<input type="text" class="form-control" placeholder=""  name="twitter" value="<?=$veri['twitter']?>"  >
</div>

<div class="form-group">
<label>Instagram</label>
<input type="text" class="form-control" placeholder=""  name="instagram" value="<?=$veri['instagram']?>"  >
</div>


<div class="form-group">
<label>Min Teklif <small>(Sadece sayı giriniz)</small></label>
<input type="number" step="0.01" class="form-control" placeholder=""  name="minteklif" value="<?=$veri['minteklif']?>" required>
</div>

<div class="form-group">
<label>Teklif Ücreti <small>(Sadece sayı giriniz, yüzde için sonuna % işareti koyunuz)</small></label>
<input type="text" class="form-control" placeholder=""  name="teklifucreti" value="<?=$veri['teklifucreti']?>" required>
</div>

<div class="form-group">
<label>Komisyon Ücreti <small>(Sadece sayı giriniz, yüzde için sonuna % işareti koyunuz)</small></label>
<input type="text" class="form-control" placeholder=""  name="komisyonucreti" value="<?=$veri['komisyonucreti']?>" required>
</div>

<div class="form-group">
<label>Max Teklif Sayısı<small>(Bu teklif sayısına ulaştığında talebi kapat)</small></label>
<input type="number" min="1" class="form-control"  name="maxteklifsayisi" value="<?=$veri['maxteklifsayisi']?>" required>
</div>


<div class="thumbnail" style="background:#e6e7ef">
<h3>Vatan Sms Bilgileri</h3>
<div class="form-group">
<label>Sms Başlığı</label>
<input type="text" class="form-control" placeholder=""  name="smsbaslik" value="<?=$veri['smsbaslik']?>" >
</div>

<div class="form-group">
<label>Sms Müşteri No</label>
<input type="text" class="form-control" placeholder=""  name="smsmusterino" value="<?=$veri['smsmusterino']?>" >
</div>

<div class="form-group">
<label>Sms Kullanıcı Adı</label>
<input type="text" class="form-control" placeholder=""  name="smskullaniciadi" value="<?=$veri['smskullaniciadi']?>" >
</div>

<div class="form-group">
<label>Sms Şifre</label>
<input type="text" class="form-control" placeholder=""  name="smssifre" value="<?=$veri['smssifre']?>" >
</div>

</div>

<div class="thumbnail" style="background:#e6e7ef">
<h3>PayTr Bilgileri</h3>

<div class="form-group">
<label>Merchant_id</label>
<input type="text" class="form-control" placeholder=""  name="merchant_id" value="<?=$veri['merchant_id']?>" >
</div>

<div class="form-group">
<label>Merchant_key</label>
<input type="text" class="form-control" placeholder=""  name="merchant_key" value="<?=$veri['merchant_key']?>" >
</div>

<div class="form-group">
<label>Merchant_salt</label>
<input type="text" class="form-control" placeholder=""  name="merchant_salt" value="<?=$veri['merchant_salt']?>" >
</div>

</div>

<div class="form-group">
<label>Ödeme Yöntemleri</label><br>
<label><input type="checkbox" name="odemeyontemi[]" value="Kredi" <?php if(strpos($veri['odemeyontemi'],'Kredi')===false){}else{?>checked<?php }?> > Kredi Kartı </label>
<label style="margin-left:50px;"><input type="checkbox" name="odemeyontemi[]" value="Havale" <?php if(strpos($veri['odemeyontemi'],'Havale')===false){}else{?>checked<?php }?> > Banka Havalesi </label>
</div>


<div style="width:%100;text-align:center;">
<button type="submit" class="btn btn-success">Kaydet</button>
</div>

</form>                                    


<?php } ?>




        </div>
        <!-- /.box-body -->
        <div class="box-footer">
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->


    </section>
    <!----------------------------------------------- /.content ------------------------------------------------>
  </div>
  <!-- /.content-wrapper -->


<?php
include "alt.php";
?>






</body>
</html>