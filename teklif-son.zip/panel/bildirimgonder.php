

<?php
$smsnumaralar='';
$epostalar='';

if(strpos($alicilar, ',') === false){
$kisiid=$alicilar;

$kisibak = $db->prepare("SELECT * FROM uyeler WHERE id=:kisiid ");
$kisibak->bindValue(':kisiid', $kisiid);
$kisibak->execute();
if($kisibak->rowCount()){
$kisibilgi = $kisibak->fetch(PDO::FETCH_ASSOC);
$kisiid=$kisibilgi['id'];
$kisitel=$kisibilgi['tel'];
$kisieposta=$kisibilgi['eposta'];

$smsnumaralar=$kisitel;
$epostalar=$kisieposta;
}

}else{
$tumalicilar = explode(",", $alicilar);
foreach($tumalicilar as $kisiid)
{
$kisibak = $db->prepare("SELECT * FROM uyeler WHERE id=:kisiid ");
$kisibak->bindValue(':kisiid', $kisiid);
$kisibak->execute();
if($kisibak->rowCount()){
$kisibilgi = $kisibak->fetch(PDO::FETCH_ASSOC);
$kisiid=$kisibilgi['id'];
$kisitel=$kisibilgi['tel'];
$kisitokenid=$kisibilgi['tokenid'];
$kisieposta=$kisibilgi['eposta'];

$smsnumaralar=$smsnumaralar.','.$kisitel;
$epostalar=$epostalar.','.$kisieposta;


if($kisitokenid!==''){
$tokenbaslik="Yeni Bildirim";
$tokenmesaj="Size uygun iş yayınlandı";
$ch = curl_init("https://fcm.googleapis.com/fcm/send");
$header=array('Content-Type: application/json',
"Authorization: key=AAAA8p2LEd8:APA91bERg7Km7H1uPP0R9p_BiRjXnLQRJFF9fLHTjN1QUEQXqTfX6pqRzw_5cyIivrevuaYgdRTkXkOuyPzpE61LJ7IzaaqRGHHeJYcyV4JrdjJ3rHWidBiRBt3eaatTQOOOYcy61qAC");
curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 ); 
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{ "notification": {"sound": "default", "title": "'.$tokenbaslik.'",    "body": "'.$tokenmesaj.'"  },    "to" : "'.$kisitokenid.'"}');
curl_exec($ch);
curl_close($ch);
}



}
}
}
?>



<?php
if ( $smsnumaralar!=='' && $smsmesaj!=='' ){
include "smsapi.php";
}
?>




<?php
if($epostalar!=='' && $epostakonu!=='' && $epostamesaj!==''){

$sablon='<img src="'.$siteurl.$logo.'" style="margin-right:5px;height:60px;" >
<div style="padding:10px;font-size:14px;">'.$epostamesaj.'</div>
<p><a href="'.$siteurl.'">'.$siteurl.'</a></p>';

		include 'bower_components/phpmailer/class.phpmailer.php';
		$mail = new PHPMailer();
		$mail->IsSMTP();
		$mail->SMTPAuth = true;
		$mail->Host = $sitepostasunucu;
		$mail->Port = $sitesunucuportu;
		$mail->Username = $siteposta;
		$mail->Password = $sitepostasifre;
		$mail->SetFrom($mail->Username, $siteadi);

if(strpos($epostalar, ',') === false){
		$mail->AddBCC($epostalar, $siteadi);
}else{
$tumepostalar = explode(",", $epostalar);
foreach($tumepostalar as $eposta)
{
		$mail->AddBCC($eposta, $siteadi);
}
}
		$mail->CharSet = 'UTF-8';
		$mail->Subject = $epostakonu;
		$mail->IsHTML(true); 
		$mail->Body = $sablon;
		if($mail->Send()) {
			// e-posta başarılı ile gönderildi
			//echo '<div class="success">E-posta başarıyla gönderildi, lütfen kontrol edin.</div>';
		} else {
			// bir sorun var, sorunu ekrana bastıralım
			//echo '<div class="error">'.$mail->ErrorInfo.'</div>';
		}
	}
?>



<?php
if(strpos($alicilar, ',') === false){
$kisiid=$alicilar;
$bildir = $db->prepare("INSERT INTO bildirimler (uyeid, mesaj) VALUES ('".$kisiid."','".$siteicimesaj."') ");
$bildir->execute();
}else{
$tumkisiler = explode(",", $alicilar);
foreach($tumkisiler as $kisiid)
{
if($kisiid!==''){
$bildir = $db->prepare("INSERT INTO bildirimler (uyeid, mesaj) VALUES ('".$kisiid."','".$siteicimesaj."') ");
$bildir->execute();
}
}
}
?>
