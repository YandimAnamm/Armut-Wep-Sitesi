<?php 
header('Set-Cookie: cross-site-cookie=name; SameSite=None; Secure');
session_start();
ob_start(); 

include "db_ayar.php";


date_default_timezone_set('Europe/Istanbul');
$tarihsaat=date("Y-m-d H:i:s");
$buay=date("m");
$buyil=date("Y");
$url=$_SERVER['SCRIPT_NAME'];



$ayar = $db->query("SELECT * FROM ayarlar")->fetch(PDO::FETCH_ASSOC);
$tema=$ayar['tema'];
$siteurl = $ayar['siteurl'];
$logo = $ayar['logo'];
$siteadi = $ayar['siteadi'];
$description = $ayar['description'];
$keyword = $ayar['keyword'];
$siteposta = $ayar['posta'];
$sitetel = $ayar['tel'];
$siteadres = $ayar['adres'];
$sitepostasifre = $ayar['postasifre'];
$sitepostasunucu = $ayar['postasunucu'];
$sitesunucuportu = $ayar['sunucuportu'];
$yetkiliid = $ayar['yetkiliid'];
$merchant_id = $ayar['merchant_id'];
$merchant_key = $ayar['merchant_key'];
$merchant_salt = $ayar['merchant_salt'];
$smsbaslik=$ayar['smsbaslik'];
$smsmusterino=$ayar['smsmusterino'];
$smskullaniciadi=$ayar['smskullaniciadi'];
$smssifre=$ayar['smssifre'];
$twitter = $ayar['twitter'];
$facebook = $ayar['facebook'];
$instagram = $ayar['instagram'];
$googleplus = $ayar['googleplus'];
$maxteklifsayisi = $ayar['maxteklifsayisi'];
$minteklif = $ayar['minteklif'];
$teklifucreti = $ayar['teklifucreti'];
$komisyonucreti = $ayar['komisyonucreti'];
$odemeyontemi = $ayar['odemeyontemi'];



function seflink($text){
	$find = array("/Ğ/","/Ü/","/Ş/","/İ/","/Ö/","/Ç/","/ğ/","/ü/","/ş/","/ı/","/ö/","/ç/");
	$degis = array("G","U","S","I","O","C","g","u","s","i","o","c");
	$text = preg_replace("/[^0-9a-zA-ZÄzÜŞİÖÇğüşıöç]/"," ",$text);
	$text = preg_replace($find,$degis,$text);
	$text = preg_replace("/ +/"," ",$text);
	$text = preg_replace("/ /","-",$text);
	$text = preg_replace("/\s/","",$text);
	$text = strtolower($text);
	$text = preg_replace("/^-/","",$text);
	$text = preg_replace("/-$/","",$text);
	return $text;
}

function gizle($str){
   $donustur = explode(' ', $str);
   $before = $donustur[0];
   $after = "*****";
   return substr($before,0,1).$after;
}

//Tarayıcı Bilgisi
function browser_al() 
{ 
	return strpos($_SERVER['HTTP_USER_AGENT'], "Chrome");
}


function cevrimici($time){
   if(time()-$time<30){
	return "1";
   }else{
	return "0";
   }
}

function sayi($deger){
   $deger=number_format($deger,2,",",".");
   return $deger;
}

function gecenzaman ($zaman){
	if($zaman=='0'){
	return 'Giriş Yapmadı';
	}else{
	$zaman_farki = time() - $zaman;
	$saniye = $zaman_farki;
	$dakika = round($zaman_farki/60);
	$saat = round($zaman_farki/3600);
	$gun = round($zaman_farki/86400);
	$hafta = round($zaman_farki/604800);
	$ay = round($zaman_farki/2419200);
	$yil = round($zaman_farki/29030400);
	if( $saniye < 60 ){
		return 'Az önce';
	} else if ( $dakika < 60 ){
		return str_replace("%d",$dakika,'%d dk önce');
	} else if ( $saat < 24 ){
		return str_replace("%d",$saat,'%d saat önce');
	} else if ( $gun < 7 ){
		return str_replace("%d",$gun,'%d gün önce');
	} else if ( $hafta < 4 ){
		return str_replace("%d",$hafta,'%d hafta önce');
	} else if ( $ay < 12 ){
		return str_replace("%d",$ay,'%d ay önce');
	} else {
		return str_replace("%d",$yil,'%d yıl önce');
	}
	}
}


function bildirimekle($buyeid,$mesaj,$link){
global $db;
$yeni = $db->prepare("INSERT INTO bildirimler SET uyeid = :uyeid, mesaj = :mesaj, link = :link ");
$yeni->bindValue(':uyeid', $buyeid);
$yeni->bindValue(':mesaj', $mesaj);
$yeni->bindValue(':link', $link);
$yeni->execute();
} 

/*
if(dirname($url)=='/'){
include 'panel/bower_components/phpmailer/class.phpmailer.php';
}else{
include 'bower_components/phpmailer/class.phpmailer.php';
}
function epostagonder($epostalar,$epostakonu,$epostamesaj){
global $siteadi;
global $siteurl;
global $sitepostasunucu;
global $sitesunucuportu;
global $siteposta;
global $sitepostasifre;

$sablon="
<table width=\"100%\" cellspacing=\"0\">
<tr><td style=\"border:1px solid #ddd;padding:10px;\" ><img src=\"".$siteurl."/assets/resimler/logo-1.png?v=1\" style=\"margin-right:5px;height:60px;float:left\" > <h2 style=\"font-size:1.5em;margin-top:0px;margin-bottom:0px;\"><b></b></h2></td></tr>
<tr><td style=\"border:1px solid #ddd;padding:10px;font-size:18px;\">".$epostamesaj."</td></tr>
<tr><td style=\"border:1px solid #ddd;padding:10px;\">
<p><a href=\"".$siteurl."\">".$siteurl."</a></p>
</td></tr>
</table>
";

		$mail = new PHPMailer();
		$mail->IsSMTP();
		$mail->SMTPAuth = true;
		$mail->Host = $sitepostasunucu;
		$mail->Port = $sitesunucuportu;
		$mail->Username = $siteposta;
		$mail->Password = $sitepostasifre;
		$mail->SetFrom($mail->Username, $siteadi);

if(strpos($epostalar, ',') === false){
		$mail->AddBCC($epostalar, $siteadi);
}else{
$tumepostalar = explode(",", $epostalar);
foreach($tumepostalar as $eposta)
{
		$mail->AddBCC($eposta, $siteadi);
}
}
		$mail->CharSet = 'UTF-8';
		$mail->Subject = $epostakonu;
		$mail->IsHTML(true); 
		$mail->Body = $sablon;
		if($mail->Send()) {
		$mailsonuc='ok';
		} else {
		$mailsonuc=$mail->ErrorInfo;
		}
}
//epostagonder('yahyaaydin87@gmail.com','Deneme Konusu 6','Deneme içeriği 6');
*/


?>