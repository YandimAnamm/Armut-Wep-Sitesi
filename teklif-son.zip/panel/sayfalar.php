<?php
include "db.php";
include "kontrol.php";
$sayfa="Sayfalar";
?>

<?php
if( isset($_GET['silid']) ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$query = $db->prepare("DELETE FROM sayfalar WHERE id = :id");
$delete = $query->execute(array(
'id' => $_GET['silid']
));
header("Location: ?");
exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteadi?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>


</head>
<body class="hold-transition <?=$tema?> sidebar-mini">
<div class="wrapper">

<?php
include "ust.php";
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!---------------------------------------------- Main content --------------------------------------------->
    <section class="content container-fluid" style="min-height:600px;">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><?=$sayfa?></h3>
          <div class="box-tools pull-right">
            <a href="sayfaekle.php" class="btn btn-success btn-sm" ><i class="fa fa-plus"></i> Yeni Kayıt</a>
          </div>
        </div>
        <div class="box-body" style="min-height:400px;">

<?php
$query = $db->prepare("SELECT * FROM sayfalar");
$query->execute();
$verisay = $query->rowCount();
?>
<?php if($verisay == "0"){ ?>
<div class="alert alert-warning">Kayıt Yok!</div>
<?php }else{ ?>
<table class="table table-stripped">
<tr class="active">
<td class="text-bold text-left">Sayfa</td>
<td class="text-bold text-center" width="100">Hit</td>
<td class="text-bold text-center" width="200">Oluşturma</td>
<td class="text-bold text-center" width="150">İşlem</td>
</tr>
<?php
while($row=$query->fetch(PDO::FETCH_ASSOC)) {
?>
<tr class="<?php echo $row['durum']!=='Evet' ? 'warning':'';?>">
<td class="text-bold text-left"><?=$row['baslik']?></td>
<td class="text-bold text-center"><?=$row['hit']?></td>
<td class="text-bold text-center">
<?php 
$tarih=new DateTime($row['tarih']);
echo $tarih->format('d/m/Y H:i'); 
?>
</td>
<td class="text-bold text-center">
<a href="sayfaguncelle.php?id=<?=$row['id']?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a> 
<a href="?silid=<?=$row['id']?>" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a>
</td>
</tr>
<?php } ?>

</table>

<?php } ?>



        </div>
        <!-- /.box-body -->
        <div class="box-footer">
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->


    </section>
    <!----------------------------------------------- /.content ------------------------------------------------>
  </div>
  <!-- /.content-wrapper -->


<?php
include "alt.php";
?>






</body>
</html>