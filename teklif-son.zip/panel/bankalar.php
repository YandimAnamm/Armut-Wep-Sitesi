<?php
include "db.php";
include "kontrol.php";
$sayfa="Banka Hesapları";
?>

<?php
if( isset($_GET['silid']) ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$query = $db->prepare("DELETE FROM bankahesaplari WHERE id = :id");
$delete = $query->execute(array(
'id' => $_GET['silid']
));

header("Location: ?");
exit();
}
?>



<?php
if( isset($_GET['islem']) ){
if( $_GET['islem']=="kaydet" ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$yeni = $db->prepare("INSERT INTO bankahesaplari SET banka = :banka, isim=:isim, iban=:iban ");
$yeni->bindValue(':banka', $_POST['banka']);
$yeni->bindValue(':isim', $_POST['isim']);
$yeni->bindValue(':iban', $_POST['iban']);
$yeni->execute();

if($yeni){
    header("Location: ?");
	exit();
}

}}
?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteadi?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>


</head>
<body class="hold-transition <?=$tema?> sidebar-mini">
<div class="wrapper">

<?php
include "ust.php";
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!---------------------------------------------- Main content --------------------------------------------->
    <section class="content container-fluid" style="min-height:600px;">

<div class="row">
<div class="col-md-8">
      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><?=$sayfa?></h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#yenipopup"><i class="fa fa-plus"></i> Yeni Kayıt</button>
          </div>
        </div>
        <div class="box-body" style="min-height:400px;">

<?php
$query = $db->prepare("SELECT * FROM bankahesaplari order by id asc");
$query->execute();
$verisay = $query->rowCount();
?>
<?php if($verisay == "0"){ ?>
<div class="alert alert-warning">Kayıt Yok!</div>
<?php }else{ ?>
<table class="table table-striped" >
<?php
while($row=$query->fetch(PDO::FETCH_ASSOC)) {
?>
<tr>
<td class="text-left"><?=$row['banka']?></td>
<td class="text-left"><?=$row['isim']?></td>
<td class="text-left"><?=$row['iban']?></td>
<td class="text-right"><a class="btn btn-danger btn-sm" href="?silid=<?=$row['id']?>"><i class="fa fa-trash-o"></i> Sil</a></td>
</tr>
<?php } ?>

</table>

<?php } ?>


<div class="modal fade" id="yenipopup">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Yeni Kayıt</h4>
      </div>
<form action="?islem=kaydet" method="post" >
      <div class="modal-body">

<div class="form-group">
<label>Banka</label>
<input type="text" class="form-control" placeholder="" value="" name="banka" required>
</div>

<div class="form-group">
<label>Hesap Sahibi</label>
<input type="text" class="form-control" placeholder="" value="" name="isim" required>
</div>

<div class="form-group">
<label>İban No</label>
<input type="text" class="form-control" placeholder="" value="" name="iban" required>
</div>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Vazgeç</button>
        <button type="submit" class="btn btn-primary">Kaydet</button>
      </div>
</form>                                    
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->



        </div>
        <!-- /.box-body -->
        <div class="box-footer">
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->
</div>
</div>


    </section>
    <!----------------------------------------------- /.content ------------------------------------------------>
  </div>
  <!-- /.content-wrapper -->


<?php
include "alt.php";
?>




</body>
</html>