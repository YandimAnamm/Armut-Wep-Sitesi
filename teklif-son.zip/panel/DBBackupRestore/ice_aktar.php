<?php
ob_start();

$dbhost = "localhost"; //Veritabanın bulunduğu host
$dbuser = "root"; //Veritabanı Kullanıcı Adı
$dbpass = ""; //Veritabanı Şifresi
$dbdata = "mysql_vt"; //Veritabanı Adı

include 'DBBackupRestore.class.php'; //DBBackup.class.php dosyamızı dahil ediyoruz
$dbBackup = new DBYedek(); // class'imizla $dbBackup nesnemizi olusturduk

	
	$dosya = 'temp/backup-mysql_vt-22-08-2019_20-42-23.sql'; // içe aktarımı yapılacak veritabanı.
	// maxKomut değişkeni yüksek tutmak aynı anda daha fazla verinin işlenmesine olanak tanır ancak hostu yorar
	// echo ini_get('max_execution_time'); ile php.ini dosyasındaki değeri kontrol edebilirsiniz öntanımlı süre genelde 30 saniyedir
    $maxKomut = 8; // php.ini dosyasındaki maksimum komut dosyası yürütme sınırınızdan daha az olmalı.
	
	$dbBackup->Ice_Aktar($dosya, $maxKomut); 


$dbBackup->kapat();// $dbBackup nesnemizi kapattik 

ob_end_flush();
?>