
<?php
include "db.php";
include "kontrol.php";
?>

<?php
if( isset($_GET['tema']) ){
$yeni = $db->prepare("UPDATE ayarlar SET tema = :tema where id=1 ");
$yeni->bindValue(':tema', $_GET['tema']);
$yeni->execute();

if($yeni){
    echo "TAMAM";
}

}
?>
