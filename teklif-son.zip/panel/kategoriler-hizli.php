<?php
include "db.php";
include "kontrol.php";
$sayfa="Kategoriler";

if(isset($_GET["katid"])){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
  $dizin = 'upload/img/';
  $yuklenecek_dosya = $dizin . basename($_FILES['yenikatresim']['name']);

  if (move_uploaded_file($_FILES['yenikatresim']['tmp_name'], $yuklenecek_dosya))
  {
      $resup = $db->prepare("UPDATE kategoriler SET resim = :resim where id = :id");
      $resup->execute(array(
      'id' => $_GET['katid'],
      'resim' => '/panel/upload/img/'.$_FILES["yenikatresim"]["name"]
      ));
      header("Location: ?");
  }

}

?>

<?php
if( isset($_GET['silid']) ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$id=$_GET['silid'];
$ids="";
foreach($db->query("SELECT * FROM kategoriler where id=".$id." order by id asc") as $row1) {
$ids=$ids.",".$row1['id'];
foreach($db->query("SELECT * FROM kategoriler where ustkat=".$row1['id']." order by id asc") as $row2) {
$ids=$ids.",".$row2['id'];
}
}

$ids=ltrim($ids,",");
$q = $db->prepare("DELETE FROM kategoriler WHERE id in (".$ids.") ");
$q->execute();

header("Location: ?");
}
?>



<?php
if( isset($_GET['islem']) ){
if( $_GET['islem']=="kaydet" ){
if($yetki=='11'){
header("Location: ?error=Demo yetkileri kısıtlıdır!");
exit();
}
$yeni = $db->prepare("INSERT INTO kategoriler SET baslik = :baslik, ustkat = :ustkat, link = :link ");
$yeni->bindValue(':baslik', $_POST['baslik']);
$yeni->bindValue(':ustkat', $_POST['ustkat']);
$yeni->bindValue(':link', $_POST['link']);
$yeni->execute();

if($yeni){
    header("Location: ?");
}

}}

if(isset($_GET['katsec']) ){
$katid=$_GET['katsec'];
$_SESSION['katid']=$katid;
}else if(!empty($_SESSION['katid'])){
$katid=$_SESSION['katid'];
}
?>





<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?=$siteadi?></title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){    
 $(".seflink").on("keyup focusout", function() {
	nereye = $(this).attr("id");
    str = $(this).val();
    str =replaceSpecialChars(str);
    str=str.toLowerCase();
    str =str.replace( /\s\s+/g, ' ' ).replace(/[^a-z0-9\s]/gi, '').replace(/[^\w]/ig, "-");
   function replaceSpecialChars(str) {
            var specialChars = [["ş", "s"], ["ğ", "g"], ["ü", "u"], ["ı", "i"],["_", "-"],
                                ["ö", "o"], ["Ş", "S"], ["Ğ", "G"], ["Ç", "C"], ["ç", "c"],
                                ["Ü", "U"], ["İ", "I"], ["Ö", "O"], ["ş", "s"]];
            for (var i = 0; i < specialChars.length; i++) {
                str = str.replace(eval("/" + specialChars[i][0] + "/ig"), specialChars[i][1]);
            }
            return str;
        }
    $("."+nereye).val(str+'-<?=time()?>');
 });    
});
</script>

<style>
.pointer{cursor:pointer}
</style>

</head>
<body class="hold-transition <?=$tema?> sidebar-mini">
<div class="wrapper">

<?php
include "ust.php";
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!---------------------------------------------- Main content --------------------------------------------->
    <section class="content container-fluid" style="min-height:600px;">

<div class="row">
<div class="col-md-12">
      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><?=$sayfa?></h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-success btn-sm altmenuekle" data-ustkat="0" ><i class="fa fa-plus"></i> Yeni Kayıt</button>
          </div>
        </div>
        <div class="box-body" style="min-height:400px;">

<?php
$query = $db->prepare("SELECT * FROM kategoriler where ustkat=0 order by sira asc");
$query->execute();
$verisay = $query->rowCount();
?>
<?php if($verisay == "0"){ ?>
<div class="alert alert-warning">Kayıt Yok!</div>
<?php }else{ ?>
<div class="table-responsive">
<table class="table menuler" >
<tbody class="ui-sortable" id="sirala">
<?php
while($row=$query->fetch(PDO::FETCH_ASSOC)) {
?>
<tr class="success" id="eleman-<?php echo $row['id'] ?>">
<td class="text-center sortable ui-sortable-handle"><i class="fa fa-arrows"></i></td>
<td class="text-left text-bold pointer" id="ustmenu<?=$row['id']?>"><a href="?katsec=<?=$row['id']==$katid ? '0':$row['id']?>"><?=$row['baslik']?></a></td>
<td class="text-left"><?=$row['link']?></td>
<td class="text-right" style="width:250px;">
<button type="button" class="btn btn-primary btn-sm altmenuekle" data-ustkat="<?=$row['id']?>" ><i class="fa fa-plus"></i></button>
<a class="btn btn-primary btn-sm" href="adimsecenekleri.php?id=<?=$row['id']?>">Adımlar</a>
<a href="katguncelle.php?id=<?=$row['id']?>" class="btn btn-warning btn-sm" ><i class="fa fa-edit"></i></a> 
<button type="button" class="btn btn-danger btn-sm sil" data-id="<?=$row['id']?>" data-katno="kat1"><i class="fa fa-trash-o"></i></button>

  <form action="?katid=<?=$row['id']?>" style="float: right;" name="form<?=$row['id']?>" class="yeniresimyukleform" method="post" enctype="multipart/form-data">
    <label for="file-upload<?=$row['id']?>" class="custom-file-upload" rec_id="<?=$row['id']?>" style="background: <?php echo $row['resim'] !== "" ? "lightblue" : "white";?>;">
        <i class="fa fa-cloud-upload"></i>
    </label>
    <input id="file-upload<?=$row['id']?>" class="file-upload-class" style="display: none;" rec_id="<?=$row['id']?>" name="yenikatresim" type="file"/>
    <!-- <input type="submit" value="Yükle"> -->
  </form>
</td>
</tr>

<!-------------------KAT 2---------------------------->
<?php
if(!empty($katid)){
if($katid==$row['id']){
$query2 = $db->prepare("SELECT * FROM kategoriler where ustkat=".$row['id']." order by sira asc");
$query2->execute();
while($row2=$query2->fetch(PDO::FETCH_ASSOC)) {
?>
<tr class="info ustmenu<?=$row['id']?>" id="eleman-<?php echo $row2['id'] ?>">
<td class="text-center sortable ui-sortable-handle"><i class="fa fa-arrows"></i></td>
<td class="text-left text-bold pointer togglemenu" id="ustmenu<?=$row2['id']?>"><?=$row2['baslik']?></td>
<td class="text-left"><?=$row2['link']?></td>
<td class="text-right">
<a class="btn btn-primary btn-sm" href="adimsecenekleri.php?id=<?=$row2['id']?>">Adımlar</a>
<a href="katguncelle.php?id=<?=$row2['id']?>" class="btn btn-warning btn-sm" ><i class="fa fa-edit"></i></a> 
<button type="button" class="btn btn-danger btn-sm sil"  data-id="<?=$row2['id']?>" data-katno="kat2"><i class="fa fa-trash-o"></i></button> 

  <form action="?katid=<?=$row2['id']?>" style="float: right;" name="form<?=$row2['id']?>" class="yeniresimyukleform" method="post" enctype="multipart/form-data">
    <label for="file-upload<?=$row2['id']?>" class="custom-file-upload" rec_id="<?=$row2['id']?>" style="background: <?php echo $row2['resim'] !== "" ? "lightblue" : "white";?>;">
        <i class="fa fa-cloud-upload"></i>
    </label>
    <input id="file-upload<?=$row2['id']?>" class="file-upload-class" style="display: none;" rec_id="<?=$row2['id']?>" name="yenikatresim" type="file"/>
    <!-- <input type="submit" value="Yükle"> -->
  </form>
  
</td>
</tr>
<?php }}} ?>
<!-------------------KAT 2 X---------------------------->

<?php } ?>
</tbody>
</table>
<?php } ?>



<div class="modal fade" id="yeni">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Kategori Ekle</h4>
      </div>
	  <form action="?islem=kaydet" method="post">
      <div class="modal-body">

<div class="form-group">
<input type="hidden" class="ustkat" name="ustkat" value="" required>
<label>Kategori Başlığı</label>
<input type="text" class="form-control seflink" id="birinci" placeholder="Kategori Başlığı" value="" name="baslik" required>
</div>

<div class="form-group">
<label>Kategori Linki</label>
<input type="text" class="form-control birinci" placeholder="Seflink" value="" name="link" required>
</div>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Kapat</button>
        <button type="submit" class="btn btn-success" ><i class="fa fa-save"></i> Kaydet</button>
      </div>
	  </form>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->





<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script>
  $(function(){
    var idd;
    $(document.body).on("click", ".custom-file-upload", function(){
      idd = $(this).attr("rec_id");
    });
    $(document.body).on("change",".file-upload-class", function(){
      $("form[name=form"+idd+"]").submit();
    });
  });
</script>

<style>
  #file-upload {
    display: none;
}
.custom-file-upload {
    border: 1px solid #ccc;
    display: inline-block;
    padding: 4px 6px;
    margin-left: 5px;
    cursor: pointer;
    border-radius: 5px;
}
</style>


        </div>
        <!-- /.box-body -->
        <div class="box-footer">
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->
</div>
</div>


    </section>
    <!----------------------------------------------- /.content ------------------------------------------------>
  </div>
  <!-- /.content-wrapper -->


<?php
include "alt.php";
?>

<script>
$(".altmenuekle").click(function(){
	var ustkat=$(this).attr("data-ustkat");
	$(".ustkat").val(ustkat);
	$("#yeni").modal("show");
});


$(".sil").click(function(){
var r = confirm("Kategori ve varsa alt kategorileriyle silinecektir!");
if (r == true) {
	var id=$(this).attr("data-id");
	location.href="?silid="+id;
}
});
</script>



<script src="bower_components/jquery/dist/jquery-ui.min.js"></script>
<script src="bower_components/jquery/dist/jquery.ui.touch-punch.min.js"></script>
<script>
$(document).ready(function () {
    $("#sirala").sortable({  // sıralamanın yapılacağı ul nin id si
        revert: true, // sürükle bırak yaparken yavaş ve estetik olması için
        handle: ".sortable",
        stop: function (event, ui) {
            var data = $(this).sortable('serialize'); // sıralama verisini oluşturuyoruz
            $.ajax({
                type: "POST", // post metodunu kullanıyoruz
                data: data, // data verisini yolluyoruz
                url: "verisirala.php?tablo=kategoriler",  // post edeceğimiz sayfamızın yolu
                success: function (data) { // veri işlendikten sonra sonucu alıyoruz.
                    if (data.trim() == "success") {
                        //$('span').text(" Sonuç: Başarılı"); 
                        // span da işlem sonucu başarılı ise belirtiyoruz
                    }
                    else {
                        alert("Demo Yetkileri kısıtlıdır!");
                        // span da işlem sonucu başarısız ise belirtiyoruz
                    }
                }
            });
        }
    });
	$( "#sirali" ).disableSelection();
});

$('#widget').draggable(); 
</script>



</body>
</html>