/************* Main Js File ************************
    Template Name: Jobguru - Job Board HTML Template
    Author: Themescare
    Version: 1.0
    Copyright 2018
*************************************************************/


(function ($) {
	"use strict";

	jQuery(document).ready(function ($) {


		$(".chat-list").perfectScrollbar();

	});


}(jQuery));

