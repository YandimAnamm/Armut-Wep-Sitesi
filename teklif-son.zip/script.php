
      <!-- Favicon -->
      <link rel="icon" type="image/png" sizes="32x32" href="/assets/img/favicon/favicon-32x32.png?v=<?=$v?>">
      <!--Bootstrap css-->
      <link rel="stylesheet" href="/assets/css/bootstrap.css?v=<?=$v?>">
      <!--Font Awesome css-->
      <link rel="stylesheet" href="/assets/css/font-awesome.min.css?v=<?=$v?>">
      <!--Magnific css-->
      <link rel="stylesheet" href="/assets/css/magnific-popup.css?v=<?=$v?>">
      <!--Owl-Carousel css-->
      <link rel="stylesheet" href="/assets/css/owl.carousel.min.css?v=<?=$v?>">
      <link rel="stylesheet" href="/assets/css/owl.theme.default.min.css?v=<?=$v?>">
      <!--Animate css-->
      <link rel="stylesheet" href="/assets/css/animate.min.css?v=<?=$v?>">
      <!--Select2 css-->
      <link rel="stylesheet" href="/assets/css/select2.min.css?v=<?=$v?>">
      <!--Slicknav css-->
      <link rel="stylesheet" href="/assets/css/slicknav.min.css?v=<?=$v?>">
      <!--Bootstrap-Datepicker css-->
      <link rel="stylesheet" href="/assets/css/bootstrap-datepicker.min.css?v=<?=$v?>">
      <!--Jquery UI css-->
      <link rel="stylesheet" href="/assets/css/jquery-ui.min.css?v=<?=$v?>">
      <!--Perfect-Scrollbar css-->
      <link rel="stylesheet" href="/assets/css/perfect-scrollbar.min.css?v=<?=$v?>">
      <!--Site Main Style css-->
      <link rel="stylesheet" href="/assets/css/style.css?v=<?=$v?>">
      <!--Responsive css-->
      <link rel="stylesheet" href="/assets/css/responsive.css?v=<?=$v?>">


      <!--Jquery js-->
      <script src="/assets/js/jquery-3.0.0.min.js?v=<?=$v?>"></script>