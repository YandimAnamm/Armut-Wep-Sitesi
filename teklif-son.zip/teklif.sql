-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost:3306
-- Üretim Zamanı: 31 Ağu 2021, 17:06:04
-- Sunucu sürümü: 10.3.31-MariaDB-cll-lve
-- PHP Sürümü: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `u9274148_teklif`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `adimsecenekleri`
--

CREATE TABLE `adimsecenekleri` (
  `id` int(11) NOT NULL,
  `katid` int(11) NOT NULL,
  `baslik` text NOT NULL,
  `tur` text NOT NULL,
  `secenekler` text NOT NULL,
  `sira` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `adimsecenekleri`
--

INSERT INTO `adimsecenekleri` (`id`, `katid`, `baslik`, `tur`, `secenekler`, `sira`) VALUES
(13, 2, 'Dersi alacak kişi okula gidiyor mu?', 'radio', 'Yetişkin|Üniversite|Lise|Ortaokul|İlkokul|Okul öncesi', 0),
(14, 2, 'Amacı nedir?', 'checkbox', 'İş ingilizcesi|Okula destek|Konuşma pratiği|YDS|IELTS|TOEFL|PTE|Diğer', 0),
(15, 2, 'Hangi seviyede?', 'radio', 'Başlangıç (A1)|Temel (A2)|Orta (B1)|Orta üstü (B2)|İleri (C1)|Profesyonel (C2)', 0),
(16, 2, 'Hangi sıklıkta?', 'radio', 'Haftada 3 veya daha fazla|Haftada 2|Haftada 1|Diğer', 0),
(17, 2, 'Ders nerede / nasıl yapılsın?', 'radio', 'Kendi evimde|Öğretmenin evinde|Online (Webcam / Skype vb.)', 0),
(21, 8, 'İstenen hizmet süresi', 'radio', 'Yarım Gün|Tam Gün|İş Bitene Kadar', 0),
(22, 8, 'Hizmeti ne sıklıkla almayı düşünüyorsunuz?', 'radio', 'Tek Seferlik|Haftada 1 Kez|Haftada 2 Kez|Ayda 1 Kez|Ayda 2 Kez', 0),
(23, 8, 'Temizlik malzemelerinin tedariği kime ait?', 'radio', 'Temizlikçiye ait|Müşteriye ait', 0),
(24, 44, 'Hangi platform için yazılım isteniyor?', 'radio', 'Web Yazılımı|Android/IOS Yazılım|Masaüstü Yazılım (Windows/Linux)|Endüstriyel Cihaz Yazılımı (PLC,CNC vb.)|Diğer (Açıklamada belirtilecek)', 0),
(25, 44, 'Yazılım dili tercihi var mı?', 'radio', 'PHP|ASP.NET|JAVA|C++|Diğer (Açıklamada belirtilecek)|Farketmez', 0),
(27, 51, 'Kaç Adet L - Şeklinde Köşe Koltuğu?', 'radio', '0|1|2|3|4|5|6|7|8|9|10+', 0),
(28, 51, 'Kaç Adet üçlü koltuk ( kanepe - çekyat )?', 'radio', '0|1|2|3|4|5|6|7|8|9|10+', 0),
(30, 60, 'Kaç adet L-şeklinde köşe koltuğu?', 'radio', '0|1|2|3|4|5|6|7|8|9|10+', 0),
(31, 60, 'Kaç adet üçlü koltuk (kanepe, çekyat)?', 'radio', '0|1|2|3|4|5|6|7|8|9|10+', 0),
(32, 60, 'Kaç adet ikili koltuk (kanepe, çekyat)?', 'radio', '0|1|2|3|4|5|6|7|8|9|10+', 0),
(33, 60, 'Kaç adet tekli koltuk (veya berjer)?', 'radio', '0|1|2|3|4|5|6|7|8|9|10+', 0),
(34, 60, 'Koltuklar minderli mi?', 'radio', 'Minderli değil|Sadece yaslanma yerleri minderli|Hem oturma hem yaslanma yerleri minderli', 0),
(35, 60, 'Kaç adet sandalye?', 'radio', '0|1|2|3|4|5|6|7|8|9|10+', 0),
(36, 60, 'Sandalye Durumu?', 'radio', 'Sandalye, Oturum|Sandalye, Oturum + Yaslanma|Sandalye, Oturum + Yaslanma + Sırt', 0),
(37, 60, 'Kaç adet tek kişilik yatak?', 'radio', '0|1|2|3|4|5|6|7|8|9|10+', 0),
(38, 60, 'Kaç adet çift kişilik yatak', 'radio', '0|1|2|3|4|5|6|7|8|9|10+', 0),
(39, 15, 'Kaç oda var? (Salon Hariç)', 'radio', '1|2|3|4|5|6|7|8|9|10 ve üstü', 0),
(40, 15, 'Kaç banyo var?', 'radio', '1|2|3|4|5 ve Üstü', 0),
(41, 15, 'Kaç saat temizlik yapılsın?', 'radio', '1|2|3|4|5|6|7|8|9|10|11|12', 0),
(42, 15, 'Temizlik hangi sıklıkla yapılsın?', 'radio', 'Haftada 1|Haftada 2|2 Haftada 1|Tek Sefer', 0),
(43, 15, 'Evde köpek veya kedi var mı?', 'radio', 'Kedi Var|Köpek Var|Hiç Biri Yok', 0),
(44, 63, 'Camları silinecek mekan nedir?', 'radio', '1 Oda 1 Salon|2 Oda 1 Salon|3 Oda 1 Salon|4 Oda 1 Salon|5 Oda 1 Salon|Dublex |Triblex|Villa|Mağza|Ofis & İşyeri', 0),
(46, 16, 'Ofis Kaç Metrekare?', 'radio', '20|30|50|80|100|120|150|170|200|250|300|400|500|600|700|1000+', 0),
(48, 16, 'Kaç Saatlik Temizlik Yapılıcak', 'radio', '2|3|4|5|6|7|8|9|10', 0),
(60, 16, 'Hnagi Sıklıkta?', 'radio', 'Tek Sefer|Haftada 1 Gün|15 Günde 1|Haftada 2 Gün|Haftada 3 Gün|Haftada 4 Gün|Haftada 5 Gün|Haftada 6 Gün|Haftada 7 Gün', 0),
(61, 16, 'Temizliğe Neler Dahil Olsun?', 'checkbox', 'Masaların Silinmesi|Çöp Kovalarının Boşaltılması|Mutfak Temizliği|Yer Süpürme|İç Cam Temizliği|Dış Cam Temizliği|Halı Yıkama Temizleme|Petek ve Jaluzi Temizliği|Dip köşe detay temizlik', 0),
(62, 56, 'Kaç oda? (salon hariç)', 'radio', '1|2|3|4|5|6|7|8|9|10+', 0),
(63, 56, 'Kaç banyo?', 'radio', '1|2|3|4+', 0),
(64, 56, 'Kaç metrekare temizlenecek?', 'radio', '50|80|100|120|150|180|200|300|500+', 0),
(65, 56, 'Evin durumu nedir?', 'checkbox', 'Ev boş eşya yok|Boya badana / Sıva yapıldı|inşaat pisliği var / sıfır ev / tadilat|Cam bantları sökülücek', 0),
(66, 17, 'Temizlik hangi sıklıkla yapılsın?', 'radio', 'Tek Sefer|Haftada 1 Gün|Haftada 2 Gün|15 Günde 1', 0),
(67, 17, 'Apartman(lar) kaç katlı?', 'radio', 'Tek katlı|2 katlı|3 katlı|4 katlı|5 katlı|6-8 katlı|10+ katlı', 0),
(68, 17, 'Kaç daire var?', 'radio', '1-4|5-9|10-19|20-29|50-99|100+', 0),
(69, 17, 'Hangi hizmetler dahil olsun?', 'checkbox', 'Kapı önleri / koridor temizliği|Merdiven temizliği|Bahçe/çevre temizliği|Çöp toplama', 0),
(70, 57, 'Dış cephe camı temizlenecek bina kaç katlı?', 'radio', '1|2|3|4|5|6-7|8-9|10|11+', 0),
(71, 57, 'Vinç hizmeti kimden', 'radio', 'Hizmet verenden|Hizmet isteyenden', 0),
(72, 65, 'Kaç tane tişört, çamaşır gibi küçük parça ütülenecek?', 'radio', 'Küçük parça yok|5|10|15|20|25|30|40|50|60|80|100', 0),
(73, 65, 'Kaç tane gömlek, pantolon gibi orta boy parça?', 'radio', 'Orta boy parça yok|5|10|15|20|25|30|40|50|60|80|100', 0),
(74, 65, 'Kaç tane nevresim, çarşaf gibi büyük parça?', 'radio', 'Büyük parça yok|5|10|15|20|25|30|40|50', 0),
(75, 65, 'Ütü hangi sıklıkla yapılsın?', 'radio', 'Tek Sefer|Haftalık|2 Haftada 1', 0),
(76, 65, 'Ütü nerede yapılsın?', 'radio', 'Evimde yapılsın|Dışarıda yapılıp getirilsin|Fark etmez', 0),
(77, 66, 'Hangi sıklıkta?', 'radio', 'Hergün|2 günde 1|Haftada 3 kere|Ayda 1|Tek sefer', 0),
(78, 66, 'Havuz yaklaşık kaç metreküp? (en x boy x derinlik)', 'radio', '20|30|50|80|100|150|200|300|500|1000+', 0),
(79, 66, 'Havuz suyu yeşile dönmüş veya bulanık görünüyor mu?', 'radio', 'Evet|Hayır', 0),
(80, 66, 'Havuzunuz klorlu mu tuzlu mu?', 'radio', 'Klorlu|Tuzlu|Diğer|Bilmiyorum|Karar veremedim', 0),
(81, 70, 'Böcek Tipi Nedir?', 'radio', 'Hamam Böceği|Pire / Bit|Karınca|Fare|Tahta Kurusu|Diğer', 0),
(82, 70, 'İlaçlanacak mekan tipi?', 'radio', 'Ev - daire|Bina - Apartman|Bahçe|Fabrika|Resmi Kurum / Özel Kurum|Okul / Kolej', 0),
(83, 70, 'Toplam kaç m2 alan ilaçlanacak?', 'radio', '20|50|80|100|120|150|200|300|500|1000+', 0),
(84, 68, 'Böcek tipi nedir?', 'radio', 'Hamam Böceği|Pire / Bit|Karınca|Fare|Tahta Kurusu|Genel İlaçlama|Diğer', 0),
(85, 68, 'İlaçlanacak daire tipi?', 'radio', '1+1 daire|2+1 daire|3+1 daire|4+1 daire|5+1 daire|6+1 daire|7+1 daire|8+1 ve üstü', 0),
(86, 71, 'Fare Türü Nedir?', 'radio', 'Ev Faresi|Tarla Faresi|Lağım Faresi|Çatı Faresi', 0),
(87, 71, 'İlaçlanacak mekan tipi?', 'radio', 'Ev - daire|Bina|Bahçe|Tarla|Diğer', 0),
(88, 71, 'Toplam kaç m2 alan ilaçlanacak?', 'radio', '20|50|80|100|120|150|200|300|500|100+', 0),
(89, 58, 'Ne yaptırmak istiyorsun?', 'checkbox', 'İç Temizlik|Dış Temizlik|Pasta Cila|Dezenfeksiyon / sterilizasyon|Motor Temizliği|Çizik Giderme|Klima Temizlik|Koku Giderme|Boya Koruma|Cam Filmi|Seramik Kaplama|Jant Temizlik|Kaput Koruma Filmi|Diğer', 0),
(90, 52, 'Halı nerede yıkansın?', 'radio', 'Adresten alınıp teslim edilsin|Yerinde halı temizliği yapılsın', 0),
(91, 52, 'Kaç m2 Makine Halısı ve Halıfleks yıkanacak?', 'radio', '2|4|6|8|10|12|15|20|25|30|40|50|100+', 0),
(92, 52, 'Kaç m2 Shaggy Halı?', 'radio', '2|3|4|5|6|8|10|12|15|20|25+', 0),
(93, 52, 'Kaç m2 El Dokuma Halı?', 'radio', '2|3|4|5|6|8|10|12|15|20|25+', 0),
(94, 52, 'Kaç m2 Step Halı?', 'radio', '2|3|4|5|6|6|10|12|15|20|25+', 0),
(95, 52, 'Kaç m2 Çin veya Nepal Halı?', 'radio', '2|3|4|5|6|6|10|12|15|20|25+', 0),
(96, 52, 'Kaç m2 Diğer Halı?', 'radio', '2|3|4|5|6|8|10|12|15|20|25+', 0),
(98, 53, 'Kaç m2 Stor perde yıkanacak?', 'radio', '3|5|8|10|15|20|25', 0),
(99, 53, 'Bu perdeler toplam kaç adet?', 'radio', '1|2|3|4|5|6|7|8|9|10+', 0),
(100, 53, 'Korniş aparatı da duvardan sökülmeli mi? (örneğin taşınıyorsanız)', 'radio', 'Hayır, sadece perde sökülüp takılacak|Evet, korniş duvardan sökülüp takılacak', 0),
(101, 108, 'Kaç m2 Zebra perde yıkanacak?', 'radio', '3|5|8|10|15|20|25+', 0),
(102, 108, 'Bu perdeler toplam kaç adet?', 'radio', '1|2|3|4|5|6|7|8|9|10+', 0),
(103, 108, 'Korniş aparatı da duvardan sökülmeli mi? (örneğin taşınıyorsanız)', 'radio', 'Hayır, sadece perde sökülüp takılacak|Evet, korniş duvardan sökülüp takılacak', 0),
(104, 109, 'Kaç m2 Tül perde yıkanacak?', 'radio', '3|5|6|10|15|20|25+', 0),
(105, 109, 'Bu perdeler toplam kaç adet?', 'radio', '1|2|3|4|5|5|6|7|8|9|10+', 0),
(106, 109, 'Korniş aparatı da duvardan sökülmeli mi? (örneğin taşınıyorsanız)', 'radio', 'Hayır, sadece perde sökülüp takılacak|Evet, korniş duvardan sökülüp takılacak', 0),
(107, 110, 'Kaç m2 Fon perde yıkanacak?', 'radio', '3|5|8|10|15|20|25+', 0),
(108, 110, 'Bu perdeler toplam kaç adet?', 'radio', '1|2|3|4|5|6|7|8|9|10+', 0),
(109, 110, 'Korniş aparatı da duvardan sökülmeli mi? (örneğin taşınıyorsanız)', 'radio', 'Hayır, sadece perde sökülüp takılacak|Evet, korniş duvardan sökülüp takılacak', 0),
(110, 111, 'Dezenfekte edilecek alan tipi nedir?', 'radio', 'Ev|Ofis|Apartman|Fabrika|Otel|Araç|Okul|Kuaför|Spor Salonu|Eczane|Diğer', 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ayarlar`
--

CREATE TABLE `ayarlar` (
  `id` int(11) NOT NULL,
  `siteadi` text NOT NULL,
  `siteurl` text NOT NULL,
  `logo` text NOT NULL,
  `description` text NOT NULL,
  `keyword` text NOT NULL,
  `posta` text NOT NULL,
  `tel` text NOT NULL,
  `adres` text NOT NULL,
  `postasifre` text NOT NULL,
  `postasunucu` text NOT NULL,
  `sunucuportu` int(11) NOT NULL DEFAULT 587,
  `yetkiliid` int(11) NOT NULL,
  `smsbaslik` text NOT NULL,
  `smsmusterino` text NOT NULL,
  `smskullaniciadi` text NOT NULL,
  `smssifre` text NOT NULL,
  `merchant_id` text NOT NULL,
  `merchant_key` text NOT NULL,
  `merchant_salt` text NOT NULL,
  `tema` text NOT NULL,
  `facebook` text NOT NULL,
  `instagram` text NOT NULL,
  `googleplus` text NOT NULL,
  `twitter` text NOT NULL,
  `maxteklifsayisi` int(11) NOT NULL DEFAULT 0,
  `minteklif` decimal(12,2) NOT NULL DEFAULT 0.00,
  `teklifucreti` text NOT NULL,
  `komisyonucreti` text NOT NULL,
  `odemeyontemi` text NOT NULL,
  `teklifiletisim` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `ayarlar`
--

INSERT INTO `ayarlar` (`id`, `siteadi`, `siteurl`, `logo`, `description`, `keyword`, `posta`, `tel`, `adres`, `postasifre`, `postasunucu`, `sunucuportu`, `yetkiliid`, `smsbaslik`, `smsmusterino`, `smskullaniciadi`, `smssifre`, `merchant_id`, `merchant_key`, `merchant_salt`, `tema`, `facebook`, `instagram`, `googleplus`, `twitter`, `maxteklifsayisi`, `minteklif`, `teklifucreti`, `komisyonucreti`, `odemeyontemi`, `teklifiletisim`) VALUES
(1, 'Hizmet Teklif Scripti', 'http://siteniz.com', '/panel/upload/resimler/logo-1-11610478311.png', 'Teklif usulu hizmet sitesi', 'teklif,al,ver,iş,hizmet,uygun,fiyat', 'admin@siteniz.com', '+90(555) 555 55 55', 'SAMSUN', '123456', 'mail.siteniz.com', 587, 1, '', '', '', '', '', '', '', 'skin-green-light', '#', '#', '#', '#', 10, 40.00, '3', '2%', 'Kredi,Havale', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `bankahesaplari`
--

CREATE TABLE `bankahesaplari` (
  `id` int(11) NOT NULL,
  `banka` text DEFAULT NULL,
  `isim` text DEFAULT NULL,
  `iban` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `bankahesaplari`
--

INSERT INTO `bankahesaplari` (`id`, `banka`, `isim`, `iban`) VALUES
(1, 'Ziraat Bankası', 'Yahya Aydın', 'TR00 0000 0000 0000 0000 0000 00'),
(2, 'Halk Bankası', 'Yahya Aydın', 'TR00 0000 0000 0000 0000 0000 00');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `bildirimler`
--

CREATE TABLE `bildirimler` (
  `id` int(11) NOT NULL,
  `uyeid` int(11) NOT NULL DEFAULT 0,
  `mesaj` text DEFAULT NULL,
  `durum` int(11) NOT NULL DEFAULT 0,
  `tarih` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `galeri`
--

CREATE TABLE `galeri` (
  `id` int(11) NOT NULL,
  `adres` text DEFAULT NULL,
  `dosyano` text DEFAULT NULL,
  `tarih` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `galeri`
--

INSERT INTO `galeri` (`id`, `adres`, `dosyano`, `tarih`) VALUES
(3, '/panel/upload/resimler/1-5fd60e5ce9d9b.png', '1607863479', '2020-12-13 12:51:40'),
(4, '/panel/upload/resimler/1-5fd60e5d0e39d.png', '1607863479', '2020-12-13 12:51:41'),
(5, '/panel/upload/resimler/1-5fd60e5d27842.png', '1607863479', '2020-12-13 12:51:41'),
(6, '/panel/upload/resimler/1-5fd60e5d42a1c.png', '1607863479', '2020-12-13 12:51:41'),
(7, '/panel/upload/resimler/1-5fd60e5d5c99b.png', '1607863479', '2020-12-13 12:51:41'),
(8, '/panel/upload/resimler/1-5fd60e5d7847a.png', '1607863479', '2020-12-13 12:51:41'),
(9, '/panel/upload/resimler/1-5fd60e5d97b80.png', '1607863479', '2020-12-13 12:51:41'),
(10, '/panel/upload/resimler/1-5fd60e5dacfd6.png', '1607863479', '2020-12-13 12:51:41'),
(11, '/panel/upload/resimler/1-5fd60e5dc7c6d.png', '1607863479', '2020-12-13 12:51:41'),
(12, '/panel/upload/resimler/1-5fd60e5de27f8.png', '1607863479', '2020-12-13 12:51:41'),
(13, '/panel/upload/resimler/5fd67521c5b93.png', '1607889933', '2020-12-13 20:10:09'),
(14, '/panel/upload/resimler/5fd6772a6581e.png', '1607890622', '2020-12-13 20:18:50'),
(15, '/panel/upload/resimler/5fd679032424e.png', '1607890883', '2020-12-13 20:26:43'),
(16, '/panel/upload/resimler/11-5fda3c729e884.png', '1608137768', '2020-12-16 16:57:22'),
(18, '/panel/upload/resimler/2-6011ce25f2f10.png', '1611779405', '2021-01-27 20:33:41'),
(19, '/panel/upload/resimler/2-6011ce261a129.png', '1611779405', '2021-01-27 20:33:42'),
(20, '/panel/upload/resimler/2-6011ce263229f.png', '1611779405', '2021-01-27 20:33:42'),
(21, '/panel/upload/resimler/1-6013268b9ae7a.png', '4111611867752', '2021-01-28 21:03:07'),
(22, '/panel/upload/resimler/1-6013268c02a26.png', '4111611867752', '2021-01-28 21:03:08'),
(23, '/panel/upload/resimler/1-6013268c77339.png', '4111611867752', '2021-01-28 21:03:08'),
(24, '/panel/upload/resimler/1-6013271bc54ec.png', '4111611867752', '2021-01-28 21:05:31'),
(25, '/panel/upload/resimler/-6015add4a7b19.png', '8131612033475', '2021-01-30 19:04:52'),
(26, '/panel/upload/resimler/31-602020ae21964.png', '1612718180', '2021-02-07 17:17:34'),
(27, '/panel/upload/resimler/31-602020bdbf4f4.png', '1612718180', '2021-02-07 17:17:49'),
(28, '/panel/upload/resimler/602297a99dd19.png', '1612879773', '2021-02-09 14:09:45'),
(29, '/panel/upload/resimler/-6022a58069d8e.png', '1901612883317', '2021-02-09 15:08:48'),
(30, '/panel/upload/resimler/39-602579bd42822.png', '5131613068716', '2021-02-11 18:38:53'),
(31, '/panel/upload/resimler/-602588015a31b.png', '3731613072379', '2021-02-11 19:39:45'),
(32, '/panel/upload/resimler/-6026db3da7025.png', '5201613159208', '2021-02-12 19:47:09'),
(33, '/panel/upload/resimler/-602bae6ec8f22.png', '3041613475419', '2021-02-16 11:37:18'),
(34, '/panel/upload/resimler/43-6039077d029e6.png', '1614348714', '2021-02-26 14:36:45'),
(35, '/panel/upload/resimler/1-603aa113f0398.png', '1614455016', '2021-02-27 19:44:19'),
(36, '/panel/upload/resimler/36-6049015b53f66.png', '9441615397207', '2021-03-10 17:26:51'),
(41, '/panel/upload/resimler/36-604a4e82d3388.png', '1615482422', '2021-03-11 17:08:18'),
(42, '/panel/upload/resimler/36-604a4ebf6d771.png', '8281615482544', '2021-03-11 17:09:19'),
(43, '/panel/upload/resimler/47-6052649b4e358.png', '6571616012389', '2021-03-17 20:20:43'),
(44, '/panel/upload/resimler/36-605a13c3838ce.png', '1616515964', '2021-03-23 16:13:55'),
(45, '/panel/upload/resimler/36-605a13c3eb3b1.png', '1616515964', '2021-03-23 16:13:55'),
(46, '/panel/upload/resimler/36-605a13c4156ea.png', '1616515964', '2021-03-23 16:13:56'),
(47, '/panel/upload/resimler/36-605a13c42243f.png', '1616515964', '2021-03-23 16:13:56'),
(48, '/panel/upload/resimler/36-605a13c42c54d.png', '1616515964', '2021-03-23 16:13:56'),
(49, '/panel/upload/resimler/36-606c6e5f74250.png', '1617718848', '2021-04-06 14:21:19'),
(50, '/panel/upload/resimler/36-606c6eb56f602.png', '6141617718955', '2021-04-06 14:22:45'),
(51, '/panel/upload/resimler/36-606c6edd0552b.png', '8891617719000', '2021-04-06 14:23:25'),
(52, '/panel/upload/resimler/-607033ee6ef1a.png', '9961617965984', '2021-04-09 11:01:02'),
(53, '/panel/upload/resimler/-6075e34e0b5ae.png', '9481618338619', '2021-04-13 18:30:38'),
(54, '/panel/upload/resimler/-60873ba865f3e.png', '8071619475356', '2021-04-26 22:16:08'),
(55, '/panel/upload/resimler/57-608c4cbdda68f.png', '1619807336', '2021-04-30 18:30:21'),
(56, '/panel/upload/resimler/57-608c4cbe0c94c.png', '1619807336', '2021-04-30 18:30:22'),
(57, '/panel/upload/resimler/57-608c4cbe31712.png', '1619807336', '2021-04-30 18:30:22'),
(60, '/panel/upload/resimler/57-608c4cbe6ff0b.png', '1619807336', '2021-04-30 18:30:22'),
(61, '/panel/upload/resimler/57-608c4cbe8afb0.png', '1619807336', '2021-04-30 18:30:22'),
(62, '/panel/upload/resimler/57-608c4cbea64bb.png', '1619807336', '2021-04-30 18:30:22'),
(63, '/panel/upload/resimler/57-608c4cbebe7df.png', '1619807336', '2021-04-30 18:30:22'),
(64, '/panel/upload/resimler/58-608cb32275eef.png', '2311619833578', '2021-05-01 01:47:14'),
(65, '/panel/upload/resimler/-609588c2ed851.png', '4671620412601', '2021-05-07 18:36:51'),
(66, '/panel/upload/resimler/59-60a383600190c.png', '5441621328730', '2021-05-18 09:05:36'),
(67, '/panel/upload/resimler/59-60b52f52cfde0.png', '5911622486860', '2021-05-31 18:47:46'),
(68, '/panel/upload/resimler/-60ba8c0218767.png', '6321622838258', '2021-06-04 20:24:34'),
(69, '/panel/upload/resimler/-60c7d9f7bfd23.png', '2401623710183', '2021-06-14 22:36:39'),
(71, '/panel/upload/resimler/57-60d54e2a6d3c1.png', '1619807336', '2021-06-25 03:31:54'),
(72, '/panel/upload/resimler/-60e42b2ca824c.png', '5351625565992', '2021-07-06 10:06:36'),
(73, '/panel/upload/resimler/70-60f7e61d44e42.png', '6701626859013', '2021-07-21 09:17:17'),
(74, '/panel/upload/resimler/70-60f7e61e41b39.png', '6701626859013', '2021-07-21 09:17:18'),
(75, '/panel/upload/resimler/-61045890890ec.png', '2201627674621', '2021-07-30 19:52:48'),
(76, '/panel/upload/resimler/-610458914c348.png', '2201627674621', '2021-07-30 19:52:49'),
(77, '/panel/upload/resimler/-610458933a377.png', '2201627674621', '2021-07-30 19:52:51'),
(78, '/panel/upload/resimler/-61045894b1366.png', '2201627674621', '2021-07-30 19:52:52'),
(79, '/panel/upload/resimler/-61045896d2ebe.png', '2201627674621', '2021-07-30 19:52:54'),
(80, '/panel/upload/resimler/-6104589763ce3.png', '2201627674621', '2021-07-30 19:52:55'),
(81, '/panel/upload/resimler/-61045897e60a5.png', '2201627674621', '2021-07-30 19:52:55'),
(82, '/panel/upload/resimler/-610458986490c.png', '2201627674621', '2021-07-30 19:52:56'),
(83, '/panel/upload/resimler/-61045898e7834.png', '2201627674621', '2021-07-30 19:52:56'),
(84, '/panel/upload/resimler/-610458995635b.png', '2201627674621', '2021-07-30 19:52:57'),
(85, '/panel/upload/resimler/-61045899cd495.png', '2201627674621', '2021-07-30 19:52:57'),
(86, '/panel/upload/resimler/-6104589dea820.png', '2201627674621', '2021-07-30 19:53:01'),
(87, '/panel/upload/resimler/-6104589ee2a8b.png', '2201627674621', '2021-07-30 19:53:02'),
(88, '/panel/upload/resimler/-6104589fb4f29.png', '2201627674621', '2021-07-30 19:53:03'),
(89, '/panel/upload/resimler/-6104589fb7f6e.png', '2201627674621', '2021-07-30 19:53:03'),
(90, '/panel/upload/resimler/-610458a13603e.png', '2201627674621', '2021-07-30 19:53:05'),
(91, '/panel/upload/resimler/-610458a16bcc2.png', '2201627674621', '2021-07-30 19:53:05'),
(92, '/panel/upload/resimler/-610458a2a1cc5.png', '2201627674621', '2021-07-30 19:53:06'),
(93, '/panel/upload/resimler/-610458a35dc67.png', '2201627674621', '2021-07-30 19:53:07'),
(94, '/panel/upload/resimler/-610458a57d82b.png', '2201627674621', '2021-07-30 19:53:09'),
(95, '/panel/upload/resimler/70-6116d5e9be92d.png', '8571628886390', '2021-08-13 20:28:25'),
(96, '/panel/upload/resimler/70-611703561d1e0.png', '1628898055', '2021-08-13 23:42:14'),
(97, '/panel/upload/resimler/70-6117198057043.png', '1581628903793', '2021-08-14 01:16:48'),
(98, '/panel/upload/resimler/74-6117c4b2e9707.png', '1628947469', '2021-08-14 13:27:15'),
(99, '/panel/upload/resimler/74-6117c4b522a66.png', '1628947469', '2021-08-14 13:27:17'),
(100, '/panel/upload/resimler/74-6117c4b8a8f8b.png', '1628947469', '2021-08-14 13:27:20'),
(101, '/panel/upload/resimler/74-6117c4baeb36d.png', '1628947469', '2021-08-14 13:27:22'),
(102, '/panel/upload/resimler/74-6117c4bd20186.png', '1628947469', '2021-08-14 13:27:25'),
(103, '/panel/upload/resimler/74-6117c4bf243b1.png', '1628947469', '2021-08-14 13:27:27'),
(104, '/panel/upload/resimler/74-6117c4c127e86.png', '1628947469', '2021-08-14 13:27:29'),
(105, '/panel/upload/resimler/74-6117c4c3d09bb.png', '1628947469', '2021-08-14 13:27:31'),
(106, '/panel/upload/resimler/74-6117c4c5e12c5.png', '1628947469', '2021-08-14 13:27:33'),
(107, '/panel/upload/resimler/70-611823efc582b.png', '1628898055', '2021-08-14 20:13:35'),
(108, '/panel/upload/resimler/-611ea6e24b1cb.png', '8741629398739', '2021-08-19 18:45:54'),
(109, '/panel/upload/resimler/77-6126a642a3b57.png', '4481629922841', '2021-08-25 20:21:22');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hizmetler`
--

CREATE TABLE `hizmetler` (
  `id` int(11) NOT NULL,
  `uyeid` int(11) NOT NULL DEFAULT 0,
  `katid` int(11) NOT NULL,
  `baslik` text NOT NULL,
  `belgeler` text NOT NULL,
  `link` text NOT NULL,
  `detaylar` longtext NOT NULL,
  `enaz` int(11) NOT NULL DEFAULT 0,
  `encok` int(11) NOT NULL DEFAULT 0,
  `bolge` text NOT NULL,
  `galeri` text NOT NULL,
  `kapak` text NOT NULL,
  `olusturma` timestamp NOT NULL DEFAULT current_timestamp(),
  `durum` text NOT NULL,
  `anasayfa` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `hizmetler`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ilceler`
--

CREATE TABLE `ilceler` (
  `id` int(11) NOT NULL,
  `ilid` int(11) DEFAULT NULL,
  `il` text NOT NULL,
  `ilce` text NOT NULL,
  `link` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `ilceler`
--

INSERT INTO `ilceler` (`id`, `ilid`, `il`, `ilce`, `link`) VALUES
(1, 1, 'Adana', 'Seyhan', 'seyhan'),
(2, 1, 'Adana', 'Ceyhan', 'ceyhan'),
(3, 1, 'Adana', 'Feke', 'feke'),
(4, 1, 'Adana', 'Karaisalı', 'karaisali'),
(5, 1, 'Adana', 'Karataş', 'karatas'),
(6, 1, 'Adana', 'Kozan', 'kozan'),
(7, 1, 'Adana', 'Pozantı', 'pozanti'),
(8, 1, 'Adana', 'Saimbeyli', 'saimbeyli'),
(9, 1, 'Adana', 'Tufanbeyli', 'tufanbeyli'),
(10, 1, 'Adana', 'Yumurtalık', 'yumurtalik'),
(11, 1, 'Adana', 'Yüreğir', 'yuregir'),
(12, 1, 'Adana', 'Aladağ', 'aladag'),
(13, 1, 'Adana', 'İmamoğlu', 'imamoglu'),
(14, 1, 'Adana', 'Sarıçam', 'saricam'),
(15, 1, 'Adana', 'Çukurova', 'cukurova'),
(16, 2, 'Adıyaman', 'Merkez', 'merkez'),
(17, 2, 'Adıyaman', 'Besni', 'besni'),
(18, 2, 'Adıyaman', 'Çelikhan', 'celikhan'),
(19, 2, 'Adıyaman', 'Gerger', 'gerger'),
(20, 2, 'Adıyaman', 'Gölbaşı', 'golbasi'),
(21, 2, 'Adıyaman', 'Kahta', 'kahta'),
(22, 2, 'Adıyaman', 'Samsat', 'samsat'),
(23, 2, 'Adıyaman', 'Sincik', 'sincik'),
(24, 2, 'Adıyaman', 'Tut', 'tut'),
(25, 3, 'Afyonkarahisar', 'Merkez', 'merkez'),
(26, 3, 'Afyonkarahisar', 'Bolvadin', 'bolvadin'),
(27, 3, 'Afyonkarahisar', 'Çay', 'cay'),
(28, 3, 'Afyonkarahisar', 'Dazkırı', 'dazkiri'),
(29, 3, 'Afyonkarahisar', 'Dinar', 'dinar'),
(30, 3, 'Afyonkarahisar', 'Emirdağ', 'emirdag'),
(31, 3, 'Afyonkarahisar', 'İhsaniye', 'ihsaniye'),
(32, 3, 'Afyonkarahisar', 'Sandıklı', 'sandikli'),
(33, 3, 'Afyonkarahisar', 'Sinanpaşa', 'sinanpasa'),
(34, 3, 'Afyonkarahisar', 'Sultandağı', 'sultandagi'),
(35, 3, 'Afyonkarahisar', 'Şuhut', 'suhut'),
(36, 3, 'Afyonkarahisar', 'Başmakçı', 'basmakci'),
(37, 3, 'Afyonkarahisar', 'Bayat', 'bayat'),
(38, 3, 'Afyonkarahisar', 'İscehisar', 'iscehisar'),
(39, 3, 'Afyonkarahisar', 'Çobanlar', 'cobanlar'),
(40, 3, 'Afyonkarahisar', 'Evciler', 'evciler'),
(41, 3, 'Afyonkarahisar', 'Hocalar', 'hocalar'),
(42, 3, 'Afyonkarahisar', 'Kızılören', 'kiziloren'),
(43, 4, 'Ağrı', 'Merkez', 'merkez'),
(44, 4, 'Ağrı', 'Diyadin', 'diyadin'),
(45, 4, 'Ağrı', 'Doğubayazıt', 'dogubayazit'),
(46, 4, 'Ağrı', 'Eleşkirt', 'eleskirt'),
(47, 4, 'Ağrı', 'Hamur', 'hamur'),
(48, 4, 'Ağrı', 'Patnos', 'patnos'),
(49, 4, 'Ağrı', 'Taşlıçay', 'taslicay'),
(50, 4, 'Ağrı', 'Tutak', 'tutak'),
(51, 5, 'Amasya', 'Merkez', 'merkez'),
(52, 5, 'Amasya', 'Göynücek', 'goynucek'),
(53, 5, 'Amasya', 'Gümüşhacıköy', 'gumushacikoy'),
(54, 5, 'Amasya', 'Merzifon', 'merzifon'),
(55, 5, 'Amasya', 'Suluova', 'suluova'),
(56, 5, 'Amasya', 'Taşova', 'tasova'),
(57, 5, 'Amasya', 'Hamamözü', 'hamamozu'),
(58, 6, 'Ankara', 'Altındağ', 'altindag'),
(59, 6, 'Ankara', 'Ayaş', 'ayas'),
(60, 6, 'Ankara', 'Bala', 'bala'),
(61, 6, 'Ankara', 'Beypazarı', 'beypazari'),
(62, 6, 'Ankara', 'Çamlıdere', 'camlidere'),
(63, 6, 'Ankara', 'Çankaya', 'cankaya'),
(64, 6, 'Ankara', 'Çubuk', 'cubuk'),
(65, 6, 'Ankara', 'Elmadağ', 'elmadag'),
(66, 6, 'Ankara', 'Güdül', 'gudul'),
(67, 6, 'Ankara', 'Haymana', 'haymana'),
(68, 6, 'Ankara', 'Kalecik', 'kalecik'),
(69, 6, 'Ankara', 'Kızılcahamam', 'kizilcahamam'),
(70, 6, 'Ankara', 'Nallıhan', 'nallihan'),
(71, 6, 'Ankara', 'Polatlı', 'polatli'),
(72, 6, 'Ankara', 'Şereflikoçhisar', 'sereflikochisar'),
(73, 6, 'Ankara', 'Yenimahalle', 'yenimahalle'),
(74, 6, 'Ankara', 'Gölbaşı', 'golbasi'),
(75, 6, 'Ankara', 'Keçiören', 'kecioren'),
(76, 6, 'Ankara', 'Mamak', 'mamak'),
(77, 6, 'Ankara', 'Sincan', 'sincan'),
(78, 6, 'Ankara', 'Kazan', 'kazan'),
(79, 6, 'Ankara', 'Akyurt', 'akyurt'),
(80, 6, 'Ankara', 'Etimesgut', 'etimesgut'),
(81, 6, 'Ankara', 'Evren', 'evren'),
(82, 6, 'Ankara', 'Pursaklar', 'pursaklar'),
(83, 7, 'Antalya', 'Akseki', 'akseki'),
(84, 7, 'Antalya', 'Alanya', 'alanya'),
(85, 7, 'Antalya', 'Elmalı', 'elmali'),
(86, 7, 'Antalya', 'Finike', 'finike'),
(87, 7, 'Antalya', 'Gazipaşa', 'gazipasa'),
(88, 7, 'Antalya', 'Gündoğmuş', 'gundogmus'),
(89, 7, 'Antalya', 'Kaş', 'kas'),
(90, 7, 'Antalya', 'Korkuteli', 'korkuteli'),
(91, 7, 'Antalya', 'Kumluca', 'kumluca'),
(92, 7, 'Antalya', 'Manavgat', 'manavgat'),
(93, 7, 'Antalya', 'Serik', 'serik'),
(94, 7, 'Antalya', 'Demre', 'demre'),
(95, 7, 'Antalya', 'İbradı', 'ibradi'),
(96, 7, 'Antalya', 'Kemer', 'kemer'),
(97, 7, 'Antalya', 'Aksu', 'aksu'),
(98, 7, 'Antalya', 'Döşemealtı', 'dosemealti'),
(99, 7, 'Antalya', 'Kepez', 'kepez'),
(100, 7, 'Antalya', 'Konyaaltı', 'konyaalti'),
(101, 7, 'Antalya', 'Muratpaşa', 'muratpasa'),
(102, 8, 'Artvin', 'Ardanuç', 'ardanuc'),
(103, 8, 'Artvin', 'Arhavi', 'arhavi'),
(104, 8, 'Artvin', 'Merkez', 'merkez'),
(105, 8, 'Artvin', 'Borçka', 'borcka'),
(106, 8, 'Artvin', 'Hopa', 'hopa'),
(107, 8, 'Artvin', 'Şavşat', 'savsat'),
(108, 8, 'Artvin', 'Yusufeli', 'yusufeli'),
(109, 8, 'Artvin', 'Murgul', 'murgul'),
(110, 9, 'Aydın', 'Bozdoğan', 'bozdogan'),
(111, 9, 'Aydın', 'Çine', 'cine'),
(112, 9, 'Aydın', 'Germencik', 'germencik'),
(113, 9, 'Aydın', 'Karacasu', 'karacasu'),
(114, 9, 'Aydın', 'Koçarlı', 'kocarli'),
(115, 9, 'Aydın', 'Kuşadası', 'kusadasi'),
(116, 9, 'Aydın', 'Kuyucak', 'kuyucak'),
(117, 9, 'Aydın', 'Nazilli', 'nazilli'),
(118, 9, 'Aydın', 'Söke', 'soke'),
(119, 9, 'Aydın', 'Sultanhisar', 'sultanhisar'),
(120, 9, 'Aydın', 'Yenipazar', 'yenipazar'),
(121, 9, 'Aydın', 'Buharkent', 'buharkent'),
(122, 9, 'Aydın', 'İncirliova', 'incirliova'),
(123, 9, 'Aydın', 'Karpuzlu', 'karpuzlu'),
(124, 9, 'Aydın', 'Köşk', 'kosk'),
(125, 9, 'Aydın', 'Didim', 'didim'),
(126, 9, 'Aydın', 'Efeler', 'efeler'),
(127, 10, 'Balıkesir', 'Ayvalık', 'ayvalik'),
(128, 10, 'Balıkesir', 'Balya', 'balya'),
(129, 10, 'Balıkesir', 'Bandırma', 'bandirma'),
(130, 10, 'Balıkesir', 'Bigadiç', 'bigadic'),
(131, 10, 'Balıkesir', 'Burhaniye', 'burhaniye'),
(132, 10, 'Balıkesir', 'Dursunbey', 'dursunbey'),
(133, 10, 'Balıkesir', 'Edremit', 'edremit'),
(134, 10, 'Balıkesir', 'Erdek', 'erdek'),
(135, 10, 'Balıkesir', 'Gönen', 'gonen'),
(136, 10, 'Balıkesir', 'Havran', 'havran'),
(137, 10, 'Balıkesir', 'İvrindi', 'ivrindi'),
(138, 10, 'Balıkesir', 'Kepsut', 'kepsut'),
(139, 10, 'Balıkesir', 'Manyas', 'manyas'),
(140, 10, 'Balıkesir', 'Savaştepe', 'savastepe'),
(141, 10, 'Balıkesir', 'Sındırgı', 'sindirgi'),
(142, 10, 'Balıkesir', 'Susurluk', 'susurluk'),
(143, 10, 'Balıkesir', 'Marmara', 'marmara'),
(144, 10, 'Balıkesir', 'Gömeç', 'gomec'),
(145, 10, 'Balıkesir', 'Altıeylül', 'altieylul'),
(146, 10, 'Balıkesir', 'Karesi', 'karesi'),
(147, 11, 'Bilecik', 'Merkez', 'merkez'),
(148, 11, 'Bilecik', 'Bozüyük', 'bozuyuk'),
(149, 11, 'Bilecik', 'Gölpazarı', 'golpazari'),
(150, 11, 'Bilecik', 'Osmaneli', 'osmaneli'),
(151, 11, 'Bilecik', 'Pazaryeri', 'pazaryeri'),
(152, 11, 'Bilecik', 'Söğüt', 'sogut'),
(153, 11, 'Bilecik', 'Yenipazar', 'yenipazar'),
(154, 11, 'Bilecik', 'İnhisar', 'inhisar'),
(155, 12, 'Bingöl', 'Merkez', 'merkez'),
(156, 12, 'Bingöl', 'Genç', 'genc'),
(157, 12, 'Bingöl', 'Karlıova', 'karliova'),
(158, 12, 'Bingöl', 'Kiğı', 'kigi'),
(159, 12, 'Bingöl', 'Solhan', 'solhan'),
(160, 12, 'Bingöl', 'Adaklı', 'adakli'),
(161, 12, 'Bingöl', 'Yayladere', 'yayladere'),
(162, 12, 'Bingöl', 'Yedisu', 'yedisu'),
(163, 13, 'Bitlis', 'Adilcevaz', 'adilcevaz'),
(164, 13, 'Bitlis', 'Ahlat', 'ahlat'),
(165, 13, 'Bitlis', 'Merkez', 'merkez'),
(166, 13, 'Bitlis', 'Hizan', 'hizan'),
(167, 13, 'Bitlis', 'Mutki', 'mutki'),
(168, 13, 'Bitlis', 'Tatvan', 'tatvan'),
(169, 13, 'Bitlis', 'Güroymak', 'guroymak'),
(170, 14, 'Bolu', 'Merkez', 'merkez'),
(171, 14, 'Bolu', 'Gerede', 'gerede'),
(172, 14, 'Bolu', 'Göynük', 'goynuk'),
(173, 14, 'Bolu', 'Kıbrıscık', 'kibriscik'),
(174, 14, 'Bolu', 'Mengen', 'mengen'),
(175, 14, 'Bolu', 'Mudurnu', 'mudurnu'),
(176, 14, 'Bolu', 'Seben', 'seben'),
(177, 14, 'Bolu', 'Dörtdivan', 'dortdivan'),
(178, 14, 'Bolu', 'Yeniçağa', 'yenicaga'),
(179, 15, 'Burdur', 'Ağlasun', 'aglasun'),
(180, 15, 'Burdur', 'Bucak', 'bucak'),
(181, 15, 'Burdur', 'Merkez', 'merkez'),
(182, 15, 'Burdur', 'Gölhisar', 'golhisar'),
(183, 15, 'Burdur', 'Tefenni', 'tefenni'),
(184, 15, 'Burdur', 'Yeşilova', 'yesilova'),
(185, 15, 'Burdur', 'Karamanlı', 'karamanli'),
(186, 15, 'Burdur', 'Kemer', 'kemer'),
(187, 15, 'Burdur', 'Altınyayla', 'altinyayla'),
(188, 15, 'Burdur', 'Çavdır', 'cavdir'),
(189, 15, 'Burdur', 'Çeltikçi', 'celtikci'),
(190, 16, 'Bursa', 'Gemlik', 'gemlik'),
(191, 16, 'Bursa', 'İnegöl', 'inegol'),
(192, 16, 'Bursa', 'İznik', 'iznik'),
(193, 16, 'Bursa', 'Karacabey', 'karacabey'),
(194, 16, 'Bursa', 'Keles', 'keles'),
(195, 16, 'Bursa', 'Mudanya', 'mudanya'),
(196, 16, 'Bursa', 'Mustafakemalpaşa', 'mustafakemalpasa'),
(197, 16, 'Bursa', 'Orhaneli', 'orhaneli'),
(198, 16, 'Bursa', 'Orhangazi', 'orhangazi'),
(199, 16, 'Bursa', 'Yenişehir', 'yenisehir'),
(200, 16, 'Bursa', 'Büyükorhan', 'buyukorhan'),
(201, 16, 'Bursa', 'Harmancık', 'harmancik'),
(202, 16, 'Bursa', 'Nilüfer', 'nilufer'),
(203, 16, 'Bursa', 'Osmangazi', 'osmangazi'),
(204, 16, 'Bursa', 'Yıldırım', 'yildirim'),
(205, 16, 'Bursa', 'Gürsu', 'gursu'),
(206, 16, 'Bursa', 'Kestel', 'kestel'),
(207, 17, 'Çanakkale', 'Ayvacık', 'ayvacik'),
(208, 17, 'Çanakkale', 'Bayramiç', 'bayramic'),
(209, 17, 'Çanakkale', 'Biga', 'biga'),
(210, 17, 'Çanakkale', 'Bozcaada', 'bozcaada'),
(211, 17, 'Çanakkale', 'Çan', 'can'),
(212, 17, 'Çanakkale', 'Merkez', 'merkez'),
(213, 17, 'Çanakkale', 'Eceabat', 'eceabat'),
(214, 17, 'Çanakkale', 'Ezine', 'ezine'),
(215, 17, 'Çanakkale', 'Gelibolu', 'gelibolu'),
(216, 17, 'Çanakkale', 'Gökçeada', 'gokceada'),
(217, 17, 'Çanakkale', 'Lapseki', 'lapseki'),
(218, 17, 'Çanakkale', 'Yenice', 'yenice'),
(219, 18, 'Çankırı', 'Merkez', 'merkez'),
(220, 18, 'Çankırı', 'Çerkeş', 'cerkes'),
(221, 18, 'Çankırı', 'Eldivan', 'eldivan'),
(222, 18, 'Çankırı', 'Ilgaz', 'ilgaz'),
(223, 18, 'Çankırı', 'Kurşunlu', 'kursunlu'),
(224, 18, 'Çankırı', 'Orta', 'orta'),
(225, 18, 'Çankırı', 'Şabanözü', 'sabanozu'),
(226, 18, 'Çankırı', 'Yapraklı', 'yaprakli'),
(227, 18, 'Çankırı', 'Atkaracalar', 'atkaracalar'),
(228, 18, 'Çankırı', 'Kızılırmak', 'kizilirmak'),
(229, 18, 'Çankırı', 'Bayramören', 'bayramoren'),
(230, 18, 'Çankırı', 'Korgun', 'korgun'),
(231, 19, 'Çorum', 'Alaca', 'alaca'),
(232, 19, 'Çorum', 'Bayat', 'bayat'),
(233, 19, 'Çorum', 'Merkez', 'merkez'),
(234, 19, 'Çorum', 'İskilip', 'iskilip'),
(235, 19, 'Çorum', 'Kargı', 'kargi'),
(236, 19, 'Çorum', 'Mecitözü', 'mecitozu'),
(237, 19, 'Çorum', 'Ortaköy', 'ortakoy'),
(238, 19, 'Çorum', 'Osmancık', 'osmancik'),
(239, 19, 'Çorum', 'Sungurlu', 'sungurlu'),
(240, 19, 'Çorum', 'Boğazkale', 'bogazkale'),
(241, 19, 'Çorum', 'Uğurludağ', 'ugurludag'),
(242, 19, 'Çorum', 'Dodurga', 'dodurga'),
(243, 19, 'Çorum', 'Laçin', 'lacin'),
(244, 19, 'Çorum', 'Oğuzlar', 'oguzlar'),
(245, 20, 'Denizli', 'Acıpayam', 'acipayam'),
(246, 20, 'Denizli', 'Buldan', 'buldan'),
(247, 20, 'Denizli', 'Çal', 'cal'),
(248, 20, 'Denizli', 'Çameli', 'cameli'),
(249, 20, 'Denizli', 'Çardak', 'cardak'),
(250, 20, 'Denizli', 'Çivril', 'civril'),
(251, 20, 'Denizli', 'Güney', 'guney'),
(252, 20, 'Denizli', 'Kale', 'kale'),
(253, 20, 'Denizli', 'Sarayköy', 'saraykoy'),
(254, 20, 'Denizli', 'Tavas', 'tavas'),
(255, 20, 'Denizli', 'Babadağ', 'babadag'),
(256, 20, 'Denizli', 'Bekilli', 'bekilli'),
(257, 20, 'Denizli', 'Honaz', 'honaz'),
(258, 20, 'Denizli', 'Serinhisar', 'serinhisar'),
(259, 20, 'Denizli', 'Pamukkale', 'pamukkale'),
(260, 20, 'Denizli', 'Baklan', 'baklan'),
(261, 20, 'Denizli', 'Beyağaç', 'beyagac'),
(262, 20, 'Denizli', 'Bozkurt', 'bozkurt'),
(263, 20, 'Denizli', 'Merkezefendi', 'merkezefendi'),
(264, 21, 'Diyarbakır', 'Bismil', 'bismil'),
(265, 21, 'Diyarbakır', 'Çermik', 'cermik'),
(266, 21, 'Diyarbakır', 'Çınar', 'cinar'),
(267, 21, 'Diyarbakır', 'Çüngüş', 'cungus'),
(268, 21, 'Diyarbakır', 'Dicle', 'dicle'),
(269, 21, 'Diyarbakır', 'Ergani', 'ergani'),
(270, 21, 'Diyarbakır', 'Hani', 'hani'),
(271, 21, 'Diyarbakır', 'Hazro', 'hazro'),
(272, 21, 'Diyarbakır', 'Kulp', 'kulp'),
(273, 21, 'Diyarbakır', 'Lice', 'lice'),
(274, 21, 'Diyarbakır', 'Silvan', 'silvan'),
(275, 21, 'Diyarbakır', 'Eğil', 'egil'),
(276, 21, 'Diyarbakır', 'Kocaköy', 'kocakoy'),
(277, 21, 'Diyarbakır', 'Bağlar', 'baglar'),
(278, 21, 'Diyarbakır', 'Kayapınar', 'kayapinar'),
(279, 21, 'Diyarbakır', 'Sur', 'sur'),
(280, 21, 'Diyarbakır', 'Yenişehir', 'yenisehir'),
(281, 22, 'Edirne', 'Merkez', 'merkez'),
(282, 22, 'Edirne', 'Enez', 'enez'),
(283, 22, 'Edirne', 'Havsa', 'havsa'),
(284, 22, 'Edirne', 'İpsala', 'ipsala'),
(285, 22, 'Edirne', 'Keşan', 'kesan'),
(286, 22, 'Edirne', 'Lalapaşa', 'lalapasa'),
(287, 22, 'Edirne', 'Meriç', 'meric'),
(288, 22, 'Edirne', 'Uzunköprü', 'uzunkopru'),
(289, 22, 'Edirne', 'Süloğlu', 'suloglu'),
(290, 23, 'Elazığ', 'Ağın', 'agin'),
(291, 23, 'Elazığ', 'Baskil', 'baskil'),
(292, 23, 'Elazığ', 'Merkez', 'merkez'),
(293, 23, 'Elazığ', 'Karakoçan', 'karakocan'),
(294, 23, 'Elazığ', 'Keban', 'keban'),
(295, 23, 'Elazığ', 'Maden', 'maden'),
(296, 23, 'Elazığ', 'Palu', 'palu'),
(297, 23, 'Elazığ', 'Sivrice', 'sivrice'),
(298, 23, 'Elazığ', 'Arıcak', 'aricak'),
(299, 23, 'Elazığ', 'Kovancılar', 'kovancilar'),
(300, 23, 'Elazığ', 'Alacakaya', 'alacakaya'),
(301, 24, 'Erzincan', 'Çayırlı', 'cayirli'),
(302, 24, 'Erzincan', 'Merkez', 'merkez'),
(303, 24, 'Erzincan', 'İliç', 'ilic'),
(304, 24, 'Erzincan', 'Kemah', 'kemah'),
(305, 24, 'Erzincan', 'Kemaliye', 'kemaliye'),
(306, 24, 'Erzincan', 'Refahiye', 'refahiye'),
(307, 24, 'Erzincan', 'Tercan', 'tercan'),
(308, 24, 'Erzincan', 'Üzümlü', 'uzumlu'),
(309, 24, 'Erzincan', 'Otlukbeli', 'otlukbeli'),
(310, 25, 'Erzurum', 'Aşkale', 'askale'),
(311, 25, 'Erzurum', 'Çat', 'cat'),
(312, 25, 'Erzurum', 'Hınıs', 'hinis'),
(313, 25, 'Erzurum', 'Horasan', 'horasan'),
(314, 25, 'Erzurum', 'İspir', 'ispir'),
(315, 25, 'Erzurum', 'Karayazı', 'karayazi'),
(316, 25, 'Erzurum', 'Narman', 'narman'),
(317, 25, 'Erzurum', 'Oltu', 'oltu'),
(318, 25, 'Erzurum', 'Olur', 'olur'),
(319, 25, 'Erzurum', 'Pasinler', 'pasinler'),
(320, 25, 'Erzurum', 'Şenkaya', 'senkaya'),
(321, 25, 'Erzurum', 'Tekman', 'tekman'),
(322, 25, 'Erzurum', 'Tortum', 'tortum'),
(323, 25, 'Erzurum', 'Karaçoban', 'karacoban'),
(324, 25, 'Erzurum', 'Uzundere', 'uzundere'),
(325, 25, 'Erzurum', 'Pazaryolu', 'pazaryolu'),
(326, 25, 'Erzurum', 'Aziziye', 'aziziye'),
(327, 25, 'Erzurum', 'Köprüköy', 'koprukoy'),
(328, 25, 'Erzurum', 'Palandöken', 'palandoken'),
(329, 25, 'Erzurum', 'Yakutiye', 'yakutiye'),
(330, 26, 'Eskişehir', 'Çifteler', 'cifteler'),
(331, 26, 'Eskişehir', 'Mahmudiye', 'mahmudiye'),
(332, 26, 'Eskişehir', 'Mihalıççık', 'mihaliccik'),
(333, 26, 'Eskişehir', 'Sarıcakaya', 'saricakaya'),
(334, 26, 'Eskişehir', 'Seyitgazi', 'seyitgazi'),
(335, 26, 'Eskişehir', 'Sivrihisar', 'sivrihisar'),
(336, 26, 'Eskişehir', 'Alpu', 'alpu'),
(337, 26, 'Eskişehir', 'Beylikova', 'beylikova'),
(338, 26, 'Eskişehir', 'İnönü', 'inonu'),
(339, 26, 'Eskişehir', 'Günyüzü', 'gunyuzu'),
(340, 26, 'Eskişehir', 'Han', 'han'),
(341, 26, 'Eskişehir', 'Mihalgazi', 'mihalgazi'),
(342, 26, 'Eskişehir', 'Odunpazarı', 'odunpazari'),
(343, 26, 'Eskişehir', 'Tepebaşı', 'tepebasi'),
(344, 27, 'Gaziantep', 'Araban', 'araban'),
(345, 27, 'Gaziantep', 'İslahiye', 'islahiye'),
(346, 27, 'Gaziantep', 'Nizip', 'nizip'),
(347, 27, 'Gaziantep', 'Oğuzeli', 'oguzeli'),
(348, 27, 'Gaziantep', 'Yavuzeli', 'yavuzeli'),
(349, 27, 'Gaziantep', 'Şahinbey', 'sahinbey'),
(350, 27, 'Gaziantep', 'Şehitkamil', 'sehitkamil'),
(351, 27, 'Gaziantep', 'Karkamış', 'karkamis'),
(352, 27, 'Gaziantep', 'Nurdağı', 'nurdagi'),
(353, 28, 'Giresun', 'Alucra', 'alucra'),
(354, 28, 'Giresun', 'Bulancak', 'bulancak'),
(355, 28, 'Giresun', 'Dereli', 'dereli'),
(356, 28, 'Giresun', 'Espiye', 'espiye'),
(357, 28, 'Giresun', 'Eynesil', 'eynesil'),
(358, 28, 'Giresun', 'Merkez', 'merkez'),
(359, 28, 'Giresun', 'Görele', 'gorele'),
(360, 28, 'Giresun', 'Keşap', 'kesap'),
(361, 28, 'Giresun', 'Şebinkarahisar', 'sebinkarahisar'),
(362, 28, 'Giresun', 'Tirebolu', 'tirebolu'),
(363, 28, 'Giresun', 'Piraziz', 'piraziz'),
(364, 28, 'Giresun', 'Yağlıdere', 'yaglidere'),
(365, 28, 'Giresun', 'Çamoluk', 'camoluk'),
(366, 28, 'Giresun', 'Çanakçı', 'canakci'),
(367, 28, 'Giresun', 'Doğankent', 'dogankent'),
(368, 28, 'Giresun', 'Güce', 'guce'),
(369, 29, 'Gümüşhane', 'Merkez', 'merkez'),
(370, 29, 'Gümüşhane', 'Kelkit', 'kelkit'),
(371, 29, 'Gümüşhane', 'Şiran', 'siran'),
(372, 29, 'Gümüşhane', 'Torul', 'torul'),
(373, 29, 'Gümüşhane', 'Köse', 'kose'),
(374, 29, 'Gümüşhane', 'Kürtün', 'kurtun'),
(375, 30, 'Hakkari', 'Çukurca', 'cukurca'),
(376, 30, 'Hakkari', 'Merkez', 'merkez'),
(377, 30, 'Hakkari', 'Şemdinli', 'semdinli'),
(378, 30, 'Hakkari', 'Yüksekova', 'yuksekova'),
(379, 31, 'Hatay', 'Altınözü', 'altinozu'),
(380, 31, 'Hatay', 'Dörtyol', 'dortyol'),
(381, 31, 'Hatay', 'Hassa', 'hassa'),
(382, 31, 'Hatay', 'İskenderun', 'iskenderun'),
(383, 31, 'Hatay', 'Kırıkhan', 'kirikhan'),
(384, 31, 'Hatay', 'Reyhanlı', 'reyhanli'),
(385, 31, 'Hatay', 'Samandağ', 'samandag'),
(386, 31, 'Hatay', 'Yayladağı', 'yayladagi'),
(387, 31, 'Hatay', 'Erzin', 'erzin'),
(388, 31, 'Hatay', 'Belen', 'belen'),
(389, 31, 'Hatay', 'Kumlu', 'kumlu'),
(390, 31, 'Hatay', 'Antakya', 'antakya'),
(391, 31, 'Hatay', 'Arsuz', 'arsuz'),
(392, 31, 'Hatay', 'Defne', 'defne'),
(393, 31, 'Hatay', 'Payas', 'payas'),
(394, 32, 'Isparta', 'Atabey', 'atabey'),
(395, 32, 'Isparta', 'Eğirdir', 'egirdir'),
(396, 32, 'Isparta', 'Gelendost', 'gelendost'),
(397, 32, 'Isparta', 'Merkez', 'merkez'),
(398, 32, 'Isparta', 'Keçiborlu', 'keciborlu'),
(399, 32, 'Isparta', 'Senirkent', 'senirkent'),
(400, 32, 'Isparta', 'Sütçüler', 'sutculer'),
(401, 32, 'Isparta', 'Şarkikaraağaç', 'sarkikaraagac'),
(402, 32, 'Isparta', 'Uluborlu', 'uluborlu'),
(403, 32, 'Isparta', 'Yalvaç', 'yalvac'),
(404, 32, 'Isparta', 'Aksu', 'aksu'),
(405, 32, 'Isparta', 'Gönen', 'gonen'),
(406, 32, 'Isparta', 'Yenişarbademli', 'yenisarbademli'),
(407, 33, 'Mersin', 'Anamur', 'anamur'),
(408, 33, 'Mersin', 'Erdemli', 'erdemli'),
(409, 33, 'Mersin', 'Gülnar', 'gulnar'),
(410, 33, 'Mersin', 'Mut', 'mut'),
(411, 33, 'Mersin', 'Silifke', 'silifke'),
(412, 33, 'Mersin', 'Tarsus', 'tarsus'),
(413, 33, 'Mersin', 'Aydıncık', 'aydincik'),
(414, 33, 'Mersin', 'Bozyazı', 'bozyazi'),
(415, 33, 'Mersin', 'Çamlıyayla', 'camliyayla'),
(416, 33, 'Mersin', 'Akdeniz', 'akdeniz'),
(417, 33, 'Mersin', 'Mezitli', 'mezitli'),
(418, 33, 'Mersin', 'Toroslar', 'toroslar'),
(419, 33, 'Mersin', 'Yenişehir', 'yenisehir'),
(420, 34, 'İstanbul', 'Adalar', 'adalar'),
(421, 34, 'İstanbul', 'Bakırköy', 'bakirkoy'),
(422, 34, 'İstanbul', 'Beşiktaş', 'besiktas'),
(423, 34, 'İstanbul', 'Beykoz', 'beykoz'),
(424, 34, 'İstanbul', 'Beyoğlu', 'beyoglu'),
(425, 34, 'İstanbul', 'Çatalca', 'catalca'),
(426, 34, 'İstanbul', 'Eyüp', 'eyup'),
(427, 34, 'İstanbul', 'Fatih', 'fatih'),
(428, 34, 'İstanbul', 'Gaziosmanpaşa', 'gaziosmanpasa'),
(429, 34, 'İstanbul', 'Kadıköy', 'kadikoy'),
(430, 34, 'İstanbul', 'Kartal', 'kartal'),
(431, 34, 'İstanbul', 'Sarıyer', 'sariyer'),
(432, 34, 'İstanbul', 'Silivri', 'silivri'),
(433, 34, 'İstanbul', 'Şile', 'sile'),
(434, 34, 'İstanbul', 'Şişli', 'sisli'),
(435, 34, 'İstanbul', 'Üsküdar', 'uskudar'),
(436, 34, 'İstanbul', 'Zeytinburnu', 'zeytinburnu'),
(437, 34, 'İstanbul', 'Büyükçekmece', 'buyukcekmece'),
(438, 34, 'İstanbul', 'Kağıthane', 'kagithane'),
(439, 34, 'İstanbul', 'Küçükçekmece', 'kucukcekmece'),
(440, 34, 'İstanbul', 'Pendik', 'pendik'),
(441, 34, 'İstanbul', 'Ümraniye', 'umraniye'),
(442, 34, 'İstanbul', 'Bayrampaşa', 'bayrampasa'),
(443, 34, 'İstanbul', 'Avcılar', 'avcilar'),
(444, 34, 'İstanbul', 'Bağcılar', 'bagcilar'),
(445, 34, 'İstanbul', 'Bahçelievler', 'bahcelievler'),
(446, 34, 'İstanbul', 'Güngören', 'gungoren'),
(447, 34, 'İstanbul', 'Maltepe', 'maltepe'),
(448, 34, 'İstanbul', 'Sultanbeyli', 'sultanbeyli'),
(449, 34, 'İstanbul', 'Tuzla', 'tuzla'),
(450, 34, 'İstanbul', 'Esenler', 'esenler'),
(451, 34, 'İstanbul', 'Arnavutköy', 'arnavutkoy'),
(452, 34, 'İstanbul', 'Ataşehir', 'atasehir'),
(453, 34, 'İstanbul', 'Başakşehir', 'basaksehir'),
(454, 34, 'İstanbul', 'Beylikdüzü', 'beylikduzu'),
(455, 34, 'İstanbul', 'Çekmeköy', 'cekmekoy'),
(456, 34, 'İstanbul', 'Esenyurt', 'esenyurt'),
(457, 34, 'İstanbul', 'Sancaktepe', 'sancaktepe'),
(458, 34, 'İstanbul', 'Sultangazi', 'sultangazi'),
(459, 35, 'İzmir', 'Aliağa', 'aliaga'),
(460, 35, 'İzmir', 'Bayındır', 'bayindir'),
(461, 35, 'İzmir', 'Bergama', 'bergama'),
(462, 35, 'İzmir', 'Bornova', 'bornova'),
(463, 35, 'İzmir', 'Çeşme', 'cesme'),
(464, 35, 'İzmir', 'Dikili', 'dikili'),
(465, 35, 'İzmir', 'Foça', 'foca'),
(466, 35, 'İzmir', 'Karaburun', 'karaburun'),
(467, 35, 'İzmir', 'Karşıyaka', 'karsiyaka'),
(468, 35, 'İzmir', 'Kemalpaşa', 'kemalpasa'),
(469, 35, 'İzmir', 'Kınık', 'kinik'),
(470, 35, 'İzmir', 'Kiraz', 'kiraz'),
(471, 35, 'İzmir', 'Menemen', 'menemen'),
(472, 35, 'İzmir', 'Ödemiş', 'odemis'),
(473, 35, 'İzmir', 'Seferihisar', 'seferihisar'),
(474, 35, 'İzmir', 'Selçuk', 'selcuk'),
(475, 35, 'İzmir', 'Tire', 'tire'),
(476, 35, 'İzmir', 'Torbalı', 'torbali'),
(477, 35, 'İzmir', 'Urla', 'urla'),
(478, 35, 'İzmir', 'Beydağ', 'beydag'),
(479, 35, 'İzmir', 'Buca', 'buca'),
(480, 35, 'İzmir', 'Konak', 'konak'),
(481, 35, 'İzmir', 'Menderes', 'menderes'),
(482, 35, 'İzmir', 'Balçova', 'balcova'),
(483, 35, 'İzmir', 'Çiğli', 'cigli'),
(484, 35, 'İzmir', 'Gaziemir', 'gaziemir'),
(485, 35, 'İzmir', 'Narlıdere', 'narlidere'),
(486, 35, 'İzmir', 'Güzelbahçe', 'guzelbahce'),
(487, 35, 'İzmir', 'Bayraklı', 'bayrakli'),
(488, 35, 'İzmir', 'Karabağlar', 'karabaglar'),
(489, 36, 'Kars', 'Arpaçay', 'arpacay'),
(490, 36, 'Kars', 'Digor', 'digor'),
(491, 36, 'Kars', 'Kağızman', 'kagizman'),
(492, 36, 'Kars', 'Merkez', 'merkez'),
(493, 36, 'Kars', 'Sarıkamış', 'sarikamis'),
(494, 36, 'Kars', 'Selim', 'selim'),
(495, 36, 'Kars', 'Susuz', 'susuz'),
(496, 36, 'Kars', 'Akyaka', 'akyaka'),
(497, 37, 'Kastamonu', 'Abana', 'abana'),
(498, 37, 'Kastamonu', 'Araç', 'arac'),
(499, 37, 'Kastamonu', 'Azdavay', 'azdavay'),
(500, 37, 'Kastamonu', 'Bozkurt', 'bozkurt'),
(501, 37, 'Kastamonu', 'Cide', 'cide'),
(502, 37, 'Kastamonu', 'Çatalzeytin', 'catalzeytin'),
(503, 37, 'Kastamonu', 'Daday', 'daday'),
(504, 37, 'Kastamonu', 'Devrekani', 'devrekani'),
(505, 37, 'Kastamonu', 'İnebolu', 'inebolu'),
(506, 37, 'Kastamonu', 'Merkez', 'merkez'),
(507, 37, 'Kastamonu', 'Küre', 'kure'),
(508, 37, 'Kastamonu', 'Taşköprü', 'taskopru'),
(509, 37, 'Kastamonu', 'Tosya', 'tosya'),
(510, 37, 'Kastamonu', 'İhsangazi', 'ihsangazi'),
(511, 37, 'Kastamonu', 'Pınarbaşı', 'pinarbasi'),
(512, 37, 'Kastamonu', 'Şenpazar', 'senpazar'),
(513, 37, 'Kastamonu', 'Ağlı', 'agli'),
(514, 37, 'Kastamonu', 'Doğanyurt', 'doganyurt'),
(515, 37, 'Kastamonu', 'Hanönü', 'hanonu'),
(516, 37, 'Kastamonu', 'Seydiler', 'seydiler'),
(517, 38, 'Kayseri', 'Bünyan', 'bunyan'),
(518, 38, 'Kayseri', 'Develi', 'develi'),
(519, 38, 'Kayseri', 'Felahiye', 'felahiye'),
(520, 38, 'Kayseri', 'İncesu', 'incesu'),
(521, 38, 'Kayseri', 'Pınarbaşı', 'pinarbasi'),
(522, 38, 'Kayseri', 'Sarıoğlan', 'sarioglan'),
(523, 38, 'Kayseri', 'Sarız', 'sariz'),
(524, 38, 'Kayseri', 'Tomarza', 'tomarza'),
(525, 38, 'Kayseri', 'Yahyalı', 'yahyali'),
(526, 38, 'Kayseri', 'Yeşilhisar', 'yesilhisar'),
(527, 38, 'Kayseri', 'Akkışla', 'akkisla'),
(528, 38, 'Kayseri', 'Talas', 'talas'),
(529, 38, 'Kayseri', 'Kocasinan', 'kocasinan'),
(530, 38, 'Kayseri', 'Melikgazi', 'melikgazi'),
(531, 38, 'Kayseri', 'Hacılar', 'hacilar'),
(532, 38, 'Kayseri', 'Özvatan', 'ozvatan'),
(533, 39, 'Kırklareli', 'Babaeski', 'babaeski'),
(534, 39, 'Kırklareli', 'Demirköy', 'demirkoy'),
(535, 39, 'Kırklareli', 'Merkez', 'merkez'),
(536, 39, 'Kırklareli', 'Kofçaz', 'kofcaz'),
(537, 39, 'Kırklareli', 'Lüleburgaz', 'luleburgaz'),
(538, 39, 'Kırklareli', 'Pehlivanköy', 'pehlivankoy'),
(539, 39, 'Kırklareli', 'Pınarhisar', 'pinarhisar'),
(540, 39, 'Kırklareli', 'Vize', 'vize'),
(541, 40, 'Kırşehir', 'Çiçekdağı', 'cicekdagi'),
(542, 40, 'Kırşehir', 'Kaman', 'kaman'),
(543, 40, 'Kırşehir', 'Merkez', 'merkez'),
(544, 40, 'Kırşehir', 'Mucur', 'mucur'),
(545, 40, 'Kırşehir', 'Akpınar', 'akpinar'),
(546, 40, 'Kırşehir', 'Akçakent', 'akcakent'),
(547, 40, 'Kırşehir', 'Boztepe', 'boztepe'),
(548, 41, 'Kocaeli', 'Gebze', 'gebze'),
(549, 41, 'Kocaeli', 'Gölcük', 'golcuk'),
(550, 41, 'Kocaeli', 'Kandıra', 'kandira'),
(551, 41, 'Kocaeli', 'Karamürsel', 'karamursel'),
(552, 41, 'Kocaeli', 'Körfez', 'korfez'),
(553, 41, 'Kocaeli', 'Derince', 'derince'),
(554, 41, 'Kocaeli', 'Başiskele', 'basiskele'),
(555, 41, 'Kocaeli', 'Çayırova', 'cayirova'),
(556, 41, 'Kocaeli', 'Darıca', 'darica'),
(557, 41, 'Kocaeli', 'Dilovası', 'dilovasi'),
(558, 41, 'Kocaeli', 'İzmit', 'izmit'),
(559, 41, 'Kocaeli', 'Kartepe', 'kartepe'),
(560, 42, 'Konya', 'Akşehir', 'aksehir'),
(561, 42, 'Konya', 'Beyşehir', 'beysehir'),
(562, 42, 'Konya', 'Bozkır', 'bozkir'),
(563, 42, 'Konya', 'Cihanbeyli', 'cihanbeyli'),
(564, 42, 'Konya', 'Çumra', 'cumra'),
(565, 42, 'Konya', 'Doğanhisar', 'doganhisar'),
(566, 42, 'Konya', 'Ereğli', 'eregli'),
(567, 42, 'Konya', 'Hadim', 'hadim'),
(568, 42, 'Konya', 'Ilgın', 'ilgin'),
(569, 42, 'Konya', 'Kadınhanı', 'kadinhani'),
(570, 42, 'Konya', 'Karapınar', 'karapinar'),
(571, 42, 'Konya', 'Kulu', 'kulu'),
(572, 42, 'Konya', 'Sarayönü', 'sarayonu'),
(573, 42, 'Konya', 'Seydişehir', 'seydisehir'),
(574, 42, 'Konya', 'Yunak', 'yunak'),
(575, 42, 'Konya', 'Akören', 'akoren'),
(576, 42, 'Konya', 'Altınekin', 'altinekin'),
(577, 42, 'Konya', 'Derebucak', 'derebucak'),
(578, 42, 'Konya', 'Hüyük', 'huyuk'),
(579, 42, 'Konya', 'Karatay', 'karatay'),
(580, 42, 'Konya', 'Meram', 'meram'),
(581, 42, 'Konya', 'Selçuklu', 'selcuklu'),
(582, 42, 'Konya', 'Taşkent', 'taskent'),
(583, 42, 'Konya', 'Ahırlı', 'ahirli'),
(584, 42, 'Konya', 'Çeltik', 'celtik'),
(585, 42, 'Konya', 'Derbent', 'derbent'),
(586, 42, 'Konya', 'Emirgazi', 'emirgazi'),
(587, 42, 'Konya', 'Güneysınır', 'guneysinir'),
(588, 42, 'Konya', 'Halkapınar', 'halkapinar'),
(589, 42, 'Konya', 'Tuzlukçu', 'tuzlukcu'),
(590, 42, 'Konya', 'Yalıhüyük', 'yalihuyuk'),
(591, 43, 'Kütahya', 'Altıntaş', 'altintas'),
(592, 43, 'Kütahya', 'Domaniç', 'domanic'),
(593, 43, 'Kütahya', 'Emet', 'emet'),
(594, 43, 'Kütahya', 'Gediz', 'gediz'),
(595, 43, 'Kütahya', 'Merkez', 'merkez'),
(596, 43, 'Kütahya', 'Simav', 'simav'),
(597, 43, 'Kütahya', 'Tavşanlı', 'tavsanli'),
(598, 43, 'Kütahya', 'Aslanapa', 'aslanapa'),
(599, 43, 'Kütahya', 'Dumlupınar', 'dumlupinar'),
(600, 43, 'Kütahya', 'Hisarcık', 'hisarcik'),
(601, 43, 'Kütahya', 'Şaphane', 'saphane'),
(602, 43, 'Kütahya', 'Çavdarhisar', 'cavdarhisar'),
(603, 43, 'Kütahya', 'Pazarlar', 'pazarlar'),
(604, 44, 'Malatya', 'Akçadağ', 'akcadag'),
(605, 44, 'Malatya', 'Arapgir', 'arapgir'),
(606, 44, 'Malatya', 'Arguvan', 'arguvan'),
(607, 44, 'Malatya', 'Darende', 'darende'),
(608, 44, 'Malatya', 'Doğanşehir', 'dogansehir'),
(609, 44, 'Malatya', 'Hekimhan', 'hekimhan'),
(610, 44, 'Malatya', 'Pütürge', 'puturge'),
(611, 44, 'Malatya', 'Yeşilyurt', 'yesilyurt'),
(612, 44, 'Malatya', 'Battalgazi', 'battalgazi'),
(613, 44, 'Malatya', 'Doğanyol', 'doganyol'),
(614, 44, 'Malatya', 'Kale', 'kale'),
(615, 44, 'Malatya', 'Kuluncak', 'kuluncak'),
(616, 44, 'Malatya', 'Yazıhan', 'yazihan'),
(617, 45, 'Manisa', 'Akhisar', 'akhisar'),
(618, 45, 'Manisa', 'Alaşehir', 'alasehir'),
(619, 45, 'Manisa', 'Demirci', 'demirci'),
(620, 45, 'Manisa', 'Gördes', 'gordes'),
(621, 45, 'Manisa', 'Kırkağaç', 'kirkagac'),
(622, 45, 'Manisa', 'Kula', 'kula'),
(623, 45, 'Manisa', 'Salihli', 'salihli'),
(624, 45, 'Manisa', 'Sarıgöl', 'sarigol'),
(625, 45, 'Manisa', 'Saruhanlı', 'saruhanli'),
(626, 45, 'Manisa', 'Selendi', 'selendi'),
(627, 45, 'Manisa', 'Soma', 'soma'),
(628, 45, 'Manisa', 'Turgutlu', 'turgutlu'),
(629, 45, 'Manisa', 'Ahmetli', 'ahmetli'),
(630, 45, 'Manisa', 'Gölmarmara', 'golmarmara'),
(631, 45, 'Manisa', 'Köprübaşı', 'koprubasi'),
(632, 45, 'Manisa', 'Şehzadeler', 'sehzadeler'),
(633, 45, 'Manisa', 'Yunusemre', 'yunusemre'),
(634, 46, 'Kahramanmaraş', 'Afşin', 'afsin'),
(635, 46, 'Kahramanmaraş', 'Andırın', 'andirin'),
(636, 46, 'Kahramanmaraş', 'Elbistan', 'elbistan'),
(637, 46, 'Kahramanmaraş', 'Göksun', 'goksun'),
(638, 46, 'Kahramanmaraş', 'Pazarcık', 'pazarcik'),
(639, 46, 'Kahramanmaraş', 'Türkoğlu', 'turkoglu'),
(640, 46, 'Kahramanmaraş', 'Çağlayancerit', 'caglayancerit'),
(641, 46, 'Kahramanmaraş', 'Ekinözü', 'ekinozu'),
(642, 46, 'Kahramanmaraş', 'Nurhak', 'nurhak'),
(643, 46, 'Kahramanmaraş', 'Dulkadiroğlu', 'dulkadiroglu'),
(644, 46, 'Kahramanmaraş', 'Onikişubat', 'onikisubat'),
(645, 47, 'Mardin', 'Derik', 'derik'),
(646, 47, 'Mardin', 'Kızıltepe', 'kiziltepe'),
(647, 47, 'Mardin', 'Mazıdağı', 'mazidagi'),
(648, 47, 'Mardin', 'Midyat', 'midyat'),
(649, 47, 'Mardin', 'Nusaybin', 'nusaybin'),
(650, 47, 'Mardin', 'Ömerli', 'omerli'),
(651, 47, 'Mardin', 'Savur', 'savur'),
(652, 47, 'Mardin', 'Dargeçit', 'dargecit'),
(653, 47, 'Mardin', 'Yeşilli', 'yesilli'),
(654, 47, 'Mardin', 'Artuklu', 'artuklu'),
(655, 48, 'Muğla', 'Bodrum', 'bodrum'),
(656, 48, 'Muğla', 'Datça', 'datca'),
(657, 48, 'Muğla', 'Fethiye', 'fethiye'),
(658, 48, 'Muğla', 'Köyceğiz', 'koycegiz'),
(659, 48, 'Muğla', 'Marmaris', 'marmaris'),
(660, 48, 'Muğla', 'Milas', 'milas'),
(661, 48, 'Muğla', 'Ula', 'ula'),
(662, 48, 'Muğla', 'Yatağan', 'yatagan'),
(663, 48, 'Muğla', 'Dalaman', 'dalaman'),
(664, 48, 'Muğla', 'Ortaca', 'ortaca'),
(665, 48, 'Muğla', 'Kavaklıdere', 'kavaklidere'),
(666, 48, 'Muğla', 'Menteşe', 'mentese'),
(667, 48, 'Muğla', 'Seydikemer', 'seydikemer'),
(668, 49, 'Muş', 'Bulanık', 'bulanik'),
(669, 49, 'Muş', 'Malazgirt', 'malazgirt'),
(670, 49, 'Muş', 'Merkez', 'merkez'),
(671, 49, 'Muş', 'Varto', 'varto'),
(672, 49, 'Muş', 'Hasköy', 'haskoy'),
(673, 49, 'Muş', 'Korkut', 'korkut'),
(674, 50, 'Nevşehir', 'Avanos', 'avanos'),
(675, 50, 'Nevşehir', 'Derinkuyu', 'derinkuyu'),
(676, 50, 'Nevşehir', 'Gülşehir', 'gulsehir'),
(677, 50, 'Nevşehir', 'Hacıbektaş', 'hacibektas'),
(678, 50, 'Nevşehir', 'Kozaklı', 'kozakli'),
(679, 50, 'Nevşehir', 'Merkez', 'merkez'),
(680, 50, 'Nevşehir', 'Ürgüp', 'urgup'),
(681, 50, 'Nevşehir', 'Acıgöl', 'acigol'),
(682, 51, 'Niğde', 'Bor', 'bor'),
(683, 51, 'Niğde', 'Çamardı', 'camardi'),
(684, 51, 'Niğde', 'Merkez', 'merkez'),
(685, 51, 'Niğde', 'Ulukışla', 'ulukisla'),
(686, 51, 'Niğde', 'Altunhisar', 'altunhisar'),
(687, 51, 'Niğde', 'Çiftlik', 'ciftlik'),
(688, 52, 'Ordu', 'Akkuş', 'akkus'),
(689, 52, 'Ordu', 'Aybastı', 'aybasti'),
(690, 52, 'Ordu', 'Fatsa', 'fatsa'),
(691, 52, 'Ordu', 'Gölköy', 'golkoy'),
(692, 52, 'Ordu', 'Korgan', 'korgan'),
(693, 52, 'Ordu', 'Kumru', 'kumru'),
(694, 52, 'Ordu', 'Mesudiye', 'mesudiye'),
(695, 52, 'Ordu', 'Perşembe', 'persembe'),
(696, 52, 'Ordu', 'Ulubey', 'ulubey'),
(697, 52, 'Ordu', 'Ünye', 'unye'),
(698, 52, 'Ordu', 'Gülyalı', 'gulyali'),
(699, 52, 'Ordu', 'Gürgentepe', 'gurgentepe'),
(700, 52, 'Ordu', 'Çamaş', 'camas'),
(701, 52, 'Ordu', 'Çatalpınar', 'catalpinar'),
(702, 52, 'Ordu', 'Çaybaşı', 'caybasi'),
(703, 52, 'Ordu', 'İkizce', 'ikizce'),
(704, 52, 'Ordu', 'Kabadüz', 'kabaduz'),
(705, 52, 'Ordu', 'Kabataş', 'kabatas'),
(706, 52, 'Ordu', 'Altınordu', 'altinordu'),
(707, 53, 'Rize', 'Ardeşen', 'ardesen'),
(708, 53, 'Rize', 'Çamlıhemşin', 'camlihemsin'),
(709, 53, 'Rize', 'Çayeli', 'cayeli'),
(710, 53, 'Rize', 'Fındıklı', 'findikli'),
(711, 53, 'Rize', 'İkizdere', 'ikizdere'),
(712, 53, 'Rize', 'Kalkandere', 'kalkandere'),
(713, 53, 'Rize', 'Pazar', 'pazar'),
(714, 53, 'Rize', 'Merkez', 'merkez'),
(715, 53, 'Rize', 'Güneysu', 'guneysu'),
(716, 53, 'Rize', 'Derepazarı', 'derepazari'),
(717, 53, 'Rize', 'Hemşin', 'hemsin'),
(718, 53, 'Rize', 'İyidere', 'iyidere'),
(719, 54, 'Sakarya', 'Akyazı', 'akyazi'),
(720, 54, 'Sakarya', 'Geyve', 'geyve'),
(721, 54, 'Sakarya', 'Hendek', 'hendek'),
(722, 54, 'Sakarya', 'Karasu', 'karasu'),
(723, 54, 'Sakarya', 'Kaynarca', 'kaynarca'),
(724, 54, 'Sakarya', 'Sapanca', 'sapanca'),
(725, 54, 'Sakarya', 'Kocaali', 'kocaali'),
(726, 54, 'Sakarya', 'Pamukova', 'pamukova'),
(727, 54, 'Sakarya', 'Taraklı', 'tarakli'),
(728, 54, 'Sakarya', 'Ferizli', 'ferizli'),
(729, 54, 'Sakarya', 'Karapürçek', 'karapurcek'),
(730, 54, 'Sakarya', 'Söğütlü', 'sogutlu'),
(731, 54, 'Sakarya', 'Adapazarı', 'adapazari'),
(732, 54, 'Sakarya', 'Arifiye', 'arifiye'),
(733, 54, 'Sakarya', 'Erenler', 'erenler'),
(734, 54, 'Sakarya', 'Serdivan', 'serdivan'),
(735, 55, 'Samsun', 'Alaçam', 'alacam'),
(736, 55, 'Samsun', 'Bafra', 'bafra'),
(737, 55, 'Samsun', 'Çarşamba', 'carsamba'),
(738, 55, 'Samsun', 'Havza', 'havza'),
(739, 55, 'Samsun', 'Kavak', 'kavak'),
(740, 55, 'Samsun', 'Ladik', 'ladik'),
(741, 55, 'Samsun', 'Terme', 'terme'),
(742, 55, 'Samsun', 'Vezirköprü', 'vezirkopru'),
(743, 55, 'Samsun', 'Asarcık', 'asarcik'),
(744, 55, 'Samsun', '19 Mayıs', '19-mayis'),
(745, 55, 'Samsun', 'Salıpazarı', 'salipazari'),
(746, 55, 'Samsun', 'Tekkeköy', 'tekkekoy'),
(747, 55, 'Samsun', 'Ayvacık', 'ayvacik'),
(748, 55, 'Samsun', 'Yakakent', 'yakakent'),
(749, 55, 'Samsun', 'Atakum', 'atakum'),
(750, 55, 'Samsun', 'Canik', 'canik'),
(751, 55, 'Samsun', 'İlkadım', 'ilkadim'),
(752, 56, 'Siirt', 'Baykan', 'baykan'),
(753, 56, 'Siirt', 'Eruh', 'eruh'),
(754, 56, 'Siirt', 'Kurtalan', 'kurtalan'),
(755, 56, 'Siirt', 'Pervari', 'pervari'),
(756, 56, 'Siirt', 'Merkez', 'merkez'),
(757, 56, 'Siirt', 'Şirvan', 'sirvan'),
(758, 56, 'Siirt', 'Tillo', 'tillo'),
(759, 57, 'Sinop', 'Ayancık', 'ayancik'),
(760, 57, 'Sinop', 'Boyabat', 'boyabat'),
(761, 57, 'Sinop', 'Durağan', 'duragan'),
(762, 57, 'Sinop', 'Erfelek', 'erfelek'),
(763, 57, 'Sinop', 'Gerze', 'gerze'),
(764, 57, 'Sinop', 'Merkez', 'merkez'),
(765, 57, 'Sinop', 'Türkeli', 'turkeli'),
(766, 57, 'Sinop', 'Dikmen', 'dikmen'),
(767, 57, 'Sinop', 'Saraydüzü', 'sarayduzu'),
(768, 58, 'Sivas', 'Divriği', 'divrigi'),
(769, 58, 'Sivas', 'Gemerek', 'gemerek'),
(770, 58, 'Sivas', 'Gürün', 'gurun'),
(771, 58, 'Sivas', 'Hafik', 'hafik'),
(772, 58, 'Sivas', 'İmranlı', 'imranli'),
(773, 58, 'Sivas', 'Kangal', 'kangal'),
(774, 58, 'Sivas', 'Koyulhisar', 'koyulhisar'),
(775, 58, 'Sivas', 'Merkez', 'merkez'),
(776, 58, 'Sivas', 'Suşehri', 'susehri'),
(777, 58, 'Sivas', 'Şarkışla', 'sarkisla'),
(778, 58, 'Sivas', 'Yıldızeli', 'yildizeli'),
(779, 58, 'Sivas', 'Zara', 'zara'),
(780, 58, 'Sivas', 'Akıncılar', 'akincilar'),
(781, 58, 'Sivas', 'Altınyayla', 'altinyayla'),
(782, 58, 'Sivas', 'Doğanşar', 'dogansar'),
(783, 58, 'Sivas', 'Gölova', 'golova'),
(784, 58, 'Sivas', 'Ulaş', 'ulas'),
(785, 59, 'Tekirdağ', 'Çerkezköy', 'cerkezkoy'),
(786, 59, 'Tekirdağ', 'Çorlu', 'corlu'),
(787, 59, 'Tekirdağ', 'Hayrabolu', 'hayrabolu'),
(788, 59, 'Tekirdağ', 'Malkara', 'malkara'),
(789, 59, 'Tekirdağ', 'Muratlı', 'muratli'),
(790, 59, 'Tekirdağ', 'Saray', 'saray'),
(791, 59, 'Tekirdağ', 'Şarköy', 'sarkoy'),
(792, 59, 'Tekirdağ', 'Marmaraereğlisi', 'marmaraereglisi'),
(793, 59, 'Tekirdağ', 'Ergene', 'ergene'),
(794, 59, 'Tekirdağ', 'Kapaklı', 'kapakli'),
(795, 59, 'Tekirdağ', 'Süleymanpaşa', 'suleymanpasa'),
(796, 60, 'Tokat', 'Almus', 'almus'),
(797, 60, 'Tokat', 'Artova', 'artova'),
(798, 60, 'Tokat', 'Erbaa', 'erbaa'),
(799, 60, 'Tokat', 'Niksar', 'niksar'),
(800, 60, 'Tokat', 'Reşadiye', 'resadiye'),
(801, 60, 'Tokat', 'Tokat Merkez', 'tokat-merkez'),
(802, 60, 'Tokat', 'Turhal', 'turhal'),
(803, 60, 'Tokat', 'Zile', 'zile'),
(804, 60, 'Tokat', 'Pazar', 'pazar'),
(805, 60, 'Tokat', 'Yeşilyurt', 'yesilyurt'),
(806, 60, 'Tokat', 'Başçiftlik', 'basciftlik'),
(807, 60, 'Tokat', 'Sulusaray', 'sulusaray'),
(808, 61, 'Trabzon', 'Akçaabat', 'akcaabat'),
(809, 61, 'Trabzon', 'Araklı', 'arakli'),
(810, 61, 'Trabzon', 'Arsin', 'arsin'),
(811, 61, 'Trabzon', 'Çaykara', 'caykara'),
(812, 61, 'Trabzon', 'Maçka', 'macka'),
(813, 61, 'Trabzon', 'Of', 'of'),
(814, 61, 'Trabzon', 'Sürmene', 'surmene'),
(815, 61, 'Trabzon', 'Tonya', 'tonya'),
(816, 61, 'Trabzon', 'Vakfıkebir', 'vakfikebir'),
(817, 61, 'Trabzon', 'Yomra', 'yomra'),
(818, 61, 'Trabzon', 'Beşikdüzü', 'besikduzu'),
(819, 61, 'Trabzon', 'Şalpazarı', 'salpazari'),
(820, 61, 'Trabzon', 'Çarşıbaşı', 'carsibasi'),
(821, 61, 'Trabzon', 'Dernekpazarı', 'dernekpazari'),
(822, 61, 'Trabzon', 'Düzköy', 'duzkoy'),
(823, 61, 'Trabzon', 'Hayrat', 'hayrat'),
(824, 61, 'Trabzon', 'Köprübaşı', 'koprubasi'),
(825, 61, 'Trabzon', 'Ortahisar', 'ortahisar'),
(826, 62, 'Tunceli', 'Çemişgezek', 'cemisgezek'),
(827, 62, 'Tunceli', 'Hozat', 'hozat'),
(828, 62, 'Tunceli', 'Mazgirt', 'mazgirt'),
(829, 62, 'Tunceli', 'Nazımiye', 'nazimiye'),
(830, 62, 'Tunceli', 'Ovacık', 'ovacik'),
(831, 62, 'Tunceli', 'Pertek', 'pertek'),
(832, 62, 'Tunceli', 'Pülümür', 'pulumur'),
(833, 62, 'Tunceli', 'Merkez', 'merkez'),
(834, 63, 'Şanlıurfa', 'Akçakale', 'akcakale'),
(835, 63, 'Şanlıurfa', 'Birecik', 'birecik'),
(836, 63, 'Şanlıurfa', 'Bozova', 'bozova'),
(837, 63, 'Şanlıurfa', 'Ceylanpınar', 'ceylanpinar'),
(838, 63, 'Şanlıurfa', 'Halfeti', 'halfeti'),
(839, 63, 'Şanlıurfa', 'Hilvan', 'hilvan'),
(840, 63, 'Şanlıurfa', 'Siverek', 'siverek'),
(841, 63, 'Şanlıurfa', 'Suruç', 'suruc'),
(842, 63, 'Şanlıurfa', 'Viranşehir', 'viransehir'),
(843, 63, 'Şanlıurfa', 'Harran', 'harran'),
(844, 63, 'Şanlıurfa', 'Eyyübiye', 'eyyubiye'),
(845, 63, 'Şanlıurfa', 'Haliliye', 'haliliye'),
(846, 63, 'Şanlıurfa', 'Karaköprü', 'karakopru'),
(847, 64, 'Uşak', 'Banaz', 'banaz'),
(848, 64, 'Uşak', 'Eşme', 'esme'),
(849, 64, 'Uşak', 'Karahallı', 'karahalli'),
(850, 64, 'Uşak', 'Sivaslı', 'sivasli'),
(851, 64, 'Uşak', 'Ulubey', 'ulubey'),
(852, 64, 'Uşak', 'Merkez', 'merkez'),
(853, 65, 'Van', 'Başkale', 'baskale'),
(854, 65, 'Van', 'Çatak', 'catak'),
(855, 65, 'Van', 'Erciş', 'ercis'),
(856, 65, 'Van', 'Gevaş', 'gevas'),
(857, 65, 'Van', 'Gürpınar', 'gurpinar'),
(858, 65, 'Van', 'Muradiye', 'muradiye'),
(859, 65, 'Van', 'Özalp', 'ozalp'),
(860, 65, 'Van', 'Bahçesaray', 'bahcesaray'),
(861, 65, 'Van', 'Çaldıran', 'caldiran'),
(862, 65, 'Van', 'Edremit', 'edremit'),
(863, 65, 'Van', 'Saray', 'saray'),
(864, 65, 'Van', 'İpekyolu', 'ipekyolu'),
(865, 65, 'Van', 'Tuşba', 'tusba'),
(866, 66, 'Yozgat', 'Akdağmadeni', 'akdagmadeni'),
(867, 66, 'Yozgat', 'Boğazlıyan', 'bogazliyan'),
(868, 66, 'Yozgat', 'Çayıralan', 'cayiralan'),
(869, 66, 'Yozgat', 'Çekerek', 'cekerek'),
(870, 66, 'Yozgat', 'Sarıkaya', 'sarikaya'),
(871, 66, 'Yozgat', 'Sorgun', 'sorgun'),
(872, 66, 'Yozgat', 'Şefaatli', 'sefaatli'),
(873, 66, 'Yozgat', 'Yerköy', 'yerkoy'),
(874, 66, 'Yozgat', 'Yozgat Merkez', 'yozgat-merkez'),
(875, 66, 'Yozgat', 'Aydıncık', 'aydincik'),
(876, 66, 'Yozgat', 'Çandır', 'candir'),
(877, 66, 'Yozgat', 'Kadışehri', 'kadisehri'),
(878, 66, 'Yozgat', 'Saraykent', 'saraykent'),
(879, 66, 'Yozgat', 'Yenifakılı', 'yenifakili'),
(880, 67, 'Zonguldak', 'Çaycuma', 'caycuma'),
(881, 67, 'Zonguldak', 'Devrek', 'devrek'),
(882, 67, 'Zonguldak', 'Ereğli', 'eregli'),
(883, 67, 'Zonguldak', 'Merkez', 'merkez'),
(884, 67, 'Zonguldak', 'Alaplı', 'alapli'),
(885, 67, 'Zonguldak', 'Gökçebey', 'gokcebey'),
(886, 67, 'Zonguldak', 'Kilimli', 'kilimli'),
(887, 67, 'Zonguldak', 'Kozlu', 'kozlu'),
(888, 68, 'Aksaray', 'Merkez', 'merkez'),
(889, 68, 'Aksaray', 'Ortaköy', 'ortakoy'),
(890, 68, 'Aksaray', 'Ağaçören', 'agacoren'),
(891, 68, 'Aksaray', 'Güzelyurt', 'guzelyurt'),
(892, 68, 'Aksaray', 'Sarıyahşi', 'sariyahsi'),
(893, 68, 'Aksaray', 'Eskil', 'eskil'),
(894, 68, 'Aksaray', 'Gülağaç', 'gulagac'),
(895, 69, 'Bayburt', 'Merkez', 'merkez'),
(896, 69, 'Bayburt', 'Aydıntepe', 'aydintepe'),
(897, 69, 'Bayburt', 'Demirözü', 'demirozu'),
(898, 70, 'Karaman', 'Ermenek', 'ermenek'),
(899, 70, 'Karaman', 'Merkez', 'merkez'),
(900, 70, 'Karaman', 'Ayrancı', 'ayranci'),
(901, 70, 'Karaman', 'Kazımkarabekir', 'kazimkarabekir'),
(902, 70, 'Karaman', 'Başyayla', 'basyayla'),
(903, 70, 'Karaman', 'Sarıveliler', 'sariveliler'),
(904, 71, 'Kırıkkale', 'Delice', 'delice'),
(905, 71, 'Kırıkkale', 'Keskin', 'keskin'),
(906, 71, 'Kırıkkale', 'Merkez', 'merkez'),
(907, 71, 'Kırıkkale', 'Sulakyurt', 'sulakyurt'),
(908, 71, 'Kırıkkale', 'Bahşili', 'bahsili'),
(909, 71, 'Kırıkkale', 'Balışeyh', 'baliseyh'),
(910, 71, 'Kırıkkale', 'Çelebi', 'celebi'),
(911, 71, 'Kırıkkale', 'Karakeçili', 'karakecili'),
(912, 71, 'Kırıkkale', 'Yahşihan', 'yahsihan'),
(913, 72, 'Batman', 'Merkez', 'merkez'),
(914, 72, 'Batman', 'Beşiri', 'besiri'),
(915, 72, 'Batman', 'Gercüş', 'gercus'),
(916, 72, 'Batman', 'Kozluk', 'kozluk'),
(917, 72, 'Batman', 'Sason', 'sason'),
(918, 72, 'Batman', 'Hasankeyf', 'hasankeyf'),
(919, 73, 'Şırnak', 'Beytüşşebap', 'beytussebap'),
(920, 73, 'Şırnak', 'Cizre', 'cizre'),
(921, 73, 'Şırnak', 'İdil', 'idil'),
(922, 73, 'Şırnak', 'Silopi', 'silopi'),
(923, 73, 'Şırnak', 'Merkez', 'merkez'),
(924, 73, 'Şırnak', 'Uludere', 'uludere'),
(925, 73, 'Şırnak', 'Güçlükonak', 'guclukonak'),
(926, 74, 'Bartın', 'Merkez', 'merkez'),
(927, 74, 'Bartın', 'Kurucaşile', 'kurucasile'),
(928, 74, 'Bartın', 'Ulus', 'ulus'),
(929, 74, 'Bartın', 'Amasra', 'amasra'),
(930, 75, 'Ardahan', 'Merkez', 'merkez'),
(931, 75, 'Ardahan', 'Çıldır', 'cildir'),
(932, 75, 'Ardahan', 'Göle', 'gole'),
(933, 75, 'Ardahan', 'Hanak', 'hanak'),
(934, 75, 'Ardahan', 'Posof', 'posof'),
(935, 75, 'Ardahan', 'Damal', 'damal'),
(936, 76, 'Iğdır', 'Aralık', 'aralik'),
(937, 76, 'Iğdır', 'Merkez', 'merkez'),
(938, 76, 'Iğdır', 'Tuzluca', 'tuzluca'),
(939, 76, 'Iğdır', 'Karakoyunlu', 'karakoyunlu'),
(940, 77, 'Yalova', 'Merkez', 'merkez'),
(941, 77, 'Yalova', 'Altınova', 'altinova'),
(942, 77, 'Yalova', 'Armutlu', 'armutlu'),
(943, 77, 'Yalova', 'Çınarcık', 'cinarcik'),
(944, 77, 'Yalova', 'Çiftlikköy', 'ciftlikkoy'),
(945, 77, 'Yalova', 'Termal', 'termal'),
(946, 78, 'Karabük', 'Eflani', 'eflani'),
(947, 78, 'Karabük', 'Eskipazar', 'eskipazar'),
(948, 78, 'Karabük', 'Merkez', 'merkez'),
(949, 78, 'Karabük', 'Ovacık', 'ovacik'),
(950, 78, 'Karabük', 'Safranbolu', 'safranbolu'),
(951, 78, 'Karabük', 'Yenice', 'yenice'),
(952, 79, 'Kilis', 'Merkez', 'merkez'),
(953, 79, 'Kilis', 'Elbeyli', 'elbeyli'),
(954, 79, 'Kilis', 'Musabeyli', 'musabeyli'),
(955, 79, 'Kilis', 'Polateli', 'polateli'),
(956, 80, 'Osmaniye', 'Bahçe', 'bahce'),
(957, 80, 'Osmaniye', 'Kadirli', 'kadirli'),
(958, 80, 'Osmaniye', 'Merkez', 'merkez'),
(959, 80, 'Osmaniye', 'Düziçi', 'duzici'),
(960, 80, 'Osmaniye', 'Hasanbeyli', 'hasanbeyli'),
(961, 80, 'Osmaniye', 'Sumbas', 'sumbas'),
(962, 80, 'Osmaniye', 'Toprakkale', 'toprakkale'),
(963, 81, 'Düzce', 'Akçakoca', 'akcakoca'),
(964, 81, 'Düzce', 'Merkez', 'merkez'),
(965, 81, 'Düzce', 'Yığılca', 'yigilca'),
(966, 81, 'Düzce', 'Cumayeri', 'cumayeri'),
(967, 81, 'Düzce', 'Gölyaka', 'golyaka'),
(968, 81, 'Düzce', 'Çilimli', 'cilimli'),
(969, 81, 'Düzce', 'Gümüşova', 'gumusova'),
(970, 81, 'Düzce', 'Kaynaşlı', 'kaynasli');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `iller`
--

CREATE TABLE `iller` (
  `id` int(11) NOT NULL,
  `il` varchar(255) DEFAULT NULL,
  `link` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `iller`
--

INSERT INTO `iller` (`id`, `il`, `link`) VALUES
(1, 'Adana', 'adana'),
(2, 'Adıyaman', 'adiyaman'),
(3, 'Afyonkarahisar', 'afyonkarahisar'),
(4, 'Ağrı', 'agri'),
(5, 'Amasya', 'amasya'),
(6, 'Ankara', 'ankara'),
(7, 'Antalya', 'antalya'),
(8, 'Artvin', 'artvin'),
(9, 'Aydın', 'aydin'),
(10, 'Balıkesir', 'balikesir'),
(11, 'Bilecik', 'bilecik'),
(12, 'Bingöl', 'bingol'),
(13, 'Bitlis', 'bitlis'),
(14, 'Bolu', 'bolu'),
(15, 'Burdur', 'burdur'),
(16, 'Bursa', 'bursa'),
(17, 'Çanakkale', 'canakkale'),
(18, 'Çankırı', 'cankiri'),
(19, 'Çorum', 'corum'),
(20, 'Denizli', 'denizli'),
(21, 'Diyarbakır', 'diyarbakir'),
(22, 'Edirne', 'edirne'),
(23, 'Elazığ', 'elazig'),
(24, 'Erzincan', 'erzincan'),
(25, 'Erzurum', 'erzurum'),
(26, 'Eskişehir', 'eskisehir'),
(27, 'Gaziantep', 'gaziantep'),
(28, 'Giresun', 'giresun'),
(29, 'Gümüşhane', 'gumushane'),
(30, 'Hakkari', 'hakkari'),
(31, 'Hatay', 'hatay'),
(32, 'Isparta', 'isparta'),
(33, 'Mersin', 'mersin'),
(34, 'İstanbul', 'istanbul'),
(35, 'İzmir', 'izmir'),
(36, 'Kars', 'kars'),
(37, 'Kastamonu', 'kastamonu'),
(38, 'Kayseri', 'kayseri'),
(39, 'Kırklareli', 'kirklareli'),
(40, 'Kırşehir', 'kirsehir'),
(41, 'Kocaeli', 'kocaeli'),
(42, 'Konya', 'konya'),
(43, 'Kütahya', 'kutahya'),
(44, 'Malatya', 'malatya'),
(45, 'Manisa', 'manisa'),
(46, 'Kahramanmaraş', 'kahramanmaras'),
(47, 'Mardin', 'mardin'),
(48, 'Muğla', 'mugla'),
(49, 'Muş', 'mus'),
(50, 'Nevşehir', 'nevsehir'),
(51, 'Niğde', 'nigde'),
(52, 'Ordu', 'ordu'),
(53, 'Rize', 'rize'),
(54, 'Sakarya', 'sakarya'),
(55, 'Samsun', 'samsun'),
(56, 'Siirt', 'siirt'),
(57, 'Sinop', 'sinop'),
(58, 'Sivas', 'sivas'),
(59, 'Tekirdağ', 'tekirdag'),
(60, 'Tokat', 'tokat'),
(61, 'Trabzon', 'trabzon'),
(62, 'Tunceli', 'tunceli'),
(63, 'Şanlıurfa', 'sanliurfa'),
(64, 'Uşak', 'usak'),
(65, 'Van', 'van'),
(66, 'Yozgat', 'yozgat'),
(67, 'Zonguldak', 'zonguldak'),
(68, 'Aksaray', 'aksaray'),
(69, 'Bayburt', 'bayburt'),
(70, 'Karaman', 'karaman'),
(71, 'Kırıkkale', 'kirikkale'),
(72, 'Batman', 'batman'),
(73, 'Şırnak', 'sirnak'),
(74, 'Bartın', 'bartin'),
(75, 'Ardahan', 'ardahan'),
(76, 'Iğdır', 'igdir'),
(77, 'Yalova', 'yalova'),
(78, 'Karabük', 'karabuk'),
(79, 'Kilis', 'kilis'),
(80, 'Osmaniye', 'osmaniye'),
(81, 'Düzce', 'duzce');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kategoriler`
--

CREATE TABLE `kategoriler` (
  `id` int(11) NOT NULL,
  `baslik` text DEFAULT NULL,
  `ustkat` int(11) DEFAULT NULL,
  `link` longtext DEFAULT NULL,
  `sira` int(11) NOT NULL DEFAULT 0,
  `hit` int(11) NOT NULL DEFAULT 0,
  `resim` text NOT NULL,
  `belgeler` text NOT NULL,
  `teklifucreti` text NOT NULL,
  `komisyonucreti` text NOT NULL,
  `minteklif` text NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `icerik` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `kategoriler`
--

INSERT INTO `kategoriler` (`id`, `baslik`, `ustkat`, `link`, `sira`, `hit`, `resim`, `teklifucreti`, `komisyonucreti`, `minteklif`, `title`, `description`, `icerik`) VALUES
(1, 'Özel Ders', 0, 'ozel-ders', 84, 0, '', '', '', '', '', '', ''),
(2, 'İngilizce Özel Ders', 1, 'ingilizce-ozel-ders', 85, 0, '', '6%', '5', '50', '', '', ''),
(3, 'Matematik Özel Ders', 1, 'matematik-ozel-ders', 87, 6, '/panel/upload/img/math-kid-750x430.jpg', '', '', '', '', '', ''),
(4, 'Türkçe Özel Ders', 1, 'turkce-ozel-ders', 88, 1, '', '', '', '', '', '', ''),
(5, 'Almanca Özel Ders', 1, 'almanca-ozel-ders', 86, 2, '', '', '', '', '', '', ''),
(8, 'Temizlik', 0, 'temizlik-1607803969', 0, 0, '/panel/upload/img/temizlik.jpg', '3', '5%', '150', '', '', '<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Temizlik Hizmeti</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Hizmeti Yolla Web Sitemiz &Uuml;zerinden Bir &Ccedil;ok Profesyonnlerimizden Teklif Alibilir Doğru Firmayı Se&ccedil;ebilirsiniz.</span></p>\r\n'),
(9, 'Tadilat', 0, 'tadilat-1607804171', 39, 0, '', '3', '5%', '150', '', '', ''),
(10, 'Nakliyat', 0, 'nakliyat-1607804178', 26, 0, '', '3', '5%', '500', '', '', ''),
(11, 'Tamir-Tesisat', 0, 'tamir-1607804201', 63, 0, '', '', '', '', '', '', ''),
(12, 'Sağlık', 0, 'saglik-1607804208', 71, 0, '', '', '', '', '', '', ''),
(13, 'Organizasyon', 0, 'organizasyon-1607804223', 79, 0, '', '', '', '', '', '', ''),
(15, 'Ev Temizliği', 8, 'ev-temizligi-1607804240', 2, 14, '/panel/upload/img/evtemizlik.jpg', '3', '5%', '100', '', '', ''),
(16, 'Ofis Temizliği', 8, 'ofis-temizligi-1607804265', 3, 1, '/panel/upload/img/ofistemizlik.jpg', '3', '5%', '150', '', '', ''),
(17, 'Apartman Bina Temizliği', 8, 'apartman-bina-temizligi-1607804277', 6, 1, '/panel/upload/img/apartman-temizligi.jpg', '3', '5%', '70', '', '', ''),
(18, 'Boya Badana', 9, 'boya-badana-1607804289', 42, 7, '/panel/upload/img/boya.jpg', '', '', '', '', '', ''),
(19, 'Ev Tadilat', 9, 'ev-tadilat-1607804312', 40, 1, '', '', '', '', '', '', ''),
(20, 'Koltuk Döşeme', 9, 'koltuk-doseme-1607804322', 44, 4, '', '', '', '', '', '', ''),
(21, 'Cam Balkon', 9, 'cam-balkon-1607804339', 45, 1, '', '', '', '', '', '', ''),
(22, 'İç Mimar', 9, 'ic-mimar-1607804347', 46, 0, '', '', '', '', '', '', ''),
(23, 'İnşaat İşleri', 9, 'insaat-isleri-1607804374', 47, 3, '', '', '', '', '', '', ''),
(24, 'Evden Eve Nakliyat', 10, 'evden-eve-nakliyat-1607804444', 27, 10, '/panel/upload/img/evdeneve.jpg', '3', '5%', '800', '', '', ''),
(25, 'Eşya Taşıma', 10, 'esya-tasima-1607804466', 37, 1, '', '3', '5%', '150', '', '', ''),
(26, 'Eşya Depolama', 10, 'esya-depolama-1607804475', 38, 0, '', '3', '5%', '300', '', '', ''),
(28, 'Kalorifer ve Doğalgaz Tesisatı', 11, 'kalorifer-ve-dogalgaz-tesisati-1607804552', 65, 0, '', '', '', '', '', '', ''),
(29, 'Kamera Sistemleri', 11, 'kamera-sistemleri-1607804590', 66, 0, '', '', '', '', '', '', ''),
(30, 'Mobilya Montaj', 11, 'mobilya-montaj-1607804601', 67, 0, '', '', '', '', '', '', ''),
(31, 'Su Tesisatı', 11, 'su-tesisatcisi-1607804615', 68, 0, '/panel/upload/img/su-tesisat.jpg', '', '', '', '', '', ''),
(32, 'Klima Montaj', 11, 'klima-montaj-1607804627', 69, 1, '', '', '', '', '', '', ''),
(83, 'Çelik Kapı Pimapen', 9, 'celik-kapi-pimapen-1610128281', 43, 0, '', '', '', '', '', '', ''),
(34, 'Psikolog', 12, 'psikolog-1607804658', 72, 0, '', '', '', '', '', '', ''),
(35, 'Hasta ve Yaşlı Bakımı', 12, 'hasta-ve-yasli-bakimi-1607804719', 75, 0, '/panel/upload/img/hasta.jpg', '', '', '', '', '', ''),
(36, 'Bebek Bakımı', 12, 'bebek-bakimi-1607804699', 76, 0, '', '', '', '', '', '', ''),
(37, 'Diyetisyen', 12, 'diyetisyen-1607804707', 77, 0, '', '', '', '', '', '', ''),
(38, 'Fizyoterapist', 12, 'fizyoterapist-1607804746', 78, 0, '', '', '', '', '', '', ''),
(39, 'Düğün Salonu', 13, 'dugun-salonu-1607804770', 80, 0, '/panel/upload/img/dugun.jpg', '', '', '', '', '', ''),
(40, 'Doğum Günü Organizasyon', 13, 'dogum-gunu-organizasyon-1607804813', 81, 0, '', '', '', '', '', '', ''),
(41, 'Toplantı Salonu', 13, 'toplanti-salonu1607804820', 82, 0, '', '', '', '', '', '', ''),
(42, 'Fotoğrafçı', 13, 'fotografci-1607804840', 83, 0, '', '', '', '', '', '', ''),
(46, 'Asansör Bakım', 11, 'asansor-bakim-1607804986', 70, 0, '', '', '', '', '', '', ''),
(50, 'Yıkama', 0, 'yikama-1608305713', 16, 0, '/panel/upload/img/yikama.jpg', '10', '5%', '90', '', '', '<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Yıkama Hizmeti</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Web Sitemiz &Uuml;zerinden T&uuml;rkiye Geneli Koltuk Yıkama, Oto Yıkama, Halı Yıakma, Stor ve Zebra Perde Yıkama, &Ccedil;amaşır Yıkama, Kuru Temizleme, Hizmeti Veren Firmalarımızdan Hizmet Fiyat Teklifleri Alarak, Profesyonel &Uuml;ye Firmalarımız İle &Ccedil;alışma İmkanı Bulabilirsiniz.</span></p>\r\n'),
(52, 'Halı Yıkama', 50, 'hali-yikama-1608305829', 18, 0, '/panel/upload/img/haliyikama.gif', '', '5', '5', '', '', '<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Halı Yıkama Hakkında Doğru Bilinen Yanlışlar</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Halılarınızın kısa s&uuml;rede kirleniyor olması sizin de canınızı sıkıyor &ouml;yle değil mi? S&uuml;rekli elinizde bir bezle lekeli yerleri silmeye &ccedil;alışmaktan yorulduğunuzu da biliyoruz. Ne yazık ki evde en sık kirlenen şeylerin başında halılar gelir. S&uuml;rekli olarak kullanım halinde olması nedeniyle yılda en az iki defa yıkanması gerekir. Tabi ki bir&ccedil;ok şeyde olduğu gibi bunda da Halı Yıkama hakkında doğru bilinen yanlışlar vardır.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Bir&ccedil;ok kişi halılarının kirliliğinden rahatsız olsa da, yıkama konusunda &ccedil;ekimserdir. &Ccedil;&uuml;nk&uuml; yaygın olarak bilinen yanlış bir inan&ccedil;, halıların sık yıkandığında parlaklığını yitirdiğini s&ouml;yler. Bu da Halı Yıkama uygulaması tercih etmek yerine, silerek &ccedil;&ouml;z&uuml;m oluşturmaya &ccedil;alışma d&uuml;ş&uuml;ncesine iter. Ancak Halı Yıkamanın parlaklığı alması gibi bir durum s&ouml;z konusu değildir. Aksine yıkamak yerine silmek kirleri i&ccedil;erisinde hapsedeceği i&ccedil;in b&ouml;yle duruma neden olabilir.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Halı yıkamak yerine silmek sadece parlaklığı almaz, aynı zamanda kirlerin de dibe &ccedil;&ouml;kmesine neden olur. Kirler ve bakteriler diplere iner, bu sayede kendilerine yeni bir yaşam alanı edinmiş olur. Aynı zamanda silme işlemi sırasında halının y&uuml;zeyine &ccedil;ok fazla bastırıldığı i&ccedil;in t&uuml;yleri de zarar g&ouml;r&uuml;r. Hem hijyen a&ccedil;ısından hem de halının g&ouml;rselliğinin zarar g&ouml;rmemesi a&ccedil;ısından halıyı silmek yerine, profesyonel bir Halı Yıkama hizmeti almak mantıklı adım olacaktır.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Bir &ccedil;ok kişi tarafından doğru bilinen yanlışlardan biri de Halı Yıkama firmalarının merdiven altı denilen işletmeler şeklinde olduğudur. Bu nedenle g&uuml;ven arz etmediklerini d&uuml;ş&uuml;n&uuml;r ve kendilerinin daha iyi bir temizlik sağlayacağına inanırlar. Fakat bu her halı yıkama firması i&ccedil;in doğru bir d&uuml;ş&uuml;nce değildir. G&uuml;venilir halı yıkamacıya ulaşmanın olduk&ccedil;a &ouml;nemli olması bağlamında Hizmeti Yolla Bu Alan da Size Profesyonel ve Belgeli Merdiven Altı Olmayan Firmaları Sizin İ&ccedil;in Web Sitemiz de Yer Verdik Vermeyede Devam Ediceğiz. Belgeleri Olan Firmaları Onaylıyoruz.&nbsp;G&ouml;n&uuml;l Rahatlığı İle Web Sitemizde Hizmer VerenHalı Firmalarımızdan Halı Yıkama Fiyat Teklifi Alabilir İşlem Sonucun da Anlaştığınız Firma İle &Ccedil;alışabilirsiniz.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Hizmeti Yolla Ekibi Olarak,&nbsp; Halı Yıkama Firmaların&#39;nın ve Sizlerin Her İki Tarafında Hizmet de Sorun Yaşamaması Adına G&uuml;nbe g&uuml;n &Ccedil;alışıyor ve yenileniyoruz.</span></p>\r\n'),
(53, 'Stor Perde Yıkama', 50, 'stor-perde-yikama-1608305864', 19, 0, '', '10', '5%', '40', '', '', '<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Stor Perde Yıkama Hizmeti</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Olduk&ccedil;a &ouml;zen ve dikkat isteyen bir hizmet olan perde yıkama işlemi, aynı zamanda bir o kadar da uğraştırıcı bir işlemdir. Perde yıkama hizmetleri, kirlenmiş olan perdeleri kumaş ya da model fark etmeksizin iyice temizleyen bir hizmettir. B&ouml;ylelikle perdeleriniz herhangi bir zarar g&ouml;rmeden yıkanıp temizlenmiş olur.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Perdeler Nasıl Yıkanmalıdır?</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Perdeler pek &ccedil;ok nedenden dolayı kirlenebilir. Bu y&uuml;zden d&uuml;zenli olarak temizlenmeleri de &ouml;nem kazanır. &Ouml;zellikle de kış mevsiminde ısıtıcıların yaydığı ısı ve tozlardan &ccedil;ok kolayca etkilenebilirler. Bahar mevsiminin gelmesi ile perdelerin temizlenmesi gerekli bir işlemdir. Perde yıkama y&ouml;ntemleri, perdelerin kumaşlarına g&ouml;re farklılık g&ouml;stermektedir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">T&uuml;l Perde Yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Beyaz t&uuml;ller evlerin vazge&ccedil;ilmez par&ccedil;alarından birisidir. Ancak olduk&ccedil;a narin bir dokuya sahip oldukları i&ccedil;in temizlikleri de bir o kadar zor ger&ccedil;ekleşir. T&uuml;l perdeler; g&uuml;neş ışığı, kirli hava, sigara ya da yemek dumanı, kalorifer ısısı gibi pek &ccedil;ok sebepten hemen kirlenebilir. Bunun dışında zamanla renk de değiştirebilir. Senede birka&ccedil; kez yıkanması &ouml;nemlidir. Doğru olmayan yıkama &ccedil;eşitleri ile yıkanan t&uuml;l perdeler, &ccedil;ok kolayca yıpranıp eskiyebilir. Bu nedenle perde yıkama hizmeti almak gerekli bir durumdur. Bu hizmette perdeler g&uuml;zelce yıkanır ve &uuml;t&uuml;lenerek teslim edilir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Stor Perde Yıkama</span></h2>\r\n\r\n<p>Hem şık hem de kolay kullanımları ile her ge&ccedil;en g&uuml;n daha da yaygınlaşan stor perdeler, &ouml;zellikle de mutfaklarda &ccedil;ok tercih edilmeye başlanmıştır. Fakat bu perdeleri temizlemek de fazlasıyla zordur. Genelde stor perde yıkama işlemi evde pek başarılı olmaz. Perdeler yıpranır ve kullanılamayacak bir hale gelir. Bu y&uuml;zden stor perde yıkama hizmeti almak gerekir. Spor perdelerde bulunan apre isimli katman her temizlik malzemesi ile kolayca temizlenemez. Bu t&uuml;r b&ouml;lgeleri mutlaka uzman ekiplerin temizlemesi gerekir. Aksi takdirde yanlış temizlik malzemeleri ile temizlenirse, sararma meydana gelebilir.</p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Zebra Perde yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Stor &ccedil;eşitlerinden biri olan zebra perde, dekoratif g&ouml;r&uuml;n&uuml;mleri ve işlevsel olmaları ile pek &ccedil;ok yerde tercih edilmektedir. &Ccedil;ok sık kirlenmese de d&uuml;zenli olarak temizlenmeleri gerekir. Uzun s&uuml;re temizlenmezse &uuml;zerinde &ccedil;ıkarılamayan lekeler meydana gelebilir. En az 6 aylık bir s&uuml;rede bu perdelerin temizlenmesi gerekir. Zebraları temizlerken &ccedil;ok dikkat edilmelidir, dokuları &ccedil;ok serttir ve istemeden hasar verebilirsiniz. Oluşabilecek kalıcı hasarlar g&ouml;z &ouml;n&uuml;nde bulundurulduğunda hizmet almanız daha faydalı olacaktır.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Jaluzi Perde yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Jaluzi perdeler genellikle ofis ortamlarında kullanılan perdelerdendir. Temizlenmesi ise &ccedil;ok zor olabilir. &Ccedil;&uuml;nk&uuml; uzun boylu &ccedil;ubuklardan oluşurlar ve tek tek s&ouml;k&uuml;lme işlemi ister. Bu şekilde temizliği &ccedil;ok uzun s&uuml;rd&uuml;ğ&uuml; i&ccedil;in genelde hizmet alınarak temizlendirilir.&nbsp;</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Kruvaze Perde yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Kruvaze perdeler ortama şıklık ve zariflik katmaları ile bilinen perde modellerinden birisidir. Mekanizmalı bir perde &ccedil;eşididir ve s&ouml;k&uuml;l&uuml;p takılması da biraz uğraş ister. Bu tarz perdelerin gelişig&uuml;zel yıkanması, onlarda kalıcı hasar bırakabilir. Halka detayları kopabilir ya da makine i&ccedil;erisinde yırtılabilir. Bu t&uuml;r sorunlarla karşılaşmamak i&ccedil;in uzman ekiplerden yardım almak en doğru se&ccedil;enek olacaktır.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Fon Perde yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Diğer perde &ccedil;eşitlerine g&ouml;re en az kir tutan perdeler fon perdelerdir. Bu nedenle senede ortalama olarak 1 ya da 2 kez yıkanmaları yeterli olur. Nasıl yıkanacağı hakkında yeterli bilgi sahibi değilseniz, mutlaka uzmanlardan hizmet almanız gerekir. Aksi takdirde koyu renkli bir fon perdeye sahipseniz, renginde solmalar meydana gelebilir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Perde Yıkama Hizmeti Aşamaları</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">- Perdenin kirlilik durumu ilk olarak g&ouml;zlemlenir. Eğer gerekli bir durum varsa &ouml;zel bir şekilde hazırlanmış olan ila&ccedil;lı bir suya yatırılır. Uzun s&uuml;re yıkanmayan perdeler genel olarak bu şekilde yıkanma işlemine hazırlanır.<br />\r\n- İlk aşama sonrası perde &uuml;zerindeki kirler yumuşamış olur ve bu perdeler makineye atılır. Eğer gerekliyse &ouml;n yıkama ile yıkanır.<br />\r\n- Perdeler makine i&ccedil;erisindeyken dikkat edilmesi gerekilen en &ouml;nemli şey ise kumaş t&uuml;r&uuml;d&uuml;r. Perdenin oluştuğu kumaş t&uuml;r&uuml;ne g&ouml;re yıkama derecesi ve uzunluğu belirlenir.<br />\r\n- Yıkama işleminden sonra perdeler kurutma makineleri ya da &ouml;zel kurutma odalarından havalandırma sistemi ile asılarak kurutulur.<br />\r\n- Kurulama işlemi bittikten sonra perdeler kumaş tiplerine g&ouml;re &uuml;t&uuml;leme işlemi g&ouml;r&uuml;rler. Perde &uuml;t&uuml;leme işlemi mutlaka işini bilen uzmanlar tarafından yapılmalıdır. Aksi takdirde perde kumaşı &uuml;zerinde kalıcı hasar oluşabilir.<br />\r\n- &Uuml;t&uuml;leme işlemi bittikten sonra &ouml;zenli ve narin bir şekilde katlanırlar. Katlanmaya uygun olmayan perdeler ise askıya alınır ve ambalajlanır. Daha sonra ise sizlere teslim edilir.<br />\r\n- Tercihe g&ouml;re teslim edilen perdelerin montajı da yapılabilir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Perde Yıkama Hizmetinde Nelere Dikkat Edilmelidir?</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">- Yıkama işlemine girecek olan perdenin kumaşına g&ouml;re kullanılacak malzemeler belirlenmelidir.<br />\r\n- Kumaş tipine g&ouml;re yıkama y&ouml;ntemi ve derecesi se&ccedil;ilir.<br />\r\n- S&ouml;k&uuml;lmesi ve yerine tekrardan monte edilmesi uzman ekipler tarafından sağlanır.<br />\r\n- Evde yapılacak klasik yıkama y&ouml;ntemlerinin yerine işini bilen uzmanlar tarafından hizmet alınmalıdır.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Perde Yıkama Hizmeti Se&ccedil;imi</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Perde temizleme i&ccedil;in hizmet se&ccedil;imi yaparken dikkat edilmesi gereken pek &ccedil;ok unsur olabilir. Bunlardan en &ouml;nemlisi ise genel olarak fiyat &ccedil;eşitliğidir. Fiyatlandırmalar genel olarak metrekare &uuml;zerinden hesaplanır. Bunun dışında alacağınız hizmete veya anlaşacağınız ekiplere g&ouml;re de değişkenlik g&ouml;sterebilir.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Siz de bu hizmetlerden yararlanmak istiyorsanız web sitemizden bir iş ilanı oluşturabilirsiniz. B&ouml;ylelikle sizlere gelen fiyat tekliflerini değerlendirebilir ve en uygun olanı tercih edebilirsiniz. Gelecek olan uygun teklifleri değerlendirerek; t&uuml;l perde yıkama, stor perde temizliği gibi daha pek &ccedil;ok perde yıkama hizmetlerinden faydalanabilirsiniz.</span></p>\r\n'),
(54, 'Çamaşır Yıkama', 50, 'camasir-yikama-1608305892', 23, 0, '', '', '', '', '', '', ''),
(55, 'Kuru Temizleme', 50, 'kuru-temizleme-1608305926', 25, 0, '', '', '', '', '', '', ''),
(56, 'İnşaat Sonrası Temizlik', 8, 'insaat-sonrasi-temizlik-1608306513', 4, 2, '/panel/upload/img/inşaat-sonrası-temizlik.jpg', '3', '5%', '150', '', '', ''),
(57, 'Dış Cephe Cam Temizliği', 8, 'dis-cephe-cam-temizligi-1608306553', 7, 1, '/panel/upload/img/dis-cephe-temizligi.jpg', '3', '5%', '150', '', '', ''),
(58, 'Oto Kuaför', 50, 'oto-kuafor-1608306565', 24, 0, '', '', '', '', '', '', '<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">OTO KUAF&Ouml;R</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Otomobiller erkekler i&ccedil;in olduk&ccedil;a &ouml;nemlidir. Pek &ccedil;ok kişi ara&ccedil;larına g&ouml;z&uuml; gibi bakar, en ufak bir zararın gelmemesini istemektedir. Hizmetiyollada oto kuaf&ouml;r konusunda sizlere detaylı bilgiler sunacağız.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Oto kuaf&ouml;r hizmetlerinde en iyi firmalarla &ccedil;alışmak istiyorsanız sizde profesyonellerden destek alabilirsiniz. Hizmetiyolla&rsquo;da &uuml;cretsiz teklif al se&ccedil;enekleri ile en iyi fiyatlarla oto kuaf&ouml;rlerle &ccedil;alışabilirsiniz.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Genel olarak ara&ccedil;ların y&uuml;zeysel şekilde temizlenmesine oto kuaf&ouml;r işlemleri adı verilmektedir. Bu uygulamada ara&ccedil;ların i&ccedil; aksamına detaylı temizlik yapılmaktadır. Bununla beraber ara&ccedil; &uuml;zerinde pasta-cila uygulaması da ger&ccedil;ekleştirilmektedir. Oto bakım yapan firmalarda motoru yıkanır ve parlatıcı ile parlatılmaktadır. Bununla beraber jantları temizlenir ve bu temizlikte genel olarak asit bazlı &uuml;r&uuml;nler kullanılmaktadır. Bu nedenle oto kuaf&ouml;r uygulamalarının her zaman uzman oto kuaf&ouml;rleri tarafından yapılması gerekmektedir.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Tıpkı insanlarda olduğu gibi ara&ccedil;ların da periyodik bakımlarının ger&ccedil;ekleştirilmesi gerekmektedir. Bu bakımlar genel olarak olduk&ccedil;a detaylı olmasının yanında kimi zaman da &ccedil;ok detaylı olmasa da bireysel şekilde yapılamayacak derecedeki bakımlar olarak yer almaktadır. Araba bakımı sırasında kullanılan cihazlar ve malzemelerin profesyonel malzemelerden oluşması nedeni ile kişilerin kendi başlarına yapmalarının olanağı bulunmamaktadır. Bununla beraber bu bakımdan sonra ara&ccedil; performansı da estetiği de g&ouml;zle g&ouml;r&uuml;l&uuml;r şekilde y&uuml;kselemeye başlayacaktır. Oto kuaf&ouml;r malzemeleri son derece pahalı ve deneyimli insanlar tarafından kullanılması gereken &uuml;r&uuml;nler arasındadır. Aksi taktirde araca faydadan &ccedil;ok zarar verilebilmektedir.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Oto Koruma Uygulamaları<br />\r\nEğer kaliteli bir bakım &uuml;r&uuml;nleri ve uzmanlar aracılığı ile yapılırsa ara&ccedil;larınız &uuml;zerinden ger&ccedil;ekten en iyi sonu&ccedil;ları kolayca alabilirsiniz. Aracınız i&ccedil;erisinde antibakteriyel detaylı temizlik yapılmaktadır. Aracınızda yer alan t&uuml;m bakteriler bu uygulama sayesinde tamamen yok edilmektedir. Kumaş aksamlar kumaş koruyucu &uuml;r&uuml;nler kullanılarak, deri ve plastik b&ouml;l&uuml;mler ise bu maddelerin &ouml;zelliklerine g&ouml;re &ouml;zel şekilde &uuml;retilmiş olan uygulamalarla koruma altına alınmaktadır.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Korumaların Amacı<br />\r\nAra&ccedil; i&ccedil;erisinde yer alan kumaş aksamların sıvı temasını engellemektedir. Kumaşınızın temizlendikten hemen sonra kolayca nefes almasını sağlamaktadır. Bu sayede kumaşın altında yer alan s&uuml;nger kısmın hava almasını sağlamakta ve s&uuml;ngerin dayanıklılık s&uuml;recini uzatmaktadır. Bu uygulama ile beraber koltuklarımız şekil deformesine uğramamaktadır. Plastik aksamlara yapılacak olan koruma ise aracınızda yer alan plastik ve bakalit malzemelerin g&uuml;neşin etkilerine karşı dayanıklılığını arttırmaktadır. Bu nedenle ara&ccedil; &uuml;zerinde renk atmaları, soyulma problemleri ve &ccedil;atlamalar tamamen engellenmektedir. Bununla beraber bu t&uuml;r malzemelerin toz itici &ouml;zelliği olduğu i&ccedil;in hem sağlığınıza faydası bulunmaktadır. bununla beraber aracınızın temiz g&ouml;r&uuml;nmesine yol a&ccedil;maktadır. Deri koruma uygulamalarında koltuklarınızın daha uzun &ouml;m&uuml;rl&uuml; olarak yer almasını, renklerinin solmasını ve &ccedil;atlamasını engellemektedir.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Hangi Hizmetler Verilir?<br />\r\nG&uuml;n&uuml;m&uuml;zde son derece yaygın olarak hizmet veren ara&ccedil; kuaf&ouml;rleri, ara&ccedil; sahiplerinin istedikleri her t&uuml;rl&uuml; oto bakım hizmetlerini sizlerle bir araya getirmektedir. Gerek kullandıkları &uuml;r&uuml;nler konusunda gerek de elektronik cihazları ile beraber ara&ccedil; i&ccedil;erisinde profesyonelce derinlemesine temizlik yapılması sağlanmaktadır. Bununla beraber bakım &uuml;r&uuml;nleri ile de sahip olduğunuz ara&ccedil;larınızın ilk g&uuml;nk&uuml; haline kavuşması sağlanmaktadır. Pek &ccedil;ok farklı alanda sunulan oto kuaf&ouml;r malzemeleri her biri farklı etkileri i&ccedil;erisinde bulundurmaktadır. Bu da her t&uuml;rl&uuml; taleplerin en iyi şekilde karşılanmasını sağlamaktadır. Aracını bir kuaf&ouml;r i&ccedil;erisine g&ouml;t&uuml;rmek isteyen insanlar hangi hizmetlerden yararlanacağından bahsedersek;</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Ara&ccedil;ların i&ccedil; ve dış yıkama hizmetleri sunulmaktadır. Bu uygulama en temel hizmet olmakla birlikte aynı zamanda en gerekli uygulamadır. Bunun nedeni iyi temizlenmemiş bir ara&ccedil; hi&ccedil;bir zaman bakımlı ve yeni g&ouml;z&uuml;kmemektedir. Bununla beraber araba yıkama işlemi sayesinde de aracın i&ccedil;erisinde var yer alan k&ouml;t&uuml; kokular giderilmekte ve daha konforlu ve kaliteli bir ara&ccedil; durumuna getirilmektedir.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Parlatma uygulaması, ara&ccedil; i&ccedil;erisinde mevcut boyanın &ccedil;ok daha parlak ve yeni g&ouml;z&uuml;kmesini sağlamaktadır. Aynı zamanda var olan boya durumunun tam olarak korunmasına da katkı sunabilmektedir. Bununla beraber boya parlatma uygulamasında ek &ccedil;iziklerin giderilmesi ve daha p&uuml;r&uuml;zs&uuml;z g&ouml;r&uuml;n&uuml;m verilmesi de sağlanabilmektedir. Motor temizliği ise ara&ccedil; verimliliği i&ccedil;in olmazsa olmaz uygulamalar arasındadır.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">T&uuml;m bu sayılan hizmetler ve daha fazlası i&ccedil;in iyi bir araba temizliği firması bulmak gereklidir. Bunun konuda ise en kolay ve g&uuml;venilir yollardan bir tanesi ustamgeliyor adresine girmek ve &uuml;cretsiz &uuml;ye olmaktır. Sizde form doldurarak en iyi firmalara kolayca ulaşabilirsiniz.</span></p>\r\n'),
(60, 'Koltuk Yıkama', 50, 'koltuk-yikama-1608392909', 17, 2, '/panel/upload/img/1.jpg', '10', '5%', '100', '', '', '<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Koltuk Yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Koltukların temizliği, insan sağlığı a&ccedil;ısından olduk&ccedil;a &ouml;nemli bir işlemdir. Ancak koltuk temizliği denilince akla ilk gelen koltuk silmedir. Oysa bu y&ouml;ntem ile koltukların temizlenmesi m&uuml;mk&uuml;n değildir. Ayrıca silme işlemi sırasında kirlerin koltuktan uzaklaştırılması bir yana, koltuk s&uuml;ngerinin &ccedil;ok daha derinlerine işlemlerine neden olunabilir. Bunun yanında pek &ccedil;ok kişi hijyen sağlamak i&ccedil;in koltuk kılıflarını yıkamayı tercih eder. Fakat detaylı olarak d&uuml;ş&uuml;n&uuml;ld&uuml;ğ&uuml;nde bu işlemin de koltuk temizliği konusunda yetersiz kaldığı anlaşılacaktır. Bu anlamda koltukların temizlenmesi i&ccedil;in en temel &ccedil;&ouml;z&uuml;m koltuk yıkama olarak karşımıza &ccedil;ıkmaktadır.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Koltuk yıkama, &ouml;zel ekipman ve temizlik &uuml;r&uuml;nleri ile ger&ccedil;ekleştirilen bir işlemdir. Koltukların derinlemesine temizliği i&ccedil;in etkili bir y&ouml;ntem olan yıkama ile ilgili bireylerin aklına takılan en &ouml;nemli soru ise koltuk yıkamanın koltuklara zarar verip vermeyeceğidir. Peki, koltuk yıkama işleminin sanıldığı gibi koltuklara herhangi bir zararı var mıdır?</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Koltuk Yıkama İşlemi Koltuklara Zarar Veriyor mu?</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Bu sorunun cevabı i&ccedil;in kesin ve net bir şekilde &ldquo;hayır&rdquo; cevabını vermek m&uuml;mk&uuml;nd&uuml;r. Koltuk yıkama sırasında koltukların deforme olmalarına neden olabilecek hi&ccedil;bir işlem uygulanmaz. Aksine d&uuml;zenli olarak yıkatılan koltukların &ouml;mr&uuml; uzar ve &ccedil;ok daha uzun yıllar boyunca kullanılabilirler. &Ccedil;&uuml;nk&uuml; koltukların yıkanması s&uuml;recinde &ouml;zel koltuk yıkama makinesi ve leke t&uuml;r&uuml;ne uygun şampuanlar kullanılmaktadır.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Aslına bakılırsa koltuklara asıl zarar verebilecek olan durum, evde temizlemeye &ccedil;alışmaktır. &Ccedil;&uuml;nk&uuml; koltuk kumaşının &ouml;zellikleri g&ouml;z &ouml;n&uuml;nde bulundurulmadan uygulanan silme işlemi, kılıfların yıpranmasına ve renk değişimlerine neden olabilmektedir. Bunun yanında koltukların &uuml;zerinde dalga dalga su lekeleri de oluşabilmektedir. Koltuklara ciddi zarar veren ve &ouml;m&uuml;rlerini kısaltan bu yanlış uygulamalar yerine koltuk yıkama hizmeti almak aynı zamanda ekonomik bir se&ccedil;im olacaktır. &Ccedil;&uuml;nk&uuml; koltuklarınızı d&uuml;zenli olarak yıkatarak eskimelerinin &ouml;n&uuml;ne ge&ccedil;er, değiştirmek zorunda kalmazsınız.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Sonu&ccedil; olarak koltukları yıkatmanın koltuklara zararından &ccedil;ok faydası bulunmakladır. Bu doğrultuda koltuklarınızın temizliği i&ccedil;in bir&nbsp;<strong><a href=\"http://hizmetiyolla.com/teklif-al/yikama-1608305713\">koltuk yıkama</a>&nbsp;</strong>Web Sitemiz &Uuml;zerinden Hizmet Veren Koltuk Yıkamacı Firmalar ile &ccedil;alışabilir, evlerinizde &ccedil;ok daha sağlıklı ve hijyenik ortamlar oluşturabilirsiniz</span>.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n'),
(63, 'Cam Temizliği', 8, 'cam-temizligi-1609961821', 5, 2, '/panel/upload/img/cam-temizligi.jpg', '3', '5%', '80', '', '', ''),
(64, 'Klima Temizliği', 8, 'klima-temizligi-1609961835', 8, 1, '/panel/upload/img/klimatemizligi.jpeg', '3', '5%', '50', '', '', ''),
(65, 'Ütü Hizmeti', 8, 'utu-hizmeti-1609961854', 9, 0, '/panel/upload/img/utuhizmeti.jpg', '3', '3%', '50', '', '', ''),
(66, 'Havuz Bakım ve Temizliği', 8, 'havuz-bakim-ve-temizligi-1609961949', 10, 0, '/panel/upload/img/havuz-bakim-temizligi.jpg', '3', '5%', '150', '', '', ''),
(61, 'Prefabrik Ev Yapımı', 0, 'prefabrik-ev-yapimi-1609884004', 89, 0, '', '', '', '', '', '', ''),
(67, 'İlaçlama', 0, 'ilaclama-1609961976', 11, 0, '/panel/upload/img/bocek-ilaclama-11.jpg', '3', '5%', '50', '', '', ''),
(68, 'Ev İlaçlama', 67, 'ev-ilaclama-1609972652', 13, 1, '/panel/upload/img/evilac3.jpg', '3', '5%', '70', '', '', '<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Ev İla&ccedil;lama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Y&uuml;zyıllardır sorunları ile karşılaştığımız haşere, b&ouml;cek, kemirgen ve parazitler evlerimize kadar girmekte, zamanımızın &ccedil;oğunu ge&ccedil;irdiğimiz bu yerler de oluşturdukları zararlarla bizlere b&uuml;y&uuml;k problemler yaratmaktadırlar. Ev ila&ccedil;lamahizmeti almak bu nedenle olduk&ccedil;a &ouml;nemlidir ve asla ihmal edilmemelidir. Evlerimizde g&ouml;rd&uuml;ğ&uuml;m&uuml;z herhangi bir b&ouml;cek t&uuml;r&uuml;n&uuml;n her ge&ccedil;en g&uuml;n &ccedil;oğalarak daha da tehlikeli hale gelebileceğinin bilincinde olmalıyız ve bu nedenle muhakkak ila&ccedil;lama şirketleri ile irtibat kurmalıyız.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Farklı haşere, b&ouml;cek t&uuml;rleri ile karşılaşılması m&uuml;mk&uuml;n olan evlerimizde, fare kemirgeniyle dahi karşılaşmak m&uuml;mk&uuml;nd&uuml;r. Her biri farklı zarar demek olan bu canlılar yok edilmelidir. Bazıları eşyalara verdikleri zararlarla maddi kayıpların sebebi demekken bazıları ise ciddi sağlık sorunlarına sebep demektirler. Haşerelerden kurtulmak d&uuml;ş&uuml;n&uuml;ld&uuml;ğ&uuml; kadar kolay olmamakla birlikte, bilin&ccedil;sizce alınan &ouml;nlemler ardından sağlık sorunları ile karşılaşılabilecek kadar hassas bir konudur. Bu ila&ccedil;lama uygulaması da aynı şekilde, bilin&ccedil;sizce uygulanan ila&ccedil;lama işlemleri ger&ccedil;ekleştiğinde kişilerin solunum yolları rahatsızlıkları başta olmak &uuml;zere sağlık problemleri yaşadığı g&ouml;r&uuml;lm&uuml;şt&uuml;r. İnsanların g&uuml;nlerinin &ccedil;oğunu ge&ccedil;irdikleri mekan olduğundan olduk&ccedil;a ciddiyet gerektiren bir iştir. Bu işlemin profesyonel ila&ccedil;lama şirketleri tarafından ger&ccedil;ekleştirilmesi gerekmektedir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Fiber Ev İla&ccedil;lama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Hamam b&ouml;ceği, tahta kurusu, kalorifer b&ouml;ceği gibi haşere t&uuml;rlerine rastlanılan evlerimizde pire, bit, fare, sivrisinek, karasinek, deri b&ouml;ceği, g&uuml;m&uuml;ş&ccedil;&uuml;n gibi haşere ve kemirgenlerle karşılaşmak da olasıdır. Bu nedenle her b&ouml;cek ve haşere t&uuml;r&uuml;ne karşı tedbirli olunmalıdır. Sadece g&ouml;r&uuml;ld&uuml;ğ&uuml; anda değil herhangi bir haşere belirtisi karşısında kalındığı zamanlar da dahi muhakkak ev ila&ccedil;lama şirketleri tarafından yardım alınmalıdır. &Ouml;rneğin v&uuml;cudunuzda kızarıklık, kaşıntı, kabarıklık gibi belirtiler g&ouml;rd&uuml;n&uuml;z ya da mutfaklarınızda geceleri &ccedil;ıkan tıkırtılar var. Yaz aylarının gelmesiyle camların a&ccedil;ılması ardından &ouml;zellikle geceleri birtakım vızıltılar duyuyorsunuz, eşyalarınız zamanla kullanılmaz hale geliyor, mutfaktaki yiyecekleriniz &uuml;zerinde bazı dışkılara rastlıyorsunuz. Bu gibi durumlar evde haşere, b&ouml;cek veya bir kemirgen olduğunun kanıtı olabilir. Bu gibi sorunlar karşısında kalan kişiler haşerelerden kurtulmak i&ccedil;in muhakkak destek almalıdırlar.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Ev İla&ccedil;lama Firmaları</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Ev ila&ccedil;lama i&ccedil;in haşere, b&ouml;cek t&uuml;r&uuml;ne g&ouml;re değişebilecek y&ouml;ntemler, uzman ekiplerce belirlenmektedir. Hamam b&ouml;ceği, kalorifer b&ouml;ceği haşere grupları i&ccedil;in evlerimizde jel ila&ccedil;lama tercih edilirken, pire, &ccedil;ıyan, tahtakurusu gibi haşere &ccedil;eşitleri i&ccedil;in ise sıvı ila&ccedil;lama uygulanır. Jel ila&ccedil;lama uygulaması olduk&ccedil;a zahmetsiz ve &ouml;nleme gerek duyulmadan yapıldığından uygulanması zaman almaz ve insanlara, &ccedil;evreye yan etkisi bulunmaz. Sıvı ila&ccedil;lama da aynı şekilde basit birka&ccedil; &ouml;nlem alınarak uygulaması ger&ccedil;ekleştirilen y&ouml;ntemdir ve her iki uygulama da olduk&ccedil;a kesin sonu&ccedil;lar almanızı sağlayacaktır. Ev ila&ccedil;lama şirketleri ile irtibat kurmanız durumunda sizlere daha sağlıklı ve huzurlu alanlar sunulacaktır.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Ev İla&ccedil;lama Fiyatları</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Havaların ısınması sebebiyle ortaya &ccedil;ıkan y&uuml;zlerce haşere ve b&ouml;cekten kurtulmak olduk&ccedil;a zordur. Dışarılarda sıcakları daha &ccedil;ok seven, yumurtalama i&ccedil;in neme ihtiya&ccedil; duyan, kış aylarında yağışlar nedeniyle yuvalarına su dolan veya yiyecek ihtiya&ccedil;larını gidermek durumunda kalan haşere, b&ouml;cek ve kemirgenler evlerimize kadar gelmektedir. A&ccedil;ık kapı, pencerelerden, su borularından, alınan eşyalardan, gelen misafirlerden kolaylıkla evlerimize girmeyi başarabilen haşerelerden kurtulmak i&ccedil;in kesinlikle profesyonel ila&ccedil;lama şirketleri ile iletişime ge&ccedil;ip, yardım alınmalıdır. &Ccedil;&uuml;nk&uuml; bu haşereler g&ouml;zle g&ouml;r&uuml;lmeyen en kuytu k&ouml;şelerde bile bulunabilmektedirler. Alınan ila&ccedil;lar bu gibi yerlere etki etmeyeceğinden bir s&uuml;re sonra aynı sorunla karşılaşılması m&uuml;mk&uuml;nd&uuml;r. bu gibi vakit kaybı yaşamadan yardım alınmalıdır.</span></p>\r\n\r\n<hr />\r\n<p>&nbsp;</p>\r\n'),
(69, 'Bina ve Apartman İlaçlama', 67, 'bina-ve-apartman-ilaclama-1609972670', 14, 1, '/panel/upload/img/14406-13pajyi-1200x440.jpg', '3', '5%', '100', '', '', '<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Bina ve Apartman İla&ccedil;lama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Bina ve Apartman ila&ccedil;lama, haşere ve kemirgen t&uuml;rlerinin zararlarından korunmaya karşı gereklilik arz etmektedir. Bina ve Apartman ila&ccedil;lama duyurusu genellikle bina ve apartman sakinlerini ilk başlarda tedirgin etse de ila&ccedil;lama şirketimizin kokulu ila&ccedil;lama, jel ila&ccedil;lama ve kokusuz ila&ccedil;lama y&ouml;ntemleri sayesinde bazı durumlarda evinizi terk etmenize gerek kalmamaktadır. Bina ve Apartman ila&ccedil;lama şirketi olarak yılların birikimine sahip lider ila&ccedil;lama firmasıyız. Bina ve Apartman ila&ccedil;lama, konut ila&ccedil;lama, site ila&ccedil;lama, bodrum ila&ccedil;lama ve bah&ccedil;e ila&ccedil;lama konusunda yıllardır kaliteli, g&uuml;venli ve garantili ila&ccedil;lama hizmeti sunmaktayız. B&ouml;cek bina ve apartman ila&ccedil;lama, hamamb&ouml;ceği ila&ccedil;lama, pire ila&ccedil;lama, kalorifer b&ouml;ceği ila&ccedil;lama ve bina ve apartman fare ila&ccedil;lama uygulamaları en sık yaptığımız ila&ccedil;lama uygulamaları arasında yer almaktadır. Biana ve Apartman ila&ccedil;lama i&ccedil;in mutlaka g&uuml;&ccedil;l&uuml; ila&ccedil;lama şirketimiz ile temas halinde olun.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Bina ve Apartman İla&ccedil;lama Fiyatları</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Bina ve Apartman ila&ccedil;lama fiyatları g&uuml;&ccedil;l&uuml; ila&ccedil;lama şirketimiz aracılığı ile ekonomik fiyatlara yapılmaktadır. Bina ve Apartman ila&ccedil;lama fiyatları belirlendikten sonra yılın belli aylarında periyodik ila&ccedil;lama uygulamalarımızı da bina ve apartman sakinleri i&ccedil;in yapmaktayız.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Fiber Apartman İla&ccedil;lama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">&bull; Bina ve Apartmanda kapalı ve a&ccedil;ık mekanlarda koridor, merdiven altları, bodrum ardiye gibi alanların metre karesi,<br />\r\n&bull; Bu alanlarda varlığı tespit edilen haşere yoğunluğu olası durumda birden fazla haşere olması,<br />\r\n&bull; Bu alanlarda toplam kullanılacak ila&ccedil; miktarı bizlere bina ve apartman ila&ccedil;lama fiyatları hakkında net bilgi vermektedir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Bina ve Apartman İla&ccedil;lama Nasıl Yapılır?</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Bina ve Apartman ila&ccedil;lama işlemleri belli bir plan ve organizasyon sonucunda yapılmaktadır. Bina ve Apartman ila&ccedil;laması i&ccedil;in başvur yapan kişiler i&ccedil;in ila&ccedil;lama alanında uzman departmanlarımız devreye girerek, ila&ccedil;lama yapılacak alanların tespitini yaparak, hangi alanlarda hangi haşere t&uuml;rleri olduğu belirlendikten sonra, sıvı, jel ila&ccedil;lama uygulamalarına karar verilerek ila&ccedil;lama işlemi yapılmaktadır.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Bina ve Apartman Fare İla&ccedil;lama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Bina ve Apartman fare ila&ccedil;lama işlemleri merak edilen ve &ccedil;ok rahatsızlık veren bir konudur. Kapalı mekanlarda fare ila&ccedil;lama işlemleri olduk&ccedil;a zordur. Ancak g&uuml;&ccedil;l&uuml; ila&ccedil;lama şirketimiz, a&ccedil;ık alanlarda fare istasyonu adını verdiğimiz uygulamaların kurulumu ile fareler bina ve apartman dairelerinde tamamen yok olmaktadır. Dışarı kurulan fare istasyonlarının i&ccedil;inde farelerin sevdiği hoş kokulu zehir bulunur. Kısa bir s&uuml;re sonra bu kokuya dayanamayan fare yuvasında &ccedil;ıkıp zehirle temas eder. Susama hissi yaratan bu zehir farenin dışarıdan su bulmasını sağlar. Suyu i&ccedil;tiği anda fare bina ve apartmanın dışında bir yerde &ouml;l&uuml;r.</span></p>\r\n'),
(70, 'Böcek ve Haşere İlaçlama', 67, 'bocek-ve-hasere-ilaclama-1609972685', 12, 1, '/panel/upload/img/ilaclama-isyeri-ilaclama.jpg', '3', '5%', '50', '', '', ''),
(71, 'Fare İlaçlama', 67, 'fare-ilaclama-1609972697', 15, 0, '/panel/upload/img/fareilaclama.jpg', '3', '5%', '70', '', '', ''),
(74, 'Servis-Bakım', 0, 'servis-bakim1610127532', 56, 0, '', '', '', '', '', '', ''),
(75, 'Kombi Servisi', 74, 'kombi-servisi-1610127589', 57, 0, '', '', '', '', '', '', ''),
(76, 'Tv-Uydu Servisi', 74, 'tv-uydu-servisi-1610127608', 58, 0, '', '', '', '', '', '', ''),
(77, 'Doğalgaz', 74, 'dogalgaz-ariza-1610127667', 60, 0, '', '', '', '', '', '', ''),
(78, 'Elektrik', 74, 'elektrik-1610127831', 61, 0, '', '', '', '', '', '', ''),
(79, 'Su', 74, 'su-1610127844', 62, 0, '', '', '', '', '', '', ''),
(80, 'Beyaz Eşya', 74, 'beyaz-esya-1610127851', 59, 1, '', '', '', '', '', '', ''),
(81, 'Elektrik Tesisatı', 11, 'elektrik-tesisati-1610128131', 64, 0, '', '', '', '', '', '', ''),
(82, 'Dış Cephe Mantolama', 9, 'dis-cephe-mantolama-1610128223', 41, 0, '', '', '', '', '', '', ''),
(84, 'Pedagog', 12, 'pedagog-1610128299', 73, 0, '', '', '', '', '', '', ''),
(85, 'Veteriner', 12, 'veteriner-1610128394', 74, 0, '', '', '', '', '', '', ''),
(88, 'Yazılım', 0, 'yazilim-1610229588', 48, 0, '', '', '', '', '', '', ''),
(89, 'Web Tasarım', 88, 'web-tasarim-1610229607', 49, 2, '', '', '', '', '', '', ''),
(106, 'Grafik Tasarım', 88, 'grafik-tasarim-1610835711', 51, 0, '', '', '', '', '', '', ''),
(93, 'Otomasyon Yazılımı', 88, 'otomasyon-yazilimi-1610230116', 53, 0, '', '', '', '', '', '', ''),
(94, 'Muhasebe Programı', 88, 'muhasebe-programi-1610230139', 54, 0, '', '', '', '', '', '', ''),
(95, 'Otomasyon Sistemleri', 88, 'otomasyon-sistemleri-1610230175', 55, 0, '', '', '', '', '', '', ''),
(96, 'Şehirler Arası Nakliyat', 10, 'sehirler-arasi-nakliyat-1610234352', 28, 0, '', '3', '5%', '500', '', '', ''),
(97, 'Şehir İçi Taşıma', 10, 'sehir-ici-tasima-1610234383', 29, 0, '', '3', '5%', '800', '', '', ''),
(98, 'Eşya Taşıma', 10, 'esya-tasima-1610234406', 30, 0, '', '3', '5%', '150', '', '', ''),
(99, 'Ofis Taşıma', 10, 'ofis-tasima-1610234429', 31, 0, '', '3', '5%', '600', '', '', ''),
(100, 'Motorlu Kurye', 10, 'motorlu-kurye-1610234442', 32, 0, '', '3', '5%', '30', '', '', ''),
(101, 'Uluslararası Nakliyat', 10, 'uluslararasi-nakliyat-1610234459', 33, 0, '', '3', '5%', '500', '', '', ''),
(102, 'Şöförlü Araç Tarnsfer', 10, 'soforlu-arac-tarnsfer-1610234498', 34, 0, '', '3', '5%', '100', '', '', ''),
(103, 'Araç Kurtarma', 10, 'arac-kurtarma-1610234548', 35, 0, '', '3', '5%', '120', '', '', ''),
(104, 'Gümrükleme', 10, 'gumrukleme-1610234571', 36, 0, '', '3', '5%', '70', '', '', ''),
(107, 'Sosyal Medya Uzmanlığı', 88, 'sosyal-medya-uzmanligi-1610835798', 52, 0, '', '', '', '', '', '', ''),
(105, 'Mobil Tasarım', 88, 'mobil-tasarim-1610835700', 50, 0, '', '', '', '', '', '', ''),
(108, 'Zebra Perde Yıkama', 50, 'zebra-perde-yikama-1610915332', 20, 0, '', '10', '5%', '50', '', '', '<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Stor Perde Yıkama Hizmeti</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Olduk&ccedil;a &ouml;zen ve dikkat isteyen bir hizmet olan perde yıkama işlemi, aynı zamanda bir o kadar da uğraştırıcı bir işlemdir. Perde yıkama hizmetleri, kirlenmiş olan perdeleri kumaş ya da model fark etmeksizin iyice temizleyen bir hizmettir. B&ouml;ylelikle perdeleriniz herhangi bir zarar g&ouml;rmeden yıkanıp temizlenmiş olur.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Perdeler Nasıl Yıkanmalıdır?</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Perdeler pek &ccedil;ok nedenden dolayı kirlenebilir. Bu y&uuml;zden d&uuml;zenli olarak temizlenmeleri de &ouml;nem kazanır. &Ouml;zellikle de kış mevsiminde ısıtıcıların yaydığı ısı ve tozlardan &ccedil;ok kolayca etkilenebilirler. Bahar mevsiminin gelmesi ile perdelerin temizlenmesi gerekli bir işlemdir. Perde yıkama y&ouml;ntemleri, perdelerin kumaşlarına g&ouml;re farklılık g&ouml;stermektedir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">T&uuml;l Perde Yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Beyaz t&uuml;ller evlerin vazge&ccedil;ilmez par&ccedil;alarından birisidir. Ancak olduk&ccedil;a narin bir dokuya sahip oldukları i&ccedil;in temizlikleri de bir o kadar zor ger&ccedil;ekleşir. T&uuml;l perdeler; g&uuml;neş ışığı, kirli hava, sigara ya da yemek dumanı, kalorifer ısısı gibi pek &ccedil;ok sebepten hemen kirlenebilir. Bunun dışında zamanla renk de değiştirebilir. Senede birka&ccedil; kez yıkanması &ouml;nemlidir. Doğru olmayan yıkama &ccedil;eşitleri ile yıkanan t&uuml;l perdeler, &ccedil;ok kolayca yıpranıp eskiyebilir. Bu nedenle perde yıkama hizmeti almak gerekli bir durumdur. Bu hizmette perdeler g&uuml;zelce yıkanır ve &uuml;t&uuml;lenerek teslim edilir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Stor Perde Yıkama</span></h2>\r\n\r\n<p>Hem şık hem de kolay kullanımları ile her ge&ccedil;en g&uuml;n daha da yaygınlaşan stor perdeler, &ouml;zellikle de mutfaklarda &ccedil;ok tercih edilmeye başlanmıştır. Fakat bu perdeleri temizlemek de fazlasıyla zordur. Genelde stor perde yıkama işlemi evde pek başarılı olmaz. Perdeler yıpranır ve kullanılamayacak bir hale gelir. Bu y&uuml;zden stor perde yıkama hizmeti almak gerekir. Spor perdelerde bulunan apre isimli katman her temizlik malzemesi ile kolayca temizlenemez. Bu t&uuml;r b&ouml;lgeleri mutlaka uzman ekiplerin temizlemesi gerekir. Aksi takdirde yanlış temizlik malzemeleri ile temizlenirse, sararma meydana gelebilir.</p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Zebra Perde yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Stor &ccedil;eşitlerinden biri olan zebra perde, dekoratif g&ouml;r&uuml;n&uuml;mleri ve işlevsel olmaları ile pek &ccedil;ok yerde tercih edilmektedir. &Ccedil;ok sık kirlenmese de d&uuml;zenli olarak temizlenmeleri gerekir. Uzun s&uuml;re temizlenmezse &uuml;zerinde &ccedil;ıkarılamayan lekeler meydana gelebilir. En az 6 aylık bir s&uuml;rede bu perdelerin temizlenmesi gerekir. Zebraları temizlerken &ccedil;ok dikkat edilmelidir, dokuları &ccedil;ok serttir ve istemeden hasar verebilirsiniz. Oluşabilecek kalıcı hasarlar g&ouml;z &ouml;n&uuml;nde bulundurulduğunda hizmet almanız daha faydalı olacaktır.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Jaluzi Perde yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Jaluzi perdeler genellikle ofis ortamlarında kullanılan perdelerdendir. Temizlenmesi ise &ccedil;ok zor olabilir. &Ccedil;&uuml;nk&uuml; uzun boylu &ccedil;ubuklardan oluşurlar ve tek tek s&ouml;k&uuml;lme işlemi ister. Bu şekilde temizliği &ccedil;ok uzun s&uuml;rd&uuml;ğ&uuml; i&ccedil;in genelde hizmet alınarak temizlendirilir.&nbsp;</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Kruvaze Perde yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Kruvaze perdeler ortama şıklık ve zariflik katmaları ile bilinen perde modellerinden birisidir. Mekanizmalı bir perde &ccedil;eşididir ve s&ouml;k&uuml;l&uuml;p takılması da biraz uğraş ister. Bu tarz perdelerin gelişig&uuml;zel yıkanması, onlarda kalıcı hasar bırakabilir. Halka detayları kopabilir ya da makine i&ccedil;erisinde yırtılabilir. Bu t&uuml;r sorunlarla karşılaşmamak i&ccedil;in uzman ekiplerden yardım almak en doğru se&ccedil;enek olacaktır.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Fon Perde yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Diğer perde &ccedil;eşitlerine g&ouml;re en az kir tutan perdeler fon perdelerdir. Bu nedenle senede ortalama olarak 1 ya da 2 kez yıkanmaları yeterli olur. Nasıl yıkanacağı hakkında yeterli bilgi sahibi değilseniz, mutlaka uzmanlardan hizmet almanız gerekir. Aksi takdirde koyu renkli bir fon perdeye sahipseniz, renginde solmalar meydana gelebilir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Perde Yıkama Hizmeti Aşamaları</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">- Perdenin kirlilik durumu ilk olarak g&ouml;zlemlenir. Eğer gerekli bir durum varsa &ouml;zel bir şekilde hazırlanmış olan ila&ccedil;lı bir suya yatırılır. Uzun s&uuml;re yıkanmayan perdeler genel olarak bu şekilde yıkanma işlemine hazırlanır.<br />\r\n- İlk aşama sonrası perde &uuml;zerindeki kirler yumuşamış olur ve bu perdeler makineye atılır. Eğer gerekliyse &ouml;n yıkama ile yıkanır.<br />\r\n- Perdeler makine i&ccedil;erisindeyken dikkat edilmesi gerekilen en &ouml;nemli şey ise kumaş t&uuml;r&uuml;d&uuml;r. Perdenin oluştuğu kumaş t&uuml;r&uuml;ne g&ouml;re yıkama derecesi ve uzunluğu belirlenir.<br />\r\n- Yıkama işleminden sonra perdeler kurutma makineleri ya da &ouml;zel kurutma odalarından havalandırma sistemi ile asılarak kurutulur.<br />\r\n- Kurulama işlemi bittikten sonra perdeler kumaş tiplerine g&ouml;re &uuml;t&uuml;leme işlemi g&ouml;r&uuml;rler. Perde &uuml;t&uuml;leme işlemi mutlaka işini bilen uzmanlar tarafından yapılmalıdır. Aksi takdirde perde kumaşı &uuml;zerinde kalıcı hasar oluşabilir.<br />\r\n- &Uuml;t&uuml;leme işlemi bittikten sonra &ouml;zenli ve narin bir şekilde katlanırlar. Katlanmaya uygun olmayan perdeler ise askıya alınır ve ambalajlanır. Daha sonra ise sizlere teslim edilir.<br />\r\n- Tercihe g&ouml;re teslim edilen perdelerin montajı da yapılabilir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Perde Yıkama Hizmetinde Nelere Dikkat Edilmelidir?</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">- Yıkama işlemine girecek olan perdenin kumaşına g&ouml;re kullanılacak malzemeler belirlenmelidir.<br />\r\n- Kumaş tipine g&ouml;re yıkama y&ouml;ntemi ve derecesi se&ccedil;ilir.<br />\r\n- S&ouml;k&uuml;lmesi ve yerine tekrardan monte edilmesi uzman ekipler tarafından sağlanır.<br />\r\n- Evde yapılacak klasik yıkama y&ouml;ntemlerinin yerine işini bilen uzmanlar tarafından hizmet alınmalıdır.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Perde Yıkama Hizmeti Se&ccedil;imi</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Perde temizleme i&ccedil;in hizmet se&ccedil;imi yaparken dikkat edilmesi gereken pek &ccedil;ok unsur olabilir. Bunlardan en &ouml;nemlisi ise genel olarak fiyat &ccedil;eşitliğidir. Fiyatlandırmalar genel olarak metrekare &uuml;zerinden hesaplanır. Bunun dışında alacağınız hizmete veya anlaşacağınız ekiplere g&ouml;re de değişkenlik g&ouml;sterebilir.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Siz de bu hizmetlerden yararlanmak istiyorsanız web sitemizden bir iş ilanı oluşturabilirsiniz. B&ouml;ylelikle sizlere gelen fiyat tekliflerini değerlendirebilir ve en uygun olanı tercih edebilirsiniz. Gelecek olan uygun teklifleri değerlendirerek; t&uuml;l perde yıkama, stor perde temizliği gibi daha pek &ccedil;ok perde yıkama hizmetlerinden faydalanabilirsiniz.</span></p>\r\n');
INSERT INTO `kategoriler` (`id`, `baslik`, `ustkat`, `link`, `sira`, `hit`, `resim`, `teklifucreti`, `komisyonucreti`, `minteklif`, `title`, `description`, `icerik`) VALUES
(109, 'Tül Perde Yıkama', 50, 'tul-perde-yikama1610915742', 21, 0, '', '10', '5%', '50', '', '', '<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Stor Perde Yıkama Hizmeti</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Olduk&ccedil;a &ouml;zen ve dikkat isteyen bir hizmet olan perde yıkama işlemi, aynı zamanda bir o kadar da uğraştırıcı bir işlemdir. Perde yıkama hizmetleri, kirlenmiş olan perdeleri kumaş ya da model fark etmeksizin iyice temizleyen bir hizmettir. B&ouml;ylelikle perdeleriniz herhangi bir zarar g&ouml;rmeden yıkanıp temizlenmiş olur.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Perdeler Nasıl Yıkanmalıdır?</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Perdeler pek &ccedil;ok nedenden dolayı kirlenebilir. Bu y&uuml;zden d&uuml;zenli olarak temizlenmeleri de &ouml;nem kazanır. &Ouml;zellikle de kış mevsiminde ısıtıcıların yaydığı ısı ve tozlardan &ccedil;ok kolayca etkilenebilirler. Bahar mevsiminin gelmesi ile perdelerin temizlenmesi gerekli bir işlemdir. Perde yıkama y&ouml;ntemleri, perdelerin kumaşlarına g&ouml;re farklılık g&ouml;stermektedir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">T&uuml;l Perde Yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Beyaz t&uuml;ller evlerin vazge&ccedil;ilmez par&ccedil;alarından birisidir. Ancak olduk&ccedil;a narin bir dokuya sahip oldukları i&ccedil;in temizlikleri de bir o kadar zor ger&ccedil;ekleşir. T&uuml;l perdeler; g&uuml;neş ışığı, kirli hava, sigara ya da yemek dumanı, kalorifer ısısı gibi pek &ccedil;ok sebepten hemen kirlenebilir. Bunun dışında zamanla renk de değiştirebilir. Senede birka&ccedil; kez yıkanması &ouml;nemlidir. Doğru olmayan yıkama &ccedil;eşitleri ile yıkanan t&uuml;l perdeler, &ccedil;ok kolayca yıpranıp eskiyebilir. Bu nedenle perde yıkama hizmeti almak gerekli bir durumdur. Bu hizmette perdeler g&uuml;zelce yıkanır ve &uuml;t&uuml;lenerek teslim edilir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Stor Perde Yıkama</span></h2>\r\n\r\n<p>Hem şık hem de kolay kullanımları ile her ge&ccedil;en g&uuml;n daha da yaygınlaşan stor perdeler, &ouml;zellikle de mutfaklarda &ccedil;ok tercih edilmeye başlanmıştır. Fakat bu perdeleri temizlemek de fazlasıyla zordur. Genelde stor perde yıkama işlemi evde pek başarılı olmaz. Perdeler yıpranır ve kullanılamayacak bir hale gelir. Bu y&uuml;zden stor perde yıkama hizmeti almak gerekir. Spor perdelerde bulunan apre isimli katman her temizlik malzemesi ile kolayca temizlenemez. Bu t&uuml;r b&ouml;lgeleri mutlaka uzman ekiplerin temizlemesi gerekir. Aksi takdirde yanlış temizlik malzemeleri ile temizlenirse, sararma meydana gelebilir.</p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Zebra Perde yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Stor &ccedil;eşitlerinden biri olan zebra perde, dekoratif g&ouml;r&uuml;n&uuml;mleri ve işlevsel olmaları ile pek &ccedil;ok yerde tercih edilmektedir. &Ccedil;ok sık kirlenmese de d&uuml;zenli olarak temizlenmeleri gerekir. Uzun s&uuml;re temizlenmezse &uuml;zerinde &ccedil;ıkarılamayan lekeler meydana gelebilir. En az 6 aylık bir s&uuml;rede bu perdelerin temizlenmesi gerekir. Zebraları temizlerken &ccedil;ok dikkat edilmelidir, dokuları &ccedil;ok serttir ve istemeden hasar verebilirsiniz. Oluşabilecek kalıcı hasarlar g&ouml;z &ouml;n&uuml;nde bulundurulduğunda hizmet almanız daha faydalı olacaktır.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Jaluzi Perde yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Jaluzi perdeler genellikle ofis ortamlarında kullanılan perdelerdendir. Temizlenmesi ise &ccedil;ok zor olabilir. &Ccedil;&uuml;nk&uuml; uzun boylu &ccedil;ubuklardan oluşurlar ve tek tek s&ouml;k&uuml;lme işlemi ister. Bu şekilde temizliği &ccedil;ok uzun s&uuml;rd&uuml;ğ&uuml; i&ccedil;in genelde hizmet alınarak temizlendirilir.&nbsp;</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Kruvaze Perde yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Kruvaze perdeler ortama şıklık ve zariflik katmaları ile bilinen perde modellerinden birisidir. Mekanizmalı bir perde &ccedil;eşididir ve s&ouml;k&uuml;l&uuml;p takılması da biraz uğraş ister. Bu tarz perdelerin gelişig&uuml;zel yıkanması, onlarda kalıcı hasar bırakabilir. Halka detayları kopabilir ya da makine i&ccedil;erisinde yırtılabilir. Bu t&uuml;r sorunlarla karşılaşmamak i&ccedil;in uzman ekiplerden yardım almak en doğru se&ccedil;enek olacaktır.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Fon Perde yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Diğer perde &ccedil;eşitlerine g&ouml;re en az kir tutan perdeler fon perdelerdir. Bu nedenle senede ortalama olarak 1 ya da 2 kez yıkanmaları yeterli olur. Nasıl yıkanacağı hakkında yeterli bilgi sahibi değilseniz, mutlaka uzmanlardan hizmet almanız gerekir. Aksi takdirde koyu renkli bir fon perdeye sahipseniz, renginde solmalar meydana gelebilir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Perde Yıkama Hizmeti Aşamaları</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">- Perdenin kirlilik durumu ilk olarak g&ouml;zlemlenir. Eğer gerekli bir durum varsa &ouml;zel bir şekilde hazırlanmış olan ila&ccedil;lı bir suya yatırılır. Uzun s&uuml;re yıkanmayan perdeler genel olarak bu şekilde yıkanma işlemine hazırlanır.<br />\r\n- İlk aşama sonrası perde &uuml;zerindeki kirler yumuşamış olur ve bu perdeler makineye atılır. Eğer gerekliyse &ouml;n yıkama ile yıkanır.<br />\r\n- Perdeler makine i&ccedil;erisindeyken dikkat edilmesi gerekilen en &ouml;nemli şey ise kumaş t&uuml;r&uuml;d&uuml;r. Perdenin oluştuğu kumaş t&uuml;r&uuml;ne g&ouml;re yıkama derecesi ve uzunluğu belirlenir.<br />\r\n- Yıkama işleminden sonra perdeler kurutma makineleri ya da &ouml;zel kurutma odalarından havalandırma sistemi ile asılarak kurutulur.<br />\r\n- Kurulama işlemi bittikten sonra perdeler kumaş tiplerine g&ouml;re &uuml;t&uuml;leme işlemi g&ouml;r&uuml;rler. Perde &uuml;t&uuml;leme işlemi mutlaka işini bilen uzmanlar tarafından yapılmalıdır. Aksi takdirde perde kumaşı &uuml;zerinde kalıcı hasar oluşabilir.<br />\r\n- &Uuml;t&uuml;leme işlemi bittikten sonra &ouml;zenli ve narin bir şekilde katlanırlar. Katlanmaya uygun olmayan perdeler ise askıya alınır ve ambalajlanır. Daha sonra ise sizlere teslim edilir.<br />\r\n- Tercihe g&ouml;re teslim edilen perdelerin montajı da yapılabilir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Perde Yıkama Hizmetinde Nelere Dikkat Edilmelidir?</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">- Yıkama işlemine girecek olan perdenin kumaşına g&ouml;re kullanılacak malzemeler belirlenmelidir.<br />\r\n- Kumaş tipine g&ouml;re yıkama y&ouml;ntemi ve derecesi se&ccedil;ilir.<br />\r\n- S&ouml;k&uuml;lmesi ve yerine tekrardan monte edilmesi uzman ekipler tarafından sağlanır.<br />\r\n- Evde yapılacak klasik yıkama y&ouml;ntemlerinin yerine işini bilen uzmanlar tarafından hizmet alınmalıdır.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Perde Yıkama Hizmeti Se&ccedil;imi</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Perde temizleme i&ccedil;in hizmet se&ccedil;imi yaparken dikkat edilmesi gereken pek &ccedil;ok unsur olabilir. Bunlardan en &ouml;nemlisi ise genel olarak fiyat &ccedil;eşitliğidir. Fiyatlandırmalar genel olarak metrekare &uuml;zerinden hesaplanır. Bunun dışında alacağınız hizmete veya anlaşacağınız ekiplere g&ouml;re de değişkenlik g&ouml;sterebilir.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Siz de bu hizmetlerden yararlanmak istiyorsanız web sitemizden bir iş ilanı oluşturabilirsiniz. B&ouml;ylelikle sizlere gelen fiyat tekliflerini değerlendirebilir ve en uygun olanı tercih edebilirsiniz. Gelecek olan uygun teklifleri değerlendirerek; t&uuml;l perde yıkama, stor perde temizliği gibi daha pek &ccedil;ok perde yıkama hizmetlerinden faydalanabilirsiniz.</span></p>\r\n'),
(110, 'Fon Perde Yıkama', 50, 'fon-perde-yikama1610915755', 22, 0, '', '10', '5%', '50', '', '', '<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Stor Perde Yıkama Hizmeti</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Olduk&ccedil;a &ouml;zen ve dikkat isteyen bir hizmet olan perde yıkama işlemi, aynı zamanda bir o kadar da uğraştırıcı bir işlemdir. Perde yıkama hizmetleri, kirlenmiş olan perdeleri kumaş ya da model fark etmeksizin iyice temizleyen bir hizmettir. B&ouml;ylelikle perdeleriniz herhangi bir zarar g&ouml;rmeden yıkanıp temizlenmiş olur.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Perdeler Nasıl Yıkanmalıdır?</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Perdeler pek &ccedil;ok nedenden dolayı kirlenebilir. Bu y&uuml;zden d&uuml;zenli olarak temizlenmeleri de &ouml;nem kazanır. &Ouml;zellikle de kış mevsiminde ısıtıcıların yaydığı ısı ve tozlardan &ccedil;ok kolayca etkilenebilirler. Bahar mevsiminin gelmesi ile perdelerin temizlenmesi gerekli bir işlemdir. Perde yıkama y&ouml;ntemleri, perdelerin kumaşlarına g&ouml;re farklılık g&ouml;stermektedir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">T&uuml;l Perde Yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Beyaz t&uuml;ller evlerin vazge&ccedil;ilmez par&ccedil;alarından birisidir. Ancak olduk&ccedil;a narin bir dokuya sahip oldukları i&ccedil;in temizlikleri de bir o kadar zor ger&ccedil;ekleşir. T&uuml;l perdeler; g&uuml;neş ışığı, kirli hava, sigara ya da yemek dumanı, kalorifer ısısı gibi pek &ccedil;ok sebepten hemen kirlenebilir. Bunun dışında zamanla renk de değiştirebilir. Senede birka&ccedil; kez yıkanması &ouml;nemlidir. Doğru olmayan yıkama &ccedil;eşitleri ile yıkanan t&uuml;l perdeler, &ccedil;ok kolayca yıpranıp eskiyebilir. Bu nedenle perde yıkama hizmeti almak gerekli bir durumdur. Bu hizmette perdeler g&uuml;zelce yıkanır ve &uuml;t&uuml;lenerek teslim edilir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Stor Perde Yıkama</span></h2>\r\n\r\n<p>Hem şık hem de kolay kullanımları ile her ge&ccedil;en g&uuml;n daha da yaygınlaşan stor perdeler, &ouml;zellikle de mutfaklarda &ccedil;ok tercih edilmeye başlanmıştır. Fakat bu perdeleri temizlemek de fazlasıyla zordur. Genelde stor perde yıkama işlemi evde pek başarılı olmaz. Perdeler yıpranır ve kullanılamayacak bir hale gelir. Bu y&uuml;zden stor perde yıkama hizmeti almak gerekir. Spor perdelerde bulunan apre isimli katman her temizlik malzemesi ile kolayca temizlenemez. Bu t&uuml;r b&ouml;lgeleri mutlaka uzman ekiplerin temizlemesi gerekir. Aksi takdirde yanlış temizlik malzemeleri ile temizlenirse, sararma meydana gelebilir.</p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Zebra Perde yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Stor &ccedil;eşitlerinden biri olan zebra perde, dekoratif g&ouml;r&uuml;n&uuml;mleri ve işlevsel olmaları ile pek &ccedil;ok yerde tercih edilmektedir. &Ccedil;ok sık kirlenmese de d&uuml;zenli olarak temizlenmeleri gerekir. Uzun s&uuml;re temizlenmezse &uuml;zerinde &ccedil;ıkarılamayan lekeler meydana gelebilir. En az 6 aylık bir s&uuml;rede bu perdelerin temizlenmesi gerekir. Zebraları temizlerken &ccedil;ok dikkat edilmelidir, dokuları &ccedil;ok serttir ve istemeden hasar verebilirsiniz. Oluşabilecek kalıcı hasarlar g&ouml;z &ouml;n&uuml;nde bulundurulduğunda hizmet almanız daha faydalı olacaktır.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Jaluzi Perde yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Jaluzi perdeler genellikle ofis ortamlarında kullanılan perdelerdendir. Temizlenmesi ise &ccedil;ok zor olabilir. &Ccedil;&uuml;nk&uuml; uzun boylu &ccedil;ubuklardan oluşurlar ve tek tek s&ouml;k&uuml;lme işlemi ister. Bu şekilde temizliği &ccedil;ok uzun s&uuml;rd&uuml;ğ&uuml; i&ccedil;in genelde hizmet alınarak temizlendirilir.&nbsp;</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Kruvaze Perde yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Kruvaze perdeler ortama şıklık ve zariflik katmaları ile bilinen perde modellerinden birisidir. Mekanizmalı bir perde &ccedil;eşididir ve s&ouml;k&uuml;l&uuml;p takılması da biraz uğraş ister. Bu tarz perdelerin gelişig&uuml;zel yıkanması, onlarda kalıcı hasar bırakabilir. Halka detayları kopabilir ya da makine i&ccedil;erisinde yırtılabilir. Bu t&uuml;r sorunlarla karşılaşmamak i&ccedil;in uzman ekiplerden yardım almak en doğru se&ccedil;enek olacaktır.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Fon Perde yıkama</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Diğer perde &ccedil;eşitlerine g&ouml;re en az kir tutan perdeler fon perdelerdir. Bu nedenle senede ortalama olarak 1 ya da 2 kez yıkanmaları yeterli olur. Nasıl yıkanacağı hakkında yeterli bilgi sahibi değilseniz, mutlaka uzmanlardan hizmet almanız gerekir. Aksi takdirde koyu renkli bir fon perdeye sahipseniz, renginde solmalar meydana gelebilir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Perde Yıkama Hizmeti Aşamaları</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">- Perdenin kirlilik durumu ilk olarak g&ouml;zlemlenir. Eğer gerekli bir durum varsa &ouml;zel bir şekilde hazırlanmış olan ila&ccedil;lı bir suya yatırılır. Uzun s&uuml;re yıkanmayan perdeler genel olarak bu şekilde yıkanma işlemine hazırlanır.<br />\r\n- İlk aşama sonrası perde &uuml;zerindeki kirler yumuşamış olur ve bu perdeler makineye atılır. Eğer gerekliyse &ouml;n yıkama ile yıkanır.<br />\r\n- Perdeler makine i&ccedil;erisindeyken dikkat edilmesi gerekilen en &ouml;nemli şey ise kumaş t&uuml;r&uuml;d&uuml;r. Perdenin oluştuğu kumaş t&uuml;r&uuml;ne g&ouml;re yıkama derecesi ve uzunluğu belirlenir.<br />\r\n- Yıkama işleminden sonra perdeler kurutma makineleri ya da &ouml;zel kurutma odalarından havalandırma sistemi ile asılarak kurutulur.<br />\r\n- Kurulama işlemi bittikten sonra perdeler kumaş tiplerine g&ouml;re &uuml;t&uuml;leme işlemi g&ouml;r&uuml;rler. Perde &uuml;t&uuml;leme işlemi mutlaka işini bilen uzmanlar tarafından yapılmalıdır. Aksi takdirde perde kumaşı &uuml;zerinde kalıcı hasar oluşabilir.<br />\r\n- &Uuml;t&uuml;leme işlemi bittikten sonra &ouml;zenli ve narin bir şekilde katlanırlar. Katlanmaya uygun olmayan perdeler ise askıya alınır ve ambalajlanır. Daha sonra ise sizlere teslim edilir.<br />\r\n- Tercihe g&ouml;re teslim edilen perdelerin montajı da yapılabilir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Perde Yıkama Hizmetinde Nelere Dikkat Edilmelidir?</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">- Yıkama işlemine girecek olan perdenin kumaşına g&ouml;re kullanılacak malzemeler belirlenmelidir.<br />\r\n- Kumaş tipine g&ouml;re yıkama y&ouml;ntemi ve derecesi se&ccedil;ilir.<br />\r\n- S&ouml;k&uuml;lmesi ve yerine tekrardan monte edilmesi uzman ekipler tarafından sağlanır.<br />\r\n- Evde yapılacak klasik yıkama y&ouml;ntemlerinin yerine işini bilen uzmanlar tarafından hizmet alınmalıdır.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Perde Yıkama Hizmeti Se&ccedil;imi</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Perde temizleme i&ccedil;in hizmet se&ccedil;imi yaparken dikkat edilmesi gereken pek &ccedil;ok unsur olabilir. Bunlardan en &ouml;nemlisi ise genel olarak fiyat &ccedil;eşitliğidir. Fiyatlandırmalar genel olarak metrekare &uuml;zerinden hesaplanır. Bunun dışında alacağınız hizmete veya anlaşacağınız ekiplere g&ouml;re de değişkenlik g&ouml;sterebilir.</span></p>\r\n\r\n<p><span style=\"font-size:16px\">Siz de bu hizmetlerden yararlanmak istiyorsanız web sitemizden bir iş ilanı oluşturabilirsiniz. B&ouml;ylelikle sizlere gelen fiyat tekliflerini değerlendirebilir ve en uygun olanı tercih edebilirsiniz. Gelecek olan uygun teklifleri değerlendirerek; t&uuml;l perde yıkama, stor perde temizliği gibi daha pek &ccedil;ok perde yıkama hizmetlerinden faydalanabilirsiniz.</span></p>\r\n'),
(111, 'Dezenfeksiyon', 8, 'dezenfeksiyon-1610917390', 1, 0, '', '3', '5%', '150', '', '', '<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Dezenfeksiyon Nedir? Nasıl Yapılır? </span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Toprak, hava, insan v&uuml;cudu ve t&uuml;m &ccedil;evremizde, mikroorganizmalar kendilerine yaşam alanı bulurlar. Evlerimizdeki halılar, kumaşlar, koltuklar ve yerler bakteri, mantar ve vir&uuml;s yuvasıdır. Ayrıca temizlik yaparken kullanılan malzemelere karşı olduk&ccedil;a dayanıklı olan bir&ccedil;ok bakteri yaşar. Evinizi veya iş yerinizi tamamen mikroorganizmalardan kurtarmak i&ccedil;in yapabileceklerinizin başında, dezenfeksiyon gelir. &Ouml;zellikle tıbbi ve cerrahi girişimler sırasında tamamen mikrop ve bakterilerden arındırılmış bir ortam gerekir. Ameliyathane, diyaliz, yoğun bakım, transplantasyon ve yeni doğan bebek &uuml;niteleri gibi yerlerde ortam havası ve malzemeler belirli bazı kurallara uymalıdır. Dezenfeksiyon sayesinde, cansız ortamdaki patojen mikroorganizmalar &ouml;ld&uuml;r&uuml;l&uuml;r. Aynı zamanda bu t&uuml;r mikroorganizmaların &uuml;remeleri de dezenfeksiyon uygulanarak engellenir.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Dezenfeksiyon Nedir? &nbsp;</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Hastalık yapma &ouml;zelliği bulunan mikropların uzaklaştırılması ve tamamen ortadan kaldırılması işlemine dezenfeksiyon denir. Dezenfeksiyon, geniş bir aralığı tanımlar. Dezenfeksiyon işleminde, genelde kimyasalların oluşturduğu dezenfektanlar kullanılır. İki farklı dezenfeksiyon y&ouml;ntemi bulunur. Biri y&uuml;ksek ısı derecesi kullanılarak ve mikroorganizmaları tamamen yok etme ama&ccedil;lanarak yapılır; diğeri de y&uuml;ksek d&uuml;zeyli dezenfeksiyondur ve uzun bir s&uuml;re&ccedil;te uygulanarak yapılır. </span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Sterilizasyon Nedir? </span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Bir maddenin &uuml;zerinde veya i&ccedil;inde bulunan t&uuml;m mikroorganizmaların arındırılma işlemine sterilizasyon denir. Sterilizasyon işlemi uygulandıktan sonra ortamdaki t&uuml;m mikroorganizmalar &ouml;ld&uuml;r&uuml;l&uuml;r. Sterilizasyonun dereceleri bulunmaz; tek seferlik bir işlemdir. Bir kere yapıldığı zaman t&uuml;m sporsuz bakteriler, vir&uuml;sler, mantarlar gibi mikroorganizmalar yok olur. Sterilizasyonun amacı t&uuml;m organizmaların ortadan kaldırılmasıdır.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Dezenfeksiyon Yapılırken Nasıl Maddeler Kullanılır? </span>&nbsp;</h2>\r\n\r\n<p><span style=\"font-size:16px\">T&uuml;m mikroorganizmaları &ouml;ld&uuml;rebilen maddeler.Hızlı etki eden maddeler. Toksik barındırmayan maddeler. N&ouml;tral pH ya da suda &ccedil;&ouml;z&uuml;lebilen maddeler. Renksiz ve kokusuz maddeler Stabil maddeler. Eşyalara zarar vermeyen maddeler. &Ccedil;evreye zarar vermeyen maddeler. Ucuz ve kullanımı kolay maddeler. </span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Dezenfeksiyon Y&ouml;ntemleri </span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Isı ile Dezenfeksiyon Isı ile dezenfeksiyon evlerde en &ccedil;ok kullanılan y&ouml;ntemdir. Suyu 15-20 dakika kaynatarak patojen maddelerin &ouml;lmesi sağlanır. Fakat b&uuml;y&uuml;k &ouml;l&ccedil;ekli uygulamalarda, altından kalkamayacağınız kadar yorucu bir y&ouml;ntemdir. </span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Isı ile Dezenfeksiyonda Nasıl Etkili Olunur? </span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Sıcaklığın derecesi, </span></p>\r\n\r\n<p><span style=\"font-size:16px\">ortamdaki basın&ccedil;, </span></p>\r\n\r\n<p><span style=\"font-size:16px\">temas s&uuml;resi, </span></p>\r\n\r\n<p><span style=\"font-size:16px\">mikroorganizmanın ısı direnci. </span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">UV Işını ile Dezenfeksiyon</span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Baker tarafından ilk kez 1910 yılında Fransa&rsquo;da kullanılan y&ouml;ntem, diğer kimyasal maddelerden etkilenmeyen bir uygulamadır. Temas s&uuml;resi kısa olmasına rağmen lokal olarak etkilidir. Sistemdeki biyofilm i&ccedil;erisinde etkisiz olan UV radyasyonu suyun fiziksel veya kimyasal &ouml;zelliğini değiştirmez. Bu işlem uygulanırken olduk&ccedil;a y&uuml;ksek miktarda enerji ihtiyacına ve pahalı ekipmanlara ihtiya&ccedil; duyulur.</span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Kimyasal Dezenfektanlar İle Dezenfeksiyon </span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Dezenfeksiyon işlemlerinde brom, iyot, klor ve hidrojen peroksit gibi halojenler kullanılır. &nbsp;</span></p>\r\n\r\n<h3>Brom</h3>\r\n\r\n<p><span style=\"font-size:16px\">Halojen ve sıvı haldeki Brom, koyu kırmızı-kahverengidir. Deri ile temasta yanıklara neden olan bu kimyasal, sudan 3.2 kat daha ağırdır. Germisidal etkisi y&uuml;ksek olan brom, y&uuml;zme havuzlarının dezenfeksiyonunda da kullanılır. </span></p>\r\n\r\n<h3>Klor</h3>\r\n\r\n<p><span style=\"font-size:16px\">Klor, dezenfeksiyon yapılırken en &ccedil;ok kullanılan halojendir. Yaygın olarak kullanılması, dezenfeksiyon işleminin &ldquo;Klorlamak&rdquo; olarak kullanılmasına bile neden olmuştur. İlk olarak suların dezenfeksiyonu amacıyla İngiltere&rsquo;de kullanılan klor, sıvılaştırılmış gaz, kalsiyum hipokloritler ve sodyum halinde piyasada bulunur.</span></p>\r\n\r\n<h3>Ozon</h3>\r\n\r\n<p><span style=\"font-size:16px\">Keskin kokulu, a&ccedil;ık mavi renkteki ozon, stabil olmayan bir gazdır. Bu nedenle ozon kullanılacağı zaman imal edilir. Fransa&rsquo;da 70&rsquo;ten fazla kentin i&ccedil;me suyu, ozon ile dezenfekte ediliyor. Ayrıca ozon yalnızca dezenfekte etmek i&ccedil;in değil, suyun rengini ve kokusunu gidermek i&ccedil;in de kullanılıyor. </span></p>\r\n\r\n<hr />\r\n<h2 style=\"text-align:center\"><span style=\"color:#27ae60\">Su Deposu Dezenfeksiyonu </span></h2>\r\n\r\n<p><span style=\"font-size:16px\">Apartmanların ortak kullanımına a&ccedil;ık olan su depolarının d&uuml;zenli bir şekilde sterilizasyon ve dezenfeksiyon işlemlerinden ge&ccedil;mesi gerekir. Suyun hi&ccedil;bir şekilde i&ccedil;eriğini değiştirmeyen kimyasallar ve &ouml;zel y&ouml;ntemlerle yapılan su deposu dezenfeksiyonu i&ccedil;in profesyonel yardım almak, her zaman sağlıklı ve temiz bir suya sahip olmanızı sağlar.</span></p>\r\n');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `mesajlar`
--

CREATE TABLE `mesajlar` (
  `id` int(11) NOT NULL,
  `kimden` text DEFAULT NULL,
  `kime` text DEFAULT NULL,
  `kimdenid` int(11) NOT NULL DEFAULT 0,
  `kimeid` int(11) NOT NULL DEFAULT 0,
  `kimdenresim` text DEFAULT NULL,
  `konu` text DEFAULT NULL,
  `icerik` text DEFAULT NULL,
  `ekler` text DEFAULT NULL,
  `tarih` timestamp NOT NULL DEFAULT current_timestamp(),
  `okundu` text DEFAULT NULL,
  `sil1` text DEFAULT NULL,
  `sil2` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `paketler`
--

CREATE TABLE `paketler` (
  `id` int(11) NOT NULL,
  `baslik` mediumtext NOT NULL,
  `altbaslik` mediumtext NOT NULL,
  `ozellikler` mediumtext NOT NULL,
  `ucret` int(11) NOT NULL,
  `sure` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `paketler`
--

INSERT INTO `paketler` (`id`, `baslik`, `altbaslik`, `ozellikler`, `ucret`, `sure`) VALUES
(1, 'BAŞLANGIÇ PAKETİ', 'Tüm işlere ücretsiz teklif verin', 'Taleplerin E-Posta ile bildirimi,Taleplerin SMS ile bildirimi,Ücretsiz Teklif Verme', 0, 1),
(2, 'SINIRSIZ PAKET', 'Teklif ve Komisyon Ücreti ödemeyin', 'Taleplerin E-Posta ile bildirimi,Taleplerin SMS ile bildirimi,Ücretsiz Teklif Verme,Sıfır Komisyon', 500, 12);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `paketozellikleri`
--

CREATE TABLE `paketozellikleri` (
  `id` int(11) NOT NULL,
  `ozellik` mediumtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `paketozellikleri`
--

INSERT INTO `paketozellikleri` (`id`, `ozellik`) VALUES
(1, 'Taleplerin E-Posta ile bildirimi'),
(2, 'Taleplerin SMS ile bildirimi'),
(3, 'Ücretsiz Teklif Verme'),
(4, 'Sıfır Komisyon');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `sayfalar`
--

CREATE TABLE `sayfalar` (
  `id` int(11) NOT NULL,
  `baslik` text DEFAULT NULL,
  `link` text DEFAULT NULL,
  `icerik` longtext DEFAULT NULL,
  `ozet` text DEFAULT NULL,
  `etiket` text DEFAULT NULL,
  `kapak` text DEFAULT NULL,
  `galeri` text DEFAULT NULL,
  `durum` text DEFAULT NULL,
  `hit` int(11) NOT NULL DEFAULT 0,
  `tarih` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `sayfalar`
--

INSERT INTO `sayfalar` (`id`, `baslik`, `link`, `icerik`, `ozet`, `etiket`, `kapak`, `galeri`, `durum`, `hit`, `tarih`) VALUES
(3, 'Gelen teklifleri nasıl görebilirim?', 'gelen-teklifleri-nasil-gorebilirim', '<p>Talep ettiğiniz hizmete teklif geldiğinde size bildirim g&ouml;ndererek haberdar edeceğiz.</p>\r\n\r\n<p><strong>Taleplerim</strong> sekmesinden size teklif g&ouml;nderenleri g&ouml;rebilir ve inceleyebilirsiniz.</p>\r\n', '', 'sayfa', NULL, '1543341376', 'Evet', 373, '2018-11-27 17:56:41'),
(4, 'Talebim hizmet verenlere nasıl ulaşacak?', 'talebim-hizmet-verenlere-nasil-ulasacak', '<p>Talebiniz doğrultusunda bulunduğunuz konuma&nbsp;hizmet g&ouml;t&uuml;rebilecek t&uuml;m profesyonellere biz bildirim g&ouml;ndereceğiz. Ve sizinle iletişime ge&ccedil;melerini sağlayacağız.</p>\r\n', '', 'sayfa', NULL, '1543341403', 'Evet', 310, '2018-11-27 17:58:07'),
(5, 'Teklifler geldi, şimdi ne yapmalıyım?', 'teklifler-geldi-simdi-ne-yapmaliyim', '<p>Size teklif g&ouml;nderenleri değerlendirerek sistem &uuml;zerinden teklifi onaylamanız gerekmektedir.&nbsp;Teklif verenin&nbsp;daha &ouml;nce yapmış olduğu işleri ve referanslarını g&ouml;rmek&nbsp; i&ccedil;in profilini inceleyebilirsiniz.&nbsp;</p>\r\n', '', 'sayfa', NULL, '1543341568', 'Evet', 331, '2018-11-27 17:59:47'),
(6, 'Profil bilgilerimi nasıl güncelleyebilirim?', 'profil-bilgilerimi-nasil-guncelleyebilirim', '<p>Hesabınızda&nbsp;<strong>&nbsp;Profilim</strong> sekmesine tıklayarak;&nbsp;&nbsp;&Uuml;nvan ,Telefon numarası ve Adresinizi kolayca g&uuml;ncelleyebilirsiniz.</p>\r\n', '', 'sayfa', NULL, '1543341590', 'Evet', 273, '2018-11-27 18:00:19'),
(8, 'İnternetten Yapılan Tüketici İşlemlerinde Yasal Haklar', 'internetten-yapilan-tuketici-islemlerinde-yasal-haklar', '<p>Mesafeli s&ouml;zleşme; satıcı veya sağlayıcı ile t&uuml;keticinin eş zamanlı fiziksel varlığı olmaksızın, mal veya hizmetlerin uzaktan pazarlanmasına y&ouml;nelik olarak oluşturulmuş bir sistem &ccedil;er&ccedil;evesinde, taraflar arasında s&ouml;zleşmenin kurulduğu ana kadar ve kurulduğu an da dahil olmak &uuml;zere (telefon ve internet gibi) uzaktan iletişim ara&ccedil;larının kullanılması suretiyle kurulan s&ouml;zleşmedir.<br />\r\n&nbsp;</p>\r\n\r\n<ul>\r\n	<li>T&uuml;ketici, s&ouml;zleşmenin kurulmasından &ouml;nce, mal veya hizmete dair hususlarda satıcı veya sağlayıcı tarafından bilgilendirilmek zorundadır. Mesafeli s&ouml;zleşmenin en &ouml;nemli unsurlarından olan &ouml;n bilgilendirmenin amacı; t&uuml;keticilerin satıcı veya sağlayıcı ile karşı karşıya gelmediği ve almayı d&uuml;ş&uuml;nd&uuml;ğ&uuml; mal veya hizmeti somut olarak g&ouml;rmediği veya deneyemediği alışveriş y&ouml;nteminde s&ouml;zleşme konusu mal veya hizmete dair &ouml;nemli hususların alışverişten &ouml;nce verilmesinin sağlanarak, t&uuml;keticilerin neyi satın almak &uuml;zere oldukları ve ne gibi hak ve y&uuml;k&uuml;ml&uuml;l&uuml;klere sahip oldukları konusunda haberdar etmektir.<br />\r\n	&nbsp;</li>\r\n	<li>T&uuml;keticinin&nbsp;14 g&uuml;n i&ccedil;inde herhangi bir gerek&ccedil;e g&ouml;stermeksizin ve cezai şart &ouml;demeksizin&nbsp;s&ouml;zleşmeden&nbsp;cayma hakkı&nbsp;mevcuttur. S&ouml;zleşmenin kurulmasından malın teslimine kadar olan s&uuml;re i&ccedil;inde de cayma hakkı kullanılabilir. &Ouml;n bilgilendirme y&uuml;k&uuml;ml&uuml;l&uuml;ğ&uuml; yerine getirilmezse cayma hakkı s&uuml;resi 1 yıla &ccedil;ıkmaktadır.<br />\r\n	&nbsp;</li>\r\n	<li>Cayma hakkının bazı istisnaları vardır. &Ouml;rneğin, &ccedil;abuk bozulabilen ve son kullanma tarihi ge&ccedil;ebilecek mallar ya da t&uuml;keticinin istekleri veya kişisel ihtiya&ccedil;ları doğrultusunda hazırlanan mallara ilişkin s&ouml;zleşmelerde cayma hakkı kullanılamamaktadır. &nbsp;<br />\r\n	&nbsp;</li>\r\n	<li>Cayma hakkının kullanımı i&ccedil;in satıcı veya sağlayıcıya yazılı olarak veya kalıcı veri saklayıcısı ile bildirim yapılması yeterlidir.<br />\r\n	&nbsp;</li>\r\n	<li>Cayma hakkının kullanılması durumunda t&uuml;ketici malı 10 g&uuml;n i&ccedil;inde satıcının belirtmiş olduğu kargo firması ile &uuml;cretsiz olarak iade etmeli ve satıcı da 14 g&uuml;n i&ccedil;inde bedel iadesini yapmalıdır. T&uuml;ketici, cayma s&uuml;resi i&ccedil;inde malı, işleyişine, teknik &ouml;zelliklerine ve kullanım talimatlarına uygun bir şekilde kullandığı takdirde meydana gelen değişiklik ve bozulmalardan sorumlu değildir.<br />\r\n	&nbsp;</li>\r\n	<li>Satıcı veya sağlayıcı siparişini taahh&uuml;t ettiği s&uuml;re i&ccedil;inde yerine getirmek zorundadır. Mal satışlarında bu s&uuml;re 30 g&uuml;n&uuml; ge&ccedil;emez. Aksi takdirde t&uuml;ketici s&ouml;zleşmeyi feshedebilir.</li>\r\n</ul>\r\n', '', 'blog', '/panel/upload/resimler/5fd67521c5b93.png', '1607889933', 'Evet', 125, '2020-12-13 20:10:14'),
(9, 'Kredi Kartı Güvenliği Nasıl Sağlanır?', 'kredi-karti-guvenligi-nasil-saglanir', '<p>G&uuml;nl&uuml;k hayatımızın vazge&ccedil;ilmez birer aracı olan maaş kartı ve&nbsp;kredi kartı&nbsp;bilgilerinin&nbsp;g&uuml;venliklerinin sağlanması &ccedil;ok &ouml;nemli bir konu. Bankamatik, POS cihazı,&nbsp;internet&nbsp;vb alanlar bu kartları kullandığımız noktalardan sadece birka&ccedil;ı.&nbsp;</p>\r\n\r\n<p>Peki bu kartları korumanın en kolay yolları nelerdir? İşte soru ve cevaplarla g&uuml;venli&nbsp;alışverişin yolları&hellip;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>İnternette kart bilgilerimi girerken nelere dikkat etmeliyim?</strong></p>\r\n\r\n<p>Sitenin adres &ccedil;ubuğunda &ldquo;https&rdquo; uzantılı bir adres olduğundan emin olmalısınız. İlaveten &ldquo;ssl&rdquo; g&uuml;venlik sertifikası da olmalı. G&uuml;venmediğiniz sitelerden alışveriş yapmayıp, e-posta yoluyla kart bilgisi ya da şifre talep eden firmalara da itimat etmeyerek kendinizi koruyabilirsiniz.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>İnternetten alışverişin en g&uuml;venli yolu&nbsp;nedir?</strong></p>\r\n\r\n<p>İnternetten alışveriş i&ccedil;in kullanmanız gereken en sağlıklı y&ouml;ntem &ldquo;sanal kart&rdquo; kullanmaktır. Sanal kartınıza yaptığınız y&uuml;kleme kadar harcama yapabilirsiniz. Bu sayede kart numaranız başkalarının eline ge&ccedil;se bile limiti sizin kontrol&uuml;n&uuml;zde olduğu i&ccedil;in g&uuml;vence altında olacaktır.</p>\r\n\r\n<p>Ayrıca 3D &ouml;deme se&ccedil;eneğini de aktif edebilirsiniz. Bu son &ouml;deme işleminde, cep telefonunuza gelen bir doğrulama kodu ile fazladan bir g&uuml;venlik adımı eklenmesi anlamına gelmektedir. Telefonunuza gelen kodu ilgili forma girmediğiniz s&uuml;rece &ouml;deme ger&ccedil;ekleşmez. Bu se&ccedil;enek i&ccedil;in bankanız ile g&ouml;r&uuml;şebilirsiniz.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Şifremi nasıl korurum?</strong></p>\r\n\r\n<p>Evinizin anahtarı neyse, kartlarınızın şifresi de odur. Bu nedenle kolay tahmin edilemeyecek şifreler belirlemelisiniz. Doğum tarihi, takımınızın kuruluş tarihi gibi şifrelerden uzak durun. ATM ve POS cihazlarına şifrenizi girerken kimseye g&ouml;stermemeli ve ATM dolandırıcılıklarına (kameralı sistemlere) karşı da dikkatli olmalısınız.&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>3 boyutlu g&uuml;venlik (3D secure) sistemi nedir?</strong></p>\r\n\r\n<p>Visa ve Mastercard&#39;ın uluslararası ge&ccedil;erliliği olan bu sistemi, internet alışveriş d&uuml;nyasının 3 boyutu olan m&uuml;şteri, kart sağlayıcısı banka ve işyeri arasındaki bilgi akışını alışveriş esnasında &ouml;zel şifre ve anahtarlar sayesinde g&uuml;venle sağlar.&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>ATM, kartımı vermiyor! Ne yapmalıyım?</strong></p>\r\n\r\n<p>Panik yapmayın ve ATM&#39;nin başından kesinlikle ayrılmayın. İlk iş olarak ilgili bankanın &ccedil;ağrı merkezini aramalı ve kartı kullanıma kapatmalısınız. Bu esnada dışarıdan gelebilecek yardım tekliflerini kibarca reddedin. Sizlere bu konuda sadece banka personeli yardımcı olabilir. Kartınızın kullanıma kapatıldığı onayını aldıktan sonra ATM&#39;den ayrılabilirsiniz.</p>\r\n', '', 'blog', '/panel/upload/resimler/5fd6772a6581e.png', '1607890622', 'Evet', 132, '2020-12-13 20:18:54'),
(10, 'Şahıs Şirketi Nasıl Kurulur?', 'sahis-sirketi-nasil-kurulur', '<p>Şahıs şirketi nasıl kurulur, sorusunun cevabını adım adım ve aşama aşama anlatmak sizler i&ccedil;in olduk&ccedil;a faydalı olacaktır.</p>\r\n\r\n<h3><strong>1.Aşama:&nbsp;G&uuml;venilir&nbsp;bir&nbsp;muhasebeci&nbsp;ile&nbsp;anlaşmak</strong></h3>\r\n\r\n<p>Şahıs şirketi kurmanın ilk aşaması g&uuml;venilir, sekt&ouml;r&uuml;n&uuml;zle alakalı g&uuml;venilir bir muhasebeci ile anlaşmak olmalıdır. Muhasebecinizi se&ccedil;erken sekt&ouml;r&uuml;n&uuml;zde faaliyet g&ouml;steren işletmelere muhasebe hizmeti verdiğinden emin olmalısınız. Bu durum sizin avantajınıza olacaktır.</p>\r\n\r\n<p>Muhasebecinizi tercih ederken mevzuat bilgi seviyesini, sizi ilgilendiren farklı konulardaki bilgi seviyesini de g&ouml;z &ouml;n&uuml;nde bulundurun. Size katma değer sağlamayan, sadece beyanname hizmeti verecek olan muhasebeci ile &ccedil;alışmanızı &ouml;nermem. Devlet destekleri, krediler vb. konularında da y&ouml;nlendirme ve bilgilendirme yapan bir&ccedil;ok yetkin muhasebeci bulunmaktadır.</p>\r\n\r\n<p>Bundan sonraki aşamaları, zaten muhasebeciniz size anlatacak ve sizi y&ouml;nlendirecektir.</p>\r\n\r\n<h3><strong>2. Aşama: İş yeri kiralamak</strong></h3>\r\n\r\n<p>Muhasebecinizle anlaştıktan sonra onun da bilgisi dahilinde iş yerinizi kiralamalı ve kira kontratınızı yapmalısınız. İş yeri kira olacak ise devlete stopaj &ouml;deyeceğinizi bilmelisiniz.</p>\r\n\r\n<p>&Uuml;lkemizde yıllık kira bedelinin %20&rsquo;si kadar devlete stopaj &ouml;dersiniz. Stopaj konusunda muhasebeciniz sizi daha detaylı bilgilendirecektir.</p>\r\n\r\n<p>Eğer iş yeri size aitse bu kısmı atlayabilirsiniz.</p>\r\n\r\n<h3><strong>3. Aşama: Notere gitmek</strong></h3>\r\n\r\n<p>Kendinize ait&nbsp;<strong>imza sirk&uuml;leri ve muhasebecinize vekalet</strong>&nbsp;vermelisiniz. Bu sayede muhasebeciniz vergi dairesine giderek sizin adınıza işlem ger&ccedil;ekleştirebilecektir.</p>\r\n\r\n<p>Bu işlemden sonra muhasebecinize şu belgeleri teslim etmeniz gerekecektir:</p>\r\n\r\n<ul>\r\n	<li>İmza sirk&uuml;leri</li>\r\n	<li>Muhasebeci vekaleti</li>\r\n	<li>N&uuml;fus c&uuml;zdanı fotokopisi</li>\r\n	<li>İşyeri kira ise kira kontratı; size ait ise tapu fotokopisi</li>\r\n</ul>\r\n\r\n<p>Yukarıdaki belgeleri teslim ettikten sonra diğer aşamaları muhasebeciniz uygulamaya sokacaktır.</p>\r\n\r\n<h3><strong>4. Aşama: Vergi dairesi sisteminde a&ccedil;ılış işlemi başlatmak</strong></h3>\r\n\r\n<p>Sizden aldığı belgeler ile bunu muhasebeciniz ger&ccedil;ekleştirir. Muhasebeciniz, interaktif vergi dairesinin ilgili sitesine giriş yaparak gerekli bilgileri sisteme girer ve a&ccedil;ılış işlemini başlatır.</p>\r\n\r\n<h3><strong>5. Aşama: Vergi dairesine m&uuml;racaat etmek</strong></h3>\r\n\r\n<p>Muhasebeci, almış olduğu vekalet sayesinde iş yeri sahibinden almış olduğu belgeler ile iş yerinin bağlı bulunduğu vergi dairesine giderek a&ccedil;ılış m&uuml;racaatını ger&ccedil;ekleştirir.</p>\r\n\r\n<h3><strong>6. Aşama: Yoklama memurunun iş yerini ziyaret etmesi</strong></h3>\r\n\r\n<p>M&uuml;racaat sonra vergi dairesi yoklama memuru, iş yerini ziyaret eder. Bu ziyaretin amacı, ger&ccedil;ekten b&ouml;yle bir işletmenin olup olmamadığını anlamaktır.</p>\r\n\r\n<p>Yoklama memuru, işletmenin fiziki durumunu ve demirbaşını inceler ve tespit eder. Yoklama belgesini d&uuml;zenler ve bu sayede işletmenin resmi olarak a&ccedil;ılışı ger&ccedil;ekleşmiş olur. i</p>\r\n\r\n<p><strong>Not:</strong>&nbsp;Yoklama memuru gelmeden &ouml;nce işletmenizin faaliyete hazır olduğundan emin olmalısınız.</p>\r\n\r\n<h3><strong>7. Aşama: Damga vergisi beyannamesinin verilmesi</strong></h3>\r\n\r\n<p>İş yeri a&ccedil;ılışından itibaren 15 g&uuml;n i&ccedil;erisinde mali m&uuml;şaviriniz, ilgili vergi dairesine damga vergisi beyannamesini vererek &ouml;deme ger&ccedil;ekleştirir. Muhasebeci s&ouml;zleşmesi ve kira kontratı i&ccedil;in bu damga vergisi &ouml;denmektedir.</p>\r\n\r\n<pre>\r\n<span style=\"font-size:14px\"><span style=\"color:#e74c3c\">T&uuml;m bu aşamalardan sonra şahıs şirketi, resmi olarak kurulmuştur. Ancak yapılacak işlemler daha bitmedi. Aşağıdaki iş ve işlemler, faaliyet g&ouml;sterilecek sekt&ouml;re g&ouml;re değişebilmektedir. Genel olarak d&uuml;ş&uuml;nd&uuml;ğ&uuml;m&uuml;zde, şahıs şirketi kurulduktan sonra aşağıdaki aşamaların da tamamlanması zorunlu olmaktadır. Bu nedenle, aşağıdaki aşamaları da atlamamalısınız.</span></span></pre>\r\n\r\n<h3><strong>8. Aşama: Esnaf ve Sanatkarlar Odası&rsquo;na kayıt olmak</strong></h3>\r\n\r\n<p>&Uuml;lkemizdeki yasal mevzuata g&ouml;re şahıs şirketlerinin Esnaf ve Sanatkarlar Odası&rsquo;na kaydı zorunludur. Bu nedenle, kayıt olmanızı &ouml;neriyoruz.</p>\r\n\r\n<p>Kayıt işlemleri i&ccedil;in aşağıdaki belgelere ihtiyacınız olacaktır:</p>\r\n\r\n<ul>\r\n	<li>Kimlik fotokopisi</li>\r\n	<li>Vesikalık fotoğraf (1 adet)</li>\r\n	<li>Vergi levhası</li>\r\n</ul>\r\n\r\n<p>Kayıt işlemlerini siz de yapabilirsiniz, vekalet verdiğiniz muhasebeciniz de yapabilir.</p>\r\n\r\n<h3><strong>9. Aşama: İlgili meslek odasına kayıt olmak</strong></h3>\r\n\r\n<p>Sekt&ouml;r&uuml;n&uuml;z ve faaliyetinizle ilgili meslek odasına kayıt yaptırmalısınız. Kuyumcular ve saat&ccedil;iler odası, kahveciler odası, şekerciler ve pastacılar odası vb. odalar, meslek odalarına &ouml;rnek verilebilir.</p>\r\n\r\n<p>Kayıt işlemleri i&ccedil;in gerekli belgeler şunlardır:</p>\r\n\r\n<ul>\r\n	<li>Vergi levhası</li>\r\n	<li>İkametgah belgesi</li>\r\n	<li>Vesikalık fotoğraf (3 adet)</li>\r\n	<li>N&uuml;fus c&uuml;zdanı &ouml;rneği</li>\r\n	<li>Esnaf sicil tasdiknamesi</li>\r\n	<li>Varsa ustalık belgesi</li>\r\n</ul>\r\n\r\n<h3><strong>10. Aşama: &Ccedil;alışma ve izin ruhsatı almak</strong></h3>\r\n\r\n<p>&Ccedil;alışma ve izin ruhsatı almak zorundasınız. Bu ruhsat, her sekt&ouml;r i&ccedil;in ge&ccedil;erli olmasa da bir&ccedil;ok sekt&ouml;r i&ccedil;in olmazsa olmazdır.</p>\r\n\r\n<p>&Ccedil;alışma ve izin ruhsatı alabilmeniz i&ccedil;in bağlı bulunan belediyeye başvuru yapılma gerekmektedir. Sekt&ouml;r&uuml;n&uuml;ze g&ouml;re sizden talep edilen belgeler, farklılık g&ouml;sterebilmektedir. Bu nedenle, ilgili belediyeyi ziyaret ederek bu belgeleri &ouml;ğrenebilirsiniz.</p>\r\n\r\n<h3><strong>11. Aşama: Yazar kasa ve kaşe almak, fatura bastırmak</strong></h3>\r\n\r\n<p>Sekt&ouml;r&uuml;n&uuml;z perakende ticaret ise mutlaka yazar kasa almalısınız. Yazar kasa satın aldıktan sonra bir matbaa ile anlaşarak fatura bastırmalısınız. Kaşe yaptırmayı da unutmamalısınız.</p>\r\n\r\n<p>Yazar kasa alma zorunluluğunuzu, mutlaka muhasebecinize danışınız.</p>\r\n\r\n<h2>Şahıs şirketi kurma maliyeti 2020 yılında ne kadar?</h2>\r\n\r\n<p>2020 yılında şahıs şirketi kurma maliyeti&nbsp;<strong>4.000 TL</strong>&lsquo;ye kadar &ccedil;ıkmaktadır. Aslına bakarsanız, şahıs şirketini resmi olarak kurmanın maliyeti sadece 300 TL civarındadır. Ancak oda kayıtları, yazar kasa vb. giderler, bu maliyeti artırmaktadır.</p>\r\n\r\n<ul>\r\n	<li>İmza sirk&uuml;leri: 150 TL</li>\r\n	<li>Vekaletname: 75 TL</li>\r\n	<li>Damga vergileri: 100 TL</li>\r\n</ul>\r\n\r\n<p>Buraya kadar şahıs şirketi, resmi olarak kurulur. Bundan sonraki maliyetlere de bakalım.</p>\r\n\r\n<ul>\r\n	<li>Esnaf ve Sanatkarlar Odası&rsquo;na kayıt: 750 TL</li>\r\n	<li>İlgili meslek odasına kayıt: 300 TL (Sekt&ouml;re g&ouml;re değişebilir.)</li>\r\n	<li>Yazar kasa: 1.000 TL (Modeline g&ouml;re değişebilir.)</li>\r\n	<li>Fatura ve kaşe: 250 TL</li>\r\n	<li>İşyeri &ccedil;alışma ve izin ruhsatı: 1.500 TL</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n', '', 'blog', '/panel/upload/resimler/5fd679032424e.png', '1607890883', 'Evet', 132, '2020-12-13 20:26:46'),
(11, 'Üyelik Şartları', 'uyelik-sartlari', '<p><strong>&Uuml;YELİK S&Ouml;ZLEŞMESİ</strong></p>\r\n\r\n<p>Sitemize &uuml;ye olmadan &ouml;nce aşağıda yer alan s&ouml;zleşmeyi dikkatlice okuyunuz l&uuml;tfen.</p>\r\n\r\n<p><strong>1. Taraflar</strong></p>\r\n\r\n<p>a) www....com internet sitesinin faaliyetlerini y&uuml;r&uuml;ten ...........İstanbul adresinde mukim ..... A.Ş. (Bundan b&ouml;yle .... olarak anılacaktır).</p>\r\n\r\n<p>b) www.....com internet sitesine &uuml;ye olan internet kullanıcısı (&quot;&Uuml;ye&quot;)</p>\r\n\r\n<p><strong>2. S&ouml;zleşmenin Konusu</strong></p>\r\n\r\n<p>İşbu S&ouml;zleşme&#39;nin konusu ....&#39;nın sahip olduğu internet sitesi www......com &#39;dan &uuml;yenin faydalanma şartlarının belirlenmesidir.</p>\r\n\r\n<p><strong>3. Tarafların Hak ve Y&uuml;k&uuml;ml&uuml;l&uuml;kleri</strong></p>\r\n\r\n<p>3.1. &Uuml;ye, www....com internet sitesine &uuml;ye olurken verdiği kişisel ve diğer sair bilgilerin kanunlar &ouml;n&uuml;nde doğru olduğunu, ....&#39;nın bu bilgilerin ger&ccedil;eğe aykırılığı nedeniyle uğrayacağı t&uuml;m zararları aynen ve derhal tazmin edeceğini beyan ve taahh&uuml;t eder.</p>\r\n\r\n<p>3.2. &Uuml;ye, .... tarafından kendisine verilmiş olan şifreyi başka kişi ya da kuruluşlara veremez, &uuml;yenin s&ouml;z konusu şifreyi kullanma hakkı bizzat kendisine aittir. Bu sebeple doğabilecek t&uuml;m sorumluluk ile &uuml;&ccedil;&uuml;nc&uuml; kişiler veya yetkili merciler tarafından ....&#39;ya karşı ileri s&uuml;r&uuml;lebilecek t&uuml;m iddia ve taleplere karşı, ....&#39;nın s&ouml;z konusu izinsiz kullanımdan kaynaklanan her t&uuml;rl&uuml; tazminat ve sair talep hakkı saklıdır.</p>\r\n\r\n<p>3.3. &Uuml;ye www......com internet sitesini kullanırken yasal mevzuat h&uuml;k&uuml;mlerine riayet etmeyi ve bunları ihlal etmemeyi baştan kabul ve taahh&uuml;t eder. Aksi takdirde, doğacak t&uuml;m hukuki ve cezai y&uuml;k&uuml;ml&uuml;l&uuml;kler tamamen ve m&uuml;nhasıran &uuml;yeyi bağlayacaktır.</p>\r\n\r\n<p>3.4. &Uuml;ye, www......com internet sitesini hi&ccedil;bir şekilde kamu d&uuml;zenini bozucu, genel ahlaka aykırı, başkalarını rahatsız ve taciz edici şekilde, yasalara aykırı bir ama&ccedil; i&ccedil;in, başkalarının fikri ve telif haklarına tecav&uuml;z edecek şekilde kullanamaz. Ayrıca, &uuml;ye başkalarının hizmetleri kullanmasını &ouml;nleyici veya zorlaştırıcı faaliyet (spam, virus, truva atı, vb.) ve işlemlerde bulunamaz.</p>\r\n\r\n<p>3.5. www......com internet sitesinde &uuml;yeler tarafından beyan edilen, yazılan, kullanılan fikir ve d&uuml;ş&uuml;nceler, tamamen &uuml;yelerin kendi kişisel g&ouml;r&uuml;şleridir ve g&ouml;r&uuml;ş sahibini bağlar. Bu g&ouml;r&uuml;ş ve d&uuml;ş&uuml;ncelerin ....&#39;yla hi&ccedil;bir ilgi ve bağlantısı yoktur. ....&#39;nın &uuml;yenin beyan edeceği fikir ve g&ouml;r&uuml;şler nedeniyle &uuml;&ccedil;&uuml;nc&uuml; kişilerin uğrayabileceği zararlardan ve &uuml;&ccedil;&uuml;nc&uuml; kişilerin beyan edeceği fikir ve g&ouml;r&uuml;şler nedeniyle &uuml;yenin uğrayabileceği zararlardan dolayı herhangi bir sorumluluğu bulunmamaktadır.</p>\r\n\r\n<p>3.6. ...., &uuml;ye verilerinin yetkisiz kişilerce okunmasından ve &uuml;ye yazılım ve verilerine gelebilecek zararlardan dolayı sorumlu olmayacaktır. &Uuml;ye, www......com internet sitesinin kullanılmasından dolayı uğrayabileceği herhangi bir zarar y&uuml;z&uuml;nden ....dan tazminat talep etmemeyi peşinen kabul etmiştir.</p>\r\n\r\n<p>3.7. &Uuml;ye, diğer internet kullanıcılarının yazılımlarına ve verilerine izinsiz olarak ulaşmamayı veya bunları kullanmamayı kabul etmiştir. Aksi takdirde, bundan doğacak hukuki ve cezai sorumluluklar tamamen &uuml;yeye aittir.</p>\r\n\r\n<p>3.8. İşbu &uuml;yelik s&ouml;zleşmesi i&ccedil;erisinde sayılan maddelerden bir ya da birka&ccedil;ını ihlal eden &uuml;ye işbu ihlal nedeniyle cezai ve hukuki olarak şahsen sorumlu olup, ....&#39;yı bu ihlallerin hukuki ve cezai sonu&ccedil;larından ari tutacaktır. Ayrıca; işbu ihlal nedeniyle, olayın hukuk alanına intikal ettirilmesi halinde, ....&#39;nın &uuml;yeye karşı &uuml;yelik s&ouml;zleşmesine uyulmamasından dolayı tazminat talebinde bulunma hakkı saklıdır.</p>\r\n\r\n<p>3.9. ....&#39;nın her zaman tek taraflı olarak gerektiğinde &uuml;yenin &uuml;yeliğini silme, m&uuml;şteriye ait dosya, belge ve bilgileri silme hakkı vardır. &Uuml;ye işbu tasarrufu &ouml;nceden kabul eder. Bu durumda, ....&#39;nın hi&ccedil;bir sorumluluğu yoktur.</p>\r\n\r\n<p>3.10. www......com internet sitesi yazılım ve tasarımı .... m&uuml;lkiyetinde olup, bunlara ilişkin telif hakkı ve/veya diğer fikri m&uuml;lkiyet hakları ilgili kanunlarca korunmakta olup, bunlar &uuml;ye tarafından izinsiz kullanılamaz, iktisap edilemez ve değiştirilemez. Bu web sitesinde adı ge&ccedil;en başkaca şirketler ve &uuml;r&uuml;nleri sahiplerinin ticari markalarıdır ve ayrıca fikri m&uuml;lkiyet hakları kapsamında korunmaktadır.</p>\r\n\r\n<p>3.11. .... tarafından www......com internet sitesinin iyileştirilmesi, geliştirilmesine y&ouml;nelik olarak ve/veya yasal mevzuat &ccedil;er&ccedil;evesinde siteye erişmek i&ccedil;in kullanılan İnternet servis sağlayıcısının adı ve Internet Protokol (IP) adresi, Siteye erişilen tarih ve saat, sitede bulunulan sırada erişilen sayfalar ve siteye doğrudan bağlanılmasını sağlayan Web sitesinin Internet adresi gibi birtakım bilgiler toplanabilir.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>3.12. ...., &uuml;yenin kişisel bilgilerini yasal bir zorunluluk olarak istendiğinde veya (a) yasal gereklere uygun hareket etmek veya ....ya tebliğ edilen yasal işlemlere uymak; (b) ....ve ....web sitesi ailesinin haklarını ve m&uuml;lkiyetini korumak ve savunmak i&ccedil;in gerekli olduğuna iyi niyetle kanaat getirdiği hallerde a&ccedil;ıklayabilir.</p>\r\n\r\n<p>3.13. ....web sitesinin virus ve benzeri ama&ccedil;lı yazılımlardan arındırılmış olması i&ccedil;in mevcut imkanlar dahilinde tedbir alınmıştır. Bunun yanında nihai g&uuml;venliğin sağlanması i&ccedil;in kullanıcının, kendi virus koruma sistemini tedarik etmesi ve gerekli korunmayı sağlaması gerekmektedir. Bu bağlamda &uuml;ye .... web sitesi&#39;ne girmesiyle, kendi yazılım ve işletim sistemlerinde oluşabilecek t&uuml;m hata ve bunların doğrudan yada dolaylı sonu&ccedil;larından kendisinin sorumlu olduğunu kabul etmiş sayılır.</p>\r\n\r\n<p>3.14. ...., sitenin i&ccedil;eriğini dilediği zaman değiştirme, kullanıcılara sağlanan herhangi bir hizmeti değiştirme yada sona erdirme veya .... web sitesinde kayıtlı kullanıcı bilgi ve verilerini silme hakkını saklı tutar.</p>\r\n\r\n<p>3.15. ...., &uuml;yelik s&ouml;zleşmesinin koşullarını hi&ccedil;bir şekil ve surette &ouml;n ihbara ve/veya ihtara gerek kalmaksızın her zaman değiştirebilir, g&uuml;ncelleyebilir veya iptal edebilir. Değiştirilen, g&uuml;ncellenen yada y&uuml;r&uuml;rl&uuml;kten kaldırılan her h&uuml;k&uuml;m , yayın tarihinde t&uuml;m &uuml;yeler bakımından h&uuml;k&uuml;m ifade edecektir.</p>\r\n\r\n<p>3.16. Taraflar, ....&#39;ya ait t&uuml;m bilgisayar kayıtlarının tek ve ger&ccedil;ek m&uuml;nhasır delil olarak, HUMK madde 287&#39;ye uygun şekilde esas alınacağını ve s&ouml;z konusu kayıtların bir delil s&ouml;zleşmesi teşkil ettiği hususunu kabul ve beyan eder.</p>\r\n\r\n<p>3.17. ...., iş bu &uuml;yelik s&ouml;zleşmesi uyarınca, &uuml;yelerinin kendisinde kayıtlı elektronik posta adreslerine bilgilendirme mailleri ve cep telefonlarına bilgilendirme SMS&#39;leri g&ouml;nderme yetkisine sahip olmakla beraber, &uuml;ye işbu &uuml;yelik s&ouml;zleşmesini onaylamasıyla beraber bilgilendirme maillerinin elektronik posta adresine ve bilgilendirme SMS&#39;lerinin cep telefonuna g&ouml;nderilmesini kabul etmiş sayılacaktır.</p>\r\n\r\n<p><strong>4. S&ouml;zleşmenin Feshi</strong></p>\r\n\r\n<p>İşbu s&ouml;zleşme &uuml;yenin &uuml;yeliğini iptal etmesi veya .... tarafından &uuml;yeliğinin iptal edilmesine kadar y&uuml;r&uuml;rl&uuml;kte kalacaktır. .... &uuml;yenin &uuml;yelik s&ouml;zleşmesinin herhangi bir h&uuml;km&uuml;n&uuml; ihlal etmesi durumunda &uuml;yenin &uuml;yeliğini iptal ederek s&ouml;zleşmeyi tek taraflı olarak feshedebilecektir.</p>\r\n\r\n<p><strong>5. ihtilaflarin Halli</strong></p>\r\n\r\n<p>İşbu s&ouml;zleşmeye ilişkin ihtilaflarda İstanbul Mahkemeleri ve İcra Daireleri yetkilidir.</p>\r\n\r\n<p><strong>6. Y&uuml;r&uuml;rl&uuml;k</strong></p>\r\n\r\n<p>&Uuml;yenin, &uuml;yelik kaydı yapması &uuml;yenin &uuml;yelik s&ouml;zleşmesinde yer alan t&uuml;m maddeleri okuduğu ve &uuml;yelik s&ouml;zleşmesinde yer alan maddeleri kabul ettiği anlamına gelir. İşbu S&ouml;zleşme &uuml;yenin &uuml;ye olması anında akdedilmiş ve karşılıklı olarak y&uuml;r&uuml;rl&uuml;l&uuml;ğe girmiştir.</p>\r\n', '', 'kullanıcı sözleşmesi', NULL, '1607893232', 'Evet', 61, '2020-12-13 21:04:20'),
(12, 'İptal ve İade Prosedürü', 'iptal-ve-iade-proseduru', '<p>İptal ve İade Prosed&uuml;r&uuml; ile ilgili kurallar burada anlatılmalıdır. (Paytr tarafından istenmektedir)</p>\r\n', 'İptal ve İade Prosedürü', 'sayfa', NULL, '1611643451', 'Evet', 125, '2021-01-26 06:45:20');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `talepler`
--

CREATE TABLE `talepler` (
  `id` int(11) NOT NULL,
  `talepno` text NOT NULL,
  `uyeid` int(11) NOT NULL DEFAULT 0,
  `ozelid` int(11) NOT NULL DEFAULT 0,
  `durum` text NOT NULL,
  `olusturma` timestamp NOT NULL DEFAULT current_timestamp(),
  `katid` int(11) NOT NULL,
  `secim` longtext NOT NULL,
  `detaylar` longtext NOT NULL,
  `galeri` text NOT NULL,
  `il` text NOT NULL,
  `ilce` text NOT NULL,
  `nezaman` text NOT NULL,
  `tarih` int(16) NOT NULL,
  `saat` text NOT NULL,
  `hit` int(11) NOT NULL DEFAULT 0,
  `kazananid` int(11) NOT NULL DEFAULT 0,
  `kazanantarih` datetime NOT NULL,
  `kazananteklif` decimal(9,2) NOT NULL DEFAULT 0.00,
  `puan` int(11) NOT NULL DEFAULT 0,
  `yorum` text NOT NULL,
  `yorumtarihi` datetime DEFAULT NULL,
  `yorumonay` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `talepler`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `teklifler`
--

CREATE TABLE `teklifler` (
  `id` int(11) NOT NULL,
  `uyeid` int(11) NOT NULL DEFAULT 0,
  `talepno` text NOT NULL,
  `teklif` decimal(9,2) NOT NULL DEFAULT 0.00,
  `durum` text NOT NULL,
  `olusturma` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `teklifler`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ucretler`
--

CREATE TABLE `ucretler` (
  `id` int(11) NOT NULL,
  `siparisno` text NOT NULL,
  `uyeid` int(11) NOT NULL DEFAULT 0,
  `miktar` decimal(9,2) NOT NULL DEFAULT 0.00,
  `durum` int(11) NOT NULL DEFAULT 0,
  `aciklama` text NOT NULL,
  `paketid` int(11) NOT NULL DEFAULT 0,
  `tarih` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `ucretler`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ustmenu`
--

CREATE TABLE `ustmenu` (
  `id` int(11) NOT NULL,
  `baslik` mediumtext NOT NULL,
  `link` mediumtext NOT NULL,
  `ustkat` int(11) NOT NULL DEFAULT 0,
  `sira` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `ustmenu`
--

INSERT INTO `ustmenu` (`id`, `baslik`, `link`, `ustkat`, `sira`) VALUES
(1, 'Anasayfa', '/', 0, 0),
(2, 'Tüm Kategoriler', '/kategoriler', 0, 1),
(3, 'Bize Ulaşın', '/bize-ulasin', 0, 5),
(6, 'Yazılar', '/blog', 0, 4),
(7, 'Tüm Talepler', '/tumtalepler', 0, 2),
(8, 'Hizmet İlanları', '/hizmetilanlari', 0, 3);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `uyeler`
--

CREATE TABLE `uyeler` (
  `id` int(11) NOT NULL,
  `tokenid` text NOT NULL,
  `uyetipi` text NOT NULL,
  `isim` text NOT NULL,
  `bakiye` decimal(9,2) NOT NULL DEFAULT 0.00,
  `puan` decimal(6,2) NOT NULL DEFAULT 5.00,
  `eposta` text NOT NULL,
  `sifre` text NOT NULL,
  `songiris` datetime NOT NULL DEFAULT '2018-01-01 00:00:00',
  `yetki` int(11) NOT NULL DEFAULT 0,
  `resim` text NOT NULL,
  `unvan` text NOT NULL,
  `ozgecmis` longtext NOT NULL,
  `tel` text NOT NULL,
  `il` text NOT NULL,
  `ilce` text NOT NULL,
  `adres` text NOT NULL,
  `facebook` text NOT NULL,
  `twitter` text NOT NULL,
  `instagram` text NOT NULL,
  `linkedin` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `uyeler`
--

INSERT INTO `uyeler` (`id`, `tokenid`, `uyetipi`, `isim`, `bakiye`, `puan`, `eposta`, `sifre`, `songiris`, `yetki`, `resim`, `unvan`, `ozgecmis`, `tel`, `il`, `ilce`, `adres`, `facebook`, `twitter`, `instagram`, `linkedin`) VALUES
(1, '', 'Firma', 'Site Yöneticisi', 10.00, 4.67, 'admin@admin.com', 'admin', '2021-08-26 02:02:55', 99, '', 'Web Yazılımcı', '', '', '', '', '', '', '', '', '');
--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `adimsecenekleri`
--
ALTER TABLE `adimsecenekleri`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `ayarlar`
--
ALTER TABLE `ayarlar`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `bankahesaplari`
--
ALTER TABLE `bankahesaplari`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `bildirimler`
--
ALTER TABLE `bildirimler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `galeri`
--
ALTER TABLE `galeri`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `hizmetler`
--
ALTER TABLE `hizmetler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `ilceler`
--
ALTER TABLE `ilceler`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ilid` (`ilid`);

--
-- Tablo için indeksler `iller`
--
ALTER TABLE `iller`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `kategoriler`
--
ALTER TABLE `kategoriler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `mesajlar`
--
ALTER TABLE `mesajlar`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `paketler`
--
ALTER TABLE `paketler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `paketozellikleri`
--
ALTER TABLE `paketozellikleri`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `sayfalar`
--
ALTER TABLE `sayfalar`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `talepler`
--
ALTER TABLE `talepler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `teklifler`
--
ALTER TABLE `teklifler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `ucretler`
--
ALTER TABLE `ucretler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `ustmenu`
--
ALTER TABLE `ustmenu`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `uyeler`
--
ALTER TABLE `uyeler`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `adimsecenekleri`
--
ALTER TABLE `adimsecenekleri`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- Tablo için AUTO_INCREMENT değeri `ayarlar`
--
ALTER TABLE `ayarlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `bankahesaplari`
--
ALTER TABLE `bankahesaplari`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `bildirimler`
--
ALTER TABLE `bildirimler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `galeri`
--
ALTER TABLE `galeri`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- Tablo için AUTO_INCREMENT değeri `hizmetler`
--
ALTER TABLE `hizmetler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- Tablo için AUTO_INCREMENT değeri `ilceler`
--
ALTER TABLE `ilceler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=971;

--
-- Tablo için AUTO_INCREMENT değeri `iller`
--
ALTER TABLE `iller`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- Tablo için AUTO_INCREMENT değeri `kategoriler`
--
ALTER TABLE `kategoriler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- Tablo için AUTO_INCREMENT değeri `mesajlar`
--
ALTER TABLE `mesajlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `paketler`
--
ALTER TABLE `paketler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `paketozellikleri`
--
ALTER TABLE `paketozellikleri`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `sayfalar`
--
ALTER TABLE `sayfalar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Tablo için AUTO_INCREMENT değeri `talepler`
--
ALTER TABLE `talepler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- Tablo için AUTO_INCREMENT değeri `teklifler`
--
ALTER TABLE `teklifler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Tablo için AUTO_INCREMENT değeri `ucretler`
--
ALTER TABLE `ucretler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- Tablo için AUTO_INCREMENT değeri `ustmenu`
--
ALTER TABLE `ustmenu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Tablo için AUTO_INCREMENT değeri `uyeler`
--
ALTER TABLE `uyeler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
