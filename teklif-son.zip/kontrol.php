<?php
$v=1.9;
$uyeid='';
$uyeeposta='';
$isim='';
$uyeil='';
$uyeilce='';
$uyeadres='';
$uyetel='';
$uyetipi='Müşteri';
$yetki='';
$paketid=0;
$paketozellikleri='';
if(isset($_SESSION["uyeid"])){
$uyeid=$_SESSION["uyeid"];
}else if(isset($_COOKIE["uyeid"])){
$uyeid=$_COOKIE["uyeid"];
}

if(!empty($uyeid)){
$q = $db->prepare("SELECT * FROM uyeler WHERE id=:id");
$q->bindValue(':id', $uyeid);
$q->execute();
if($q->rowCount()>0){
$uyebilgi = $q->fetch(PDO::FETCH_ASSOC);
$uyeid=$uyebilgi['id'];
$uyeeposta=$uyebilgi['eposta'];
$isim=$uyebilgi['isim'];
$uyeil=$uyebilgi['il'];
$uyeilce=$uyebilgi['ilce'];
$uyeadres=$uyebilgi['adres'];
$uyetel=$uyebilgi['tel'];
$uyetipi=$uyebilgi['uyetipi'];
$uyebakiye=$uyebilgi['bakiye'];
$yetki=$uyebilgi['yetki'];


$paketbilgi1 = $db->query("SELECT * FROM ucretler where uyeid=".$uyeid." and paketid>0 and durum=1 order by id desc ")->fetch(PDO::FETCH_ASSOC);
if(isset($paketbilgi1['id'])){
$paketbilgi = $db->query("SELECT * FROM paketler where id=".$paketbilgi1['paketid']." ")->fetch(PDO::FETCH_ASSOC);
if(isset($paketbilgi['id'])){
$paketbaslangic = strtotime($paketbilgi1['tarih']);
$paketbitis = strtotime('+'.$paketbilgi['sure'].' Months', $paketbaslangic);
if($paketbitis>time()){
$paketid=$paketbilgi['id'];
$paket=$paketbilgi['baslik'];
$paketozellikleri=$paketbilgi['ozellikler'];
}
}
}


}
}
?>
