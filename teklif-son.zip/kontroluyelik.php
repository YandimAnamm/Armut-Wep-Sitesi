<?php
if($uyeid==''){
header("Location: giris.php?uyelik=gerekli&hedef=".$siteurl.$_SERVER['REQUEST_URI']);
}
?>
