<?php
include "panel/db.php";
include "kontrol.php";
include "kontroluyelik.php";



if( isset($_GET['islem']) ){
if( $_GET['islem']=="kaydet" ){

$yeni = $db->prepare("UPDATE uyeler SET eposta = :eposta, il = :il, ilce = :ilce, unvan = :unvan, ozgecmis = :ozgecmis, adres = :adres, facebook = :facebook, twitter = :twitter, instagram = :instagram, linkedin = :linkedin WHERE id=".$uyeid." ");
$yeni->bindValue(':eposta', $_POST['eposta']);
$yeni->bindValue(':il', $_POST['il']);
$yeni->bindValue(':ilce', $_POST['ilce']);
$yeni->bindValue(':unvan', $_POST['unvan']);
$yeni->bindValue(':ozgecmis', $_POST['ozgecmis']);
$yeni->bindValue(':adres', $_POST['adres']);
$yeni->bindValue(':facebook', $_POST['facebook']);
$yeni->bindValue(':twitter', $_POST['twitter']);
$yeni->bindValue(':instagram', $_POST['instagram']);
$yeni->bindValue(':linkedin', $_POST['linkedin']);
$yeni->execute();

if( !empty($_POST['sifre']) && !empty($_POST['sifre2']) ){
if( $_POST['sifre']==$_POST['sifre2'] ){
$yeni = $db->prepare("UPDATE uyeler SET sifre = :sifre WHERE id=".$uyeid." ");
$yeni->bindValue(':sifre', $_POST['sifre']);
$yeni->execute();
}
}

if($yeni){
    header("Location: ?success=Değişiklikler kaydedildi.");
}

}}





if( isset($_GET['islem']) ){
if( $_GET['islem']=="resimkaydet" ){

if(isset($_FILES['avatar']) and !$_FILES['avatar']['error']){
	$file = 'panel/upload/resimler/' . $uyeid.'-'.time().'.png';
	file_put_contents($file, file_get_contents($_FILES['avatar']['tmp_name']));

$yeni = $db->prepare("UPDATE uyeler SET resim = :resim where id = :uyeid ");
$yeni->bindValue(':uyeid', $uyeid);
$yeni->bindValue(':resim', "/".$file);
$yeni->execute();
} 

echo "ok";

}}




$bak = $db->prepare("SELECT * FROM uyeler WHERE id=:id");
$bak->bindValue(':id', $uyeid);
$bak->execute();
if($bak->rowCount()){
$veri = $bak->fetch(PDO::FETCH_ASSOC);
?>


<!DOCTYPE html>
<html lang="tr">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">

	        <!-- Title -->
      <title>Profilim</title>
      <meta name="description" content="">
      <meta name="keyword" content="">
      <meta name="author" content="yahyaaydin.com.tr">

<?php include "script.php"; ?>

<style>
.single-input input[type="password"] {
    display: block;
    width: 100%;
    border: 2px solid #e8ecec;
    padding: 7px 10px;
    border-radius: 5px;
    color: #666;
}
</style>
<!-- Cropper CSS -->
<link href="assets/cropper/cropper.css" rel="stylesheet">


   </head>
   <body>
       
       
      <!-- Header Area Start -->
      <header class="jobguru-header-area stick-top forsticky page-header">
<?php include "menu.php"; ?>
      </header>
      <!-- Header Area End -->
       
       
       
      <!-- Breadcromb Area Start -->
      <section class="jobguru-breadcromb-area">
         <div class="breadcromb-bottom">
            <div class="container">
               <div class="row">
                  <div class="col-md-12">
                     <div class="breadcromb-box-pagin">
                        <ul>
                           <li><a href="/">Anasayfa</a></li>
                           <li class="active-breadcromb"><a href="#">Profilim</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Breadcromb Area End -->
       
       
      <!-- Candidate Dashboard Area Start -->
      <section class="candidate-dashboard-area section_30">
         <div class="container">
            <div class="row">
               <?php include "menuprofil.php"; ?>
               <div class="col-lg-9 col-md-12">
                  <div class="dashboard-right">
                     <div class="candidate-profile">
                        <div class="candidate-single-profile-info">
						<form action="?islem=resimkaydet" method="post" >
                           <div class="single-resume-feild resume-avatar">
                              <div class="resume-image">
                                 <img src="<?=$uyebilgi['resim']?>" onerror="this.src='/assets/resimler/noperson.png'" id="avatar" alt="Profil Resmi">
								 <div class="resume-avatar-hover">
                                    <div class="resume-avatar-upload">
									   <input type="file"  id="input" style="opacity:0;">
                                       <p>
                                          <i class="fa fa-pencil"></i>
                                          Güncelle
                                       </p>
                                    </div>
                                 </div>
								 
                              </div>
                           </div>
						   <p class="text-center"><button type="submit" class="btn btn-success yuklebuton2" style="display:none"><i class="fa fa-pencil"></i> Değişikliği Kaydet</button><p>
						</form>
                        </div>
                        <div class="candidate-single-profile-info">
                           <form id="pform" action="?islem=kaydet" method="post" >
                              <div class="resume-box">
                                 <h3>Profilim</h3>
                                 <div class="single-resume-feild feild-flex-2">
                                    <div class="single-input">
                                       <label for="name">Ad Soyad:</label>
                                       <input type="text" name="isim" value="<?php echo $veri['isim'];?>" id="name" required readonly>
                                    </div>
                                    <div class="single-input">
                                       <label for="p_title">Unvan (Zorunlu değil):</label>
                                       <input type="text" name="unvan" value="<?php echo $veri['unvan'];?>" placeholder="" id="p_title" >
                                    </div>
                                 </div>
                              </div>
                              <div class="resume-box">
                                 <h3>İletişim Bilgileri</h3>
                                 <div class="single-resume-feild feild-flex-2">
                                    <div class="single-input">
                                       <label for="Phone">Telefon:</label>
                                       <input type="text" name="tel" value="<?php echo $veri['tel'];?>" id="Phone" required  readonly>
                                    </div>
                                    <div class="single-input">
                                       <label for="Email">E-Posta:</label>
                                       <input type="text" name="eposta" value="<?php echo $veri['eposta'];?>" id="Email" required>
                                    </div>
                                 </div>
                                 <div class="single-resume-feild feild-flex-2">
                                    <div class="single-input">
                                       <label for="sifre">Şifre <small>(Değiştirmek istemiyorsanız boş bırakınız)</small>:</label>
                                       <input type="password" name="sifre" value="" id="sifre" >
                                    </div>
                                    <div class="single-input">
                                       <label for="sifre2">Şifre (Tekrar) <small>(Değiştirmek istemiyorsanız boş bırakınız)</small>:</label>
                                       <input type="password" name="sifre2" value="" id="sifre2">
                                    </div>
                                 </div>
                                 <div class="single-resume-feild feild-flex-2">
                                    <div class="single-input">
                                       <label for="il">İl:</label>
                                       <select id="il" name="il" required>
                                          <option value=""> İl </option>
<?php
$query = $db->prepare("SELECT * FROM iller order by il asc ");
$query->execute();
while($row=$query->fetch(PDO::FETCH_ASSOC)) {
?>
					<option value="<?=$row['il'];?>" > <?=$row['il'];?> </option>
<?php } ?>
					</select>
                                       </select>
                                    </div>
                                    <div class="single-input" required>
                                       <label for="ilce">İlçe:</label>
                                       <select id="ilce" name="ilce">
                                          <option value=""> Önce İl Seçiniz </option>
                                       </select>
                                    </div>
                                 </div>
                                 <div class="single-resume-feild">
                                    <div class="single-input">
                                       <label for="Address22">Adres:</label>
                                       <input type="text" name="adres" value="<?php echo $veri['adres'];?>" id="Address22">
                                    </div>
                                 </div>
                              </div>


<div style="display:none;" >
							  <div class="resume-box">
                                 <div class="single-resume-feild ">
                                    <div class="single-input">
                                       <label for="Bio">Kısa Özgeçmiş:</label>
                                       <textarea id="Bio" name="ozgecmis" placeholder="Müşterilere kendinizi anlatın" ><?php echo $veri['ozgecmis'];?></textarea>
                                    </div>
                                 </div>
							  </div>
                              <div class="resume-box">
                                 <h3>Sosyal Medya Linkleri</h3>
                                 <div class="single-resume-feild feild-flex-2">
                                    <div class="single-input">
                                       <label for="twitter">
                                       <i class="fa fa-twitter twitter"></i>
                                       Twitter
                                       </label>
                                       <input type="text" name="twitter" value="<?php echo $veri['twitter'];?>" id="twitter" name="twitter">
                                    </div>
                                    <div class="single-input">
                                       <label for="twitter">
                                       <i class="fa fa-facebook facebook"></i>
                                       Facebook
                                       </label>
                                       <input type="text" name="facebook" value="<?php echo $veri['facebook'];?>" id="facebook" name="facebook">
                                    </div>
                                 </div>
                                 <div class="single-resume-feild feild-flex-2">
                                    <div class="single-input">
                                       <label for="instagram">
                                       <i class="fa fa-instagram google"></i>
                                       Instagram
                                       </label>
                                       <input type="text" name="instagram" value="<?php echo $veri['instagram'];?>" id="instagram" name="instagram">
                                    </div>
                                    <div class="single-input">
                                       <label for="linkedin">
                                       <i class="fa fa-linkedin linkedin"></i>
                                       Linkedin
                                       </label>
                                       <input type="text" name="linkedin" value="<?php echo $veri['linkedin'];?>" id="linkedin" name="linkedin">
                                    </div>
                                 </div>
                              </div>
</div>
                              <div class="submit-resume">
							  <p class="uyari text-danger text-center"></p>
                                 <button type="submit">Değişiklikleri Kaydet</button>
                              </div>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Candidate Dashboard Area End -->
       
       
       
      <!-- Hire-2 Area Start -->
      <section class="jobguru-hire-2-area section_70">
         <div class="container">
            <div class="row">
               <div class="col-md-8">
                  <div class="hire-2-box">
                     <h2>Herhangi bir sektörde hizmet mi veriyorsunuz?<br>Hadi para kazanmaya başlayın.</h2>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="hire-box-2-btn">
                     <a href="/hizmetekle.php" class="jobguru-btn-2">Hizmet Profili Oluştur</a>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Hire-2 Area End -->
	  
	  
    <div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalLabel">Profil Foroğrafı Yükle</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="img-container">
              <img class="img-fluid" id="image" src="<?=$uyebilgi['resim']?>" onerror="this.src='/assets/resimler/noperson.png'" >
            </div>
          </div>
          <div class="modal-footer">
		    <span class="float-left">
		    <button type="button" class="btn btn-secondary" id="soladondur"><i class="fa fa-rotate-left"></i></button>
            <button type="button" class="btn btn-secondary" id="sagadondur"><i class="fa fa-rotate-right"></i></button>
			</span>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Vazgeç</button>
            <button type="button" class="btn btn-primary" id="crop">Kaydet</button>
          </div>
        </div>
      </div>
    </div>

<?php include "alt.php"; ?>

<script>
$('#pform').submit(function(){
	if($('#sifre').val()!==''){
		if($('#sifre2').val()==''){
			$('.uyari').html("Şifre tekrarını doldurunuz!");
			return false;
		}else if($('#sifre').val()!==$('#sifre2').val()){
			$('.uyari').html("Şifre ve Şifre tekrarı aynı olmalı!");
			return false;
		}else{
			return true;
		}
	}else{
		return true;
	}
});
</script>

<!-- Image cropper JavaScript -->
<script src="/assets/cropper/cropper.js"></script>
<script>
    window.addEventListener('DOMContentLoaded', function () {
      var avatar = document.getElementById('avatar');
      var image = document.getElementById('image');
      var input = document.getElementById('input');
      var $progress = $('.progress');
      var $progressBar = $('.progress-bar');
      var $alert = $('.alert');
      var $modal = $('#modal');
      var cropper;

      $('[data-toggle="tooltip"]').tooltip();

      input.addEventListener('change', function (e) {
        var files = e.target.files;
        var done = function (url) {
          input.value = '';
          image.src = url;
          $alert.hide();
          $modal.modal('show');
        };
        var reader;
        var file;
        var url;

        if (files && files.length > 0) {
          file = files[0];

          if (URL) {
            done(URL.createObjectURL(file));
          } else if (FileReader) {
            reader = new FileReader();
            reader.onload = function (e) {
              done(reader.result);
            };
            reader.readAsDataURL(file);
          }
        }
      });

      $modal.on('shown.bs.modal', function () {
        cropper = new Cropper(image, {
          aspectRatio: 1,
          viewMode: 3,
		  rotatable: true,
		  movable: true,
		  zoomable: true,
		  scalable: true
        });
      }).on('hidden.bs.modal', function () {
        cropper.destroy();
        cropper = null;
      });

	$('#sagadondur').click(function(){
		cropper.rotate(90);
	});
	$('#soladondur').click(function(){
		cropper.rotate(-90);
	});
	
	
	
	
      document.getElementById('crop').addEventListener('click', function () {
        var initialAvatarURL;
        var canvas;

        $modal.modal('hide');

        if (cropper) {
          canvas = cropper.getCroppedCanvas({
            width: 160,
            height: 160,
          });
          initialAvatarURL = avatar.src;
          avatar.src = canvas.toDataURL();
          $progress.show();
          $alert.removeClass('alert-success alert-warning');
          canvas.toBlob(function (blob) {
            var formData = new FormData();
            formData.append('avatar', blob);
            $.ajax('?islem=resimkaydet', {
              method: 'POST',
              data: formData,
              processData: false,
              contentType: false,

              xhr: function () {
                var xhr = new XMLHttpRequest();

                xhr.upload.onprogress = function (e) {
                  var percent = '0';
                  var percentage = '0%';

                  if (e.lengthComputable) {
                    percent = Math.round((e.loaded / e.total) * 100);
                    percentage = percent + '%';
                    $progressBar.width(percentage).attr('aria-valuenow', percent).text(percentage);
                  }
                };

                return xhr;
              },

              success: function () {
                $alert.show().addClass('alert-success').text('Yükleme Başarılı');
              },

              error: function () {
                avatar.src = initialAvatarURL;
                $alert.show().addClass('alert-warning').text('Yükleme Başarısız');
              },

              complete: function () {
                $progress.hide();
              },
            });
          });
        }
      });
    });
</script>





<script type="text/javascript">
$(function(){
$('#il').on('change', function () {
	var il = $('#il option:selected').val();
    $.post("/ilceler.php", {il: il}, function (cevap) {
        $("#ilce").html(cevap);
		$(".ilce").show("slow");
		
    });
});

$("#il").val("<?=$veri['il']?>");
$.post("/ilceler.php", {il: '<?=$veri['il']?>'}, function (cevap) {
        $("#ilce").html(cevap);
		$(".ilce").show("slow");
		$("#ilce").val("<?=$veri['ilce']?>");
});

});
</script>



   </body>
</html>

<?php } ?>